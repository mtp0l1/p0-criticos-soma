# Regras e verificações

Cada regra do sistema tem um ID. O script `checks/ds_checks.py` e os testes de navegador conferem o que dá para conferir; o resto é revisão humana na triagem. Resultado da última rodada: `checks/relatorio.md`.

## Regras que o script confere

| ID | Regra | Como confere |
|---|---|---|
| TOK-01 | Toda classe de cor e medida usada no código existe no CSS gerado dos tokens | Procura cada classe no `bundle.css`; classe sem token não gera estilo e passa despercebida |
| TOK-02 | Nenhum hex, `rgb()` ou `hsl()` nos componentes | Busca no código (as ilustrações ficam de fora) |
| TOK-03 | Contraste dos pares de token: 4,5:1 texto, 3:1 borda e indicador | Calcula com os valores de `tokens.json` |
| TOK-04 | Texto só em 12, 14, 16, 18, 20, 24 e 32px | Busca `text-[Npx]` e olha os estilos de texto. `tab-label` (11px) é a única exceção |
| TOK-05 | Raios só da escala | Busca `rounded-[...]` |
| SPC-01 | Espaço só na escala de 4px; medida fora dela só se estiver em `excecoes.json` | Busca `gap`, `p*` e `m*` com valor arbitrário |
| CTR-01 | Todo componente tem Usar para, Nunca e Verificado por | Lê os READMEs |
| CAT-01 | Todo componente tem categoria no mapa de decisão | `checks/categorias.json` |
| IDX-01 | Todo componente aparece no índice da doc 1 | Compara pastas e índice |
| NAME-01 | Todo nome citado como `Soma.<Componente>` nas docs existe na API | Compara com `index.d.ts` |
| DEC-01 | `decision-map.md` está igual ao que os contratos geram | Gera de novo e compara |
| ACC-01 | Nenhuma violação de acessibilidade (axe, WCAG 2.2 AA) em todas as visualizações | `checks/axe.js` |
| ACC-02 | Todo controle tocável tem 44×44px | `checks/touch.js`, no celular de 360px. Link no meio de parágrafo está isento |

Regra que não se aplica a um componente é pulada (um card sem botão não passa por ACC-02) e o "Verificado por" do README diz quais valem para ele.

## Regras que ainda dependem de revisão

| ID | Regra |
|---|---|
| CMP-01 a CMP-04 | Composição (ver `AGENTS.md`). Conferidas na triagem |
| UX-01 | Um botão `loud` por tela |
| UX-02 | Os cinco estados desenhados: conta nova, carregando, vazio, erro, sucesso |
| UX-03 | Textos em sentence case, com verbo de toque |
| UX-04 | Voltar leva à tela anterior real |

## Triagem de peça nova

Toda tela nova passa por quatro perguntas, nesta ordem. Pare na primeira que resolver.

1. **Já existe?** Procure no `decision-map.md` pelo sentido, não pelo nome. Se existe, use.
2. **Cabe numa variante ou prop que já existe?** Se sim, use e ajuste a tela.
3. **É a mesma necessidade em mais de uma tela?** Se sim, vira componente novo: nome, tarefa, motivo e origem (CMP-03), contrato escrito e entra nas verificações.
4. **É de uma tela só?** Fica como `##Primitivo##` no handoff, sem entrar no sistema até aparecer uma segunda tela.

## O que o sistema ainda não tem

- Tema escuro: só o claro está definido.
- Layouts além de 360px de largura.
- Componente de mapa para os espaços de recebimento: aparece como `##SpaceMap##` nas telas.
- Tokens de movimento e de elevação além de uma sombra (`shadow-high`); o sistema é plano.
- Tela 6A (e-mail) do cadastro.
- Estados finais de `RedemptionItem` além dos três de `StatusChip`.
- Ilustrações originais: as atuais vêm do Figma.
- Campo de data de nascimento: o tipo de campo está em dúvida com Claudia e Tatiana.
- Contraste do indicador laranja (`selected-indicator`, 2:1): decisão aberta, registrada em `checks/excecoes.json`.

## Como medir se o sistema está funcionando

- Telas novas feitas só com componentes que têm contrato (meta: todas).
- Peças novas por tela e quantas viram componente.
- Falhas por rodada do script e quantas exceções abertas existem em `excecoes.json` (o número só pode cair).
