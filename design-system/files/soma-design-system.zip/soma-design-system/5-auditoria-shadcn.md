# Auditoria contra o shadcn/ui

Comparação do Campana com a biblioteca completa do shadcn/ui (ui.shadcn.com), usada como referência técnica: o que já existia, o que foi adicionado, o que foi corrigido e o que ficou de fora de propósito. A lista de componentes do shadcn foi tomada de memória e deve ser conferida com a documentação oficial antes de fechar o escopo.

## Resultado

| | Quantidade |
|---|---|
| Componentes do shadcn/ui considerados | 59 |
| Já cobertos antes da auditoria | 22 |
| Adicionados nesta auditoria | 20 |
| Cobertos por um equivalente do Campana ou por receita | 7 |
| Fora de propósito no sistema (com motivo) | 10 |
| Correções em componentes existentes | 18 |

Todos os componentes novos seguem a receita do shadcn: primitiva sem estilo (Radix, ou a biblioteca que o próprio shadcn usa) + classes do preset do Campana + variantes em CVA + `cn()`; `forwardRef` e `asChild` onde o shadcn tem. Nenhum usa cor, raio ou tamanho fora dos tokens.

## Cobertura, componente a componente

| shadcn/ui | Campana | Situação |
|---|---|---|
| Accordion | `Accordion` | Já existia; ganhou pressionado e desabilitado |
| Alert | `Alert`, `Message` | Já existia |
| Alert Dialog | `AlertDialog` | Já existia; ganhou rolagem e animação de saída |
| Aspect Ratio | `AspectRatio` | **Novo** (Radix) |
| Avatar | `Avatar` | Já existia |
| Badge | `Badge`, `Tag`, `StatusChip` | Já existia; ganhou `asChild` |
| Breadcrumb | — | Fora: a navegação mobile é por pilha, com voltar no `Header` |
| Button | `Button`, `IconButton` | Já existia; corrigido (ver abaixo) |
| Button Group | `ButtonGroup` | **Novo** |
| Calendar · Date Picker | `SlotPicker`, campo com máscara | Equivalente: o agendamento escolhe entre poucos dias; nascimento é digitado |
| Card | `Card` | Já existia; ganhou `CardAction` |
| Carousel | `Carousel` | **Novo** (Embla) |
| Chart | — | Fora por enquanto: o sistema não tem gráfico; entra com Recharts quando houver |
| Checkbox | `Checkbox` | Já existia; corrigido (área de toque, indeterminado, erro) |
| Collapsible | `Collapsible` | **Novo** (Radix) |
| Combobox | `Combobox` | **Novo** (Popover + Command) |
| Command | `Command` | **Novo** (cmdk) |
| Context Menu | — | Fora: toque longo não é padrão do sistema; ações vão em `DropdownMenu` |
| Data Table | `Table` | Parcial: tabela simples; ordenação e filtro (TanStack) não fazem sentido no celular |
| Dialog | `Dialog`, `Modal` | Já existia; ganhou rolagem e animação de saída |
| Drawer | `Drawer` | **Novo** (Vaul) |
| Dropdown Menu | `DropdownMenu` | **Novo** (Radix) |
| Empty | `EmptyState` | Equivalente |
| Field | `Field` e família | **Novo** |
| Form | `Field` + React Hook Form | Receita no README do `Field`; o pacote não entra no bundle |
| Hover Card | — | Fora: depende de hover; use `Popover` |
| Input | `Input`, `TextField` | Já existia; corrigido (erro no foco, somente leitura, arquivo) |
| Input Group | `InputGroup` | **Novo** |
| Input OTP | `InputOTP` | **Novo** (input-otp) |
| Item | `ListRow` | Equivalente |
| Kbd | — | Fora: não há teclado físico no uso principal |
| Label | `Label` | Já existia; reage a `Field` desabilitado |
| Menubar · Navigation Menu · Sidebar · Resizable | — | Fora: padrões de desktop; o sistema usa `TabBar`, `Header` e `Sheet` |
| Native Select | `NativeSelect` | **Novo** |
| Pagination | `Pagination` | **Novo** |
| Popover | `Popover` | Já existia; ganhou `PopoverClose` e animação de saída |
| Progress | `Progress` | Já existia |
| Radio Group | `RadioGroup`, `RadioList` | Já existia; corrigido (área de toque, erro) |
| Scroll Area | `ScrollArea` | **Novo** (Radix) |
| Select | `Select` | Já existia; estado aberto e animação de saída |
| Separator | `Separator` | Já existia |
| Sheet | `Sheet` | Já existia; ganhou `side` top, left e right |
| Skeleton | `Skeleton` | Já existia |
| Slider | `Slider` | **Novo** (Radix) |
| Sonner · Toast | `Toaster` + `notify()`, `Toast` | **Novo** provedor (Sonner); o visual já existia |
| Spinner | `Spinner` | **Novo** |
| Switch | `Switch` | Já existia; corrigido (área de toque, hover, desabilitado) |
| Table | `Table` | **Novo** |
| Tabs | `Tabs`, `SegmentedControl` | Já existia; ganhou pressionado |
| Textarea | `Textarea` | Já existia |
| Toggle · Toggle Group | `Toggle`, `ToggleGroup` | **Novo** (Radix) |
| Tooltip | — | Fora: no celular não há hover; ajuda curta vai em `Popover` |
| Typography | estilos de texto | Equivalente: classes `page-title`, `body`, `caption`… |

## O que estava abaixo do padrão e foi corrigido

| Onde | Problema | Correção |
|---|---|---|
| Foco (todos) | `outline: none` fixo: no modo de alto contraste do sistema o anel (box-shadow) some e não sobra indicador | `focusRing` agora mantém um contorno transparente de 2px, que o sistema pinta em alto contraste |
| `Button` | Link com cara de botão (`asChild`) não tinha estado desabilitado | `aria-disabled`, fora da ordem de foco, mesmo visual do `disabled` |
| `Button` | `destructive` usava a mesma cor em hover e pressionado | Tokens `interactive-fill-destructive-hover` e `-active` |
| `Button` | Ícone podia capturar o toque e encolher | `pointer-events-none` e `shrink-0` nos ícones |
| `Checkbox`, `RadioGroupItem`, `Switch` | Área tocável de 20 a 24px quando usados fora de uma linha | `hitArea`: 44px sem mudar o desenho |
| `Checkbox` | Sem estado indeterminado; marcado e desabilitado ficava com check branco sobre cinza | Traço no indeterminado; check em `interactive-text-disabled` |
| `Checkbox`, `RadioGroupItem` | Sem pressionado e sem erro | `active` e `aria-invalid` |
| `Switch` | Sem hover; desabilitado e ligado continuava navy | Hover no trilho; cinza nos dois estados |
| `Input`, `Textarea` | Com erro, o anel de foco continuava navy; sem estilo de somente leitura e de arquivo | Anel vermelho no erro; `readOnly` e `type="file"` tratados |
| `Select` | Gatilho sem estado aberto; ícone com traço diferente do resto | `data-state=open` com `border-highlight`; traço de 2px |
| `Dialog`, `AlertDialog` | Conteúdo maior que a tela era cortado | Altura máxima e rolagem interna |
| `Dialog`, `AlertDialog`, `Sheet`, `Popover`, `Select` | Só animavam a entrada; sumiam de uma vez | Animação de saída em `data-state=closed` |
| `Sheet` | Só `side="bottom"` | `top`, `left` e `right`, como no shadcn |
| `Accordion` | Sem pressionado; item desabilitado parecia ativo | `active` e `data-disabled` |
| `Tabs` | Sem pressionado; aba desabilitada reagia ao hover | `active`; hover desligado no desabilitado |
| `Badge` | Não podia ser link | `asChild` com foco e hover |
| `PressableBase` (Tile, ListRow, BalanceCard…) | Com `href`, o link perdia `onClick`, `aria-*` e `disabled` | O link recebe os mesmos atributos; desabilitado vira `aria-disabled` |
| `Toast` | Só o visual: fila, tempo e anúncio ficavam por conta de quem usa | `Toaster` + `notify()` |

## Dependências novas

`@radix-ui/react-aspect-ratio`, `react-collapsible`, `react-dropdown-menu`, `react-scroll-area`, `react-slider`, `react-toggle`, `react-toggle-group`, `vaul`, `cmdk`, `input-otp`, `sonner`, `embla-carousel-react`. São as mesmas que o shadcn instala para esses componentes. O `bundle.js` de protótipo passou de 226 KB para 431 KB; no repositório, cada tela importa só o que usa.

## Verificação

- TypeScript em modo estrito sem erros.
- axe-core (WCAG 2.2 AA) sem violações nos exemplos de todos os componentes; a única exceção continua sendo o `Toast tone="app"`, mantido de propósito para documentar o vermelho de produção anterior do primeiro produto.
- Menu, combobox, drawer e avisos foram abertos e conferidos em navegador.

## Fica para depois

- `Chart`, quando o Meu impacto ganhar gráfico.
- `Calendar`, se o agendamento passar a aceitar datas distantes.
- `TextField` e `SearchField` continuam com estrutura própria; podem passar a usar `Field` e `InputGroup` por dentro sem mudar a API.
- Tema escuro: os tokens estão prontos para um segundo modo, mas o tema padrão é só claro.
