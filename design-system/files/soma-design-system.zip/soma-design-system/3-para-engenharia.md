# Para engenharia

## Arquitetura

A biblioteca segue a arquitetura do shadcn/ui, com a identidade e as regras do So+ma:

| Camada | O que é | Onde |
|---|---|---|
| Tokens | Núcleo (cores do app), semântico So+ma (papel, como no Andes) e aliases shadcn (`background`, `primary`, `ring`…) | `tokens.json` → `tokens.css` |
| Preset Tailwind | Cores, espaços, tamanhos, raios e sombra do Tailwind apontando para as variáveis de `tokens.css` | `components/src/tailwind.preset.js` |
| Primitivas (`ui/`) | Componentes do shadcn adaptados: Radix para comportamento e acessibilidade, `cva` para variantes, `cn` para juntar classes | `components/src/ui/` |
| Produto (`soma/`) | Componentes do app montados sobre as primitivas (LevelCard, QuestionCard, Podium…) | `components/src/soma/` |

## Arquivos

| Arquivo | O que é |
|---|---|
| `tokens.json` | Fonte única dos tokens |
| `tokens.css` | Variáveis CSS (`--text-primary`, `--primary`, `--space-mini`…) e um estilo de texto por classe (`.label`, `.caption`, `.eyebrow`…) |
| `components/src/` | Código-fonte TypeScript para copiar para o repositório: `lib/utils.ts` (`cn`, `focusRing`), `ui/*.tsx`, `soma/*.tsx`, `index.ts`, `tailwind.preset.js` |
| `components/bundle.css` | O Tailwind compilado a partir de `src/` com o preset (só `var(--token)`, inclui o preflight) |
| `components/bundle.js` | Tudo em `window.Soma`, script clássico que lê React 18 de `window.React` (Radix, CVA e Lucide já dentro) |
| `components/index.d.ts` | Tipos e props de cada componente e primitiva |

## Como levar para o repositório

1. Instale as dependências do shadcn: `@radix-ui/react-*` (accordion, alert-dialog, avatar, checkbox, dialog, label, popover, progress, radio-group, select, separator, slot, switch, tabs, toggle-group), `class-variance-authority`, `clsx`, `tailwind-merge`, `lucide-react@0.544.0` (ou mais nova; é a primeira com `bottle-wine`).
2. Copie `components/src/` para o projeto (por exemplo `src/components/soma/`) e use `tailwind.preset.js` em `presets` do `tailwind.config`.
3. Carregue `tokens.css` no CSS global, antes do Tailwind. Os aliases (`--background`, `--primary`, `--ring`…) já têm os nomes do shadcn: componentes novos do `npx shadcn add` saem com o tema So+ma.
4. Para protótipo sem build, carregue `tokens.css`, `components/bundle.css`, React 18 e `components/bundle.js`; depois `const { Button } = window.Soma`.

App nativo (React Native, Flutter): leia `tokens.json` e gere o tema com os mesmos nomes. Os README de cada componente servem de especificação de medidas, estados e acessibilidade.

## Convenções

- **Variantes por CVA, com o vocabulário do Andes:** `hierarchy` (loud, quiet, transparent, destructive), `size`, `tone`, `variant`, `layout`, `fullWidth`. Cada família exporta suas classes (`buttonVariants`, `badgeVariants`, `cardVariants`, `alertVariants`, `tabsTriggerVariants`, `listRowVariants`, `statTileVariants`, `toastVariants`, `iconVariants`).
- **Classes com `cn()`:** `clsx` + `tailwind-merge` configurado com as escalas So+ma (`p-mini`, `h-button`, `rounded-lg`), então `className` de quem usa sempre vence sem duplicar.
- **Escalas fechadas:** o preset substitui as escalas do Tailwind. Só existem `xnano`…`xlarge` (espaço), `touch`, `button`, `input`, `icon`, `thumb`, `medal`, `avatar`, `qr`, `tile`, `tabbar` (tamanho), `xs`…`xl`, `full` (raio) e as cores semânticas. `p-4` ou `bg-orange-500` não compilam.
- **Texto por classe de estilo:** `page-title`, `screen-title`, `section-title`, `subtitle`, `header-title`, `stat-number`, `balance-number`, `body`, `body-strong`, `body-small`, `label`, `caption`, `eyebrow`, `tab-label`, `button`. Não use `text-sm` e afins. Lexend em 400, 500, 600 e 700.
- **Versão atual e anterior:** componentes cujo desenho mudou nas telas novas aceitam `version` (`TabBar`, `SectionHeader`, `QuestionCard`, `Podium`). O padrão é `"atual"`; `"anterior"` mantém o app em produção funcionando enquanto as telas migram. Nada foi removido.
- **Composição:** `asChild` (Radix Slot) em `Button` e nos gatilhos; `href` nos componentes tocáveis de produto (Tile, BalanceCard, ListRow, RankingBanner, RedemptionItem, RewardRow) vira `<a>`.
- **Ícones pelo nome do Figma:** `Icon` aceita o nome So+ma (`pin`) e o nome da camada no Figma (`map-pin`, `Pino — SVG fornecido`), via `ICON_ALIASES`.
- **Refs:** primitivas usam `forwardRef`, como no shadcn.
- Variantes "como no app" (`tone="app"`, `border="app"`, `nameTone="app"`) só documentam o estado atual.

## Estados

| Estado | Regra | Tokens |
|---|---|---|
| Hover | Escurece o fundo um passo; nunca muda a cor do texto para algo que reprove | `interactive-fill-loud-hover`, `interactive-fill-quiet-hover`, `surface-secondary-hover`, `surface-accent-hover` |
| Pressionado (`active`) | Um passo além do hover | `interactive-fill-loud-active`, `interactive-fill-quiet-active` |
| Foco | Só no teclado (`focus-visible`): anel de 2px em `ring`, a 2px, sobre `background` | `ring` (= `focus-ring`) |
| Desabilitado | Cor cheia, sem opacidade, cursor bloqueado, motivo dito em texto | `interactive-fill-disabled`, `interactive-text-disabled` |
| Selecionado | Pelo atributo do Radix (`data-state=checked/active/on`) ou `aria-current`, nunca só por classe | `primary`, `selected-indicator`, `surface-inverse` |
| Carregando | `aria-busy`, indicador no lugar do ícone, toques ignorados | — |
| Erro | `aria-invalid` no campo; borda e mensagem em `feedback-text-negative` | `feedback-*-negative` |

Transições de 150 a 200ms, todas desligadas com `prefers-reduced-motion`.

## Do Andes e do shadcn para o So+ma

| Andes | shadcn/ui | So+ma |
|---|---|---|
| Button Loud / Quiet / Transparent | Button default / outline / link / destructive | `Button hierarchy="loud" / "quiet" / "transparent" / "destructive"` |
| Header | — | `Header` |
| Tabs mobile | Tabs | `Tabs` (e `TabsRoot`/`TabsList`/`TabsTrigger`/`TabsContent`) |
| Segmented control | Tabs / Toggle Group | `SegmentedControl` |
| List row chevron / ícone | — | `ListRow variant="help" / "menu"` |
| Shortcuts grid | — | `TileGrid` + `Tile` |
| Card | Card | `Card` (+ `CardHeader`, `CardTitle`…) |
| Textfield | Input + Label + Form | `Input`, `Label`, `TextField` |
| — | Textarea | `Textarea` |
| Searchbox | — | `SearchField` |
| Dropdown | Select | `Select` |
| Checkbox | Checkbox | `Checkbox` |
| Switch | Switch | `Switch` |
| Radio button group | Radio Group | `RadioList`, `RadioGroup` |
| Tag choice | Toggle Group | `ChoiceChips` |
| Tag, Badge pill | Badge | `Badge`, `Tag`, `StatusChip` |
| Progress indicator linear / segments | Progress | `Progress` / segmentos do `MissionBanner` / `StepDots` / `StreakProgress` |
| Accordion | Accordion | `Accordion` |
| Message (quiet) | Alert | `Message` (e `Alert`) |
| Snackbar | Toast / Sonner | `Toast` (visual, `kind` error · success · info) |
| Feedback screen (congrats) | — | `ResultScreen` |
| Pill / tag de valor | Badge | `PointsBadge`, `LevelBadge` |
| Card selecionável | Toggle | `SpaceCard` com `onSelect` (`aria-pressed`) |
| Date / time picker em chips | Toggle Group | `SlotPicker` |
| Modal | Dialog / Alert Dialog | `Modal`, `Dialog`, `AlertDialog` |
| Bottom sheet | Sheet (side bottom) | `Sheet` |
| Popover | Popover | `Popover` |
| Thumbnail | Avatar | `Avatar`, `Thumb` |
| Divider | Separator | `Separator` |
| Skeleton | Skeleton | `Skeleton` |
| `andes-color-text-primary`, `…-interactive-fill-loud-idle` | `--foreground`, `--primary` | `text-primary`, `interactive-fill-loud` |
| Spacing xnano 4 · nano 8 · micro 12 · mini 16 · xsmall 20 · small 24 · medium 32 · large 40 · xlarge 48 | — | `space-xnano` … `space-xlarge` (classes `p-mini`, `gap-nano`…). As variáveis do Andes X no Figma usam outra numeração (nano 6, xmicro 8, xtiny 16): não importe uma pela outra |

Fora de propósito: Tooltip (no celular não há hover; use `Popover`), Dropdown Menu, Command, Navigation Menu, Data Table e Calendar, que o app não usa hoje.

## Pronto para entregar

- [ ] Usa componentes do sistema; primitivos novos foram registrados.
- [ ] Nenhum hex, nenhuma classe fora das escalas do preset.
- [ ] Estados: hover, pressionado, foco, desabilitado, carregando, vazio, erro, conta nova e sucesso.
- [ ] Área tocável de 44px, rótulos acessíveis, seleção por atributo (`aria-*` ou `data-state`).
- [ ] Teclado: Tab chega em tudo; setas em abas, rádios e chips; Esc fecha sobreposições e o foco volta ao gatilho.
- [ ] Contraste 4,5:1 para texto e 3:1 para ícone, borda e controle.
- [ ] Movimento reduzido respeitado.
- [ ] Voltar leva à tela anterior real; a tela atualiza sem precisar sair e voltar.
- [ ] Validação antes de enviar: CPF válido, valor de doação até o saldo.

## A confirmar antes de implementar

- Fonte: Lexend, confirmada nas variáveis de texto do Figma (Heading, Subtitle, Paragraph). Os conceitos em Inter, Sora e Manrope foram trazidos para Lexend.
- Ícones: definidos. São Lucide, inclusive os "SVG fornecido" (recycle, chart-column, map-pin, gift). Lista e apelidos no README do `Icon`.
- Cores: vêm das variáveis do Figma (Neutral/Level 1 a 8, Highlight, Brand). Hover e pressionado continuam propostas.
- Texto laranja do Figma (#DD8613, #F36208, #E8823F) e texto branco sobre laranja reprovam contraste: o sistema usa `text-link` e `text-on-loud`. Confirme com o time antes de seguir o Figma ao pé da letra.
- Textos de 9 e 10px do Figma (endereço, chip, etiqueta) sobem para `caption` (12px).
- Pendente no Figma: card de entrega quando a data do calendário já passou (`DeliveryCard state="past"` é a proposta).
- Indicadores de impacto: o app usa uma cor por métrica no valor; essas cores não estão no sistema.
