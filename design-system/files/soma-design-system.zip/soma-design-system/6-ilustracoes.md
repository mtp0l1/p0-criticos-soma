# 6. Ilustrações

Todas as ilustrações das telas NOVO do Figma, exportadas direto de lá e guardadas em `assets/illustrations/`. As onze primeiras da tabela já vêm embutidas no bundle e saem pelo componente `Illustration` (`<Soma.Illustration name="mascote-lata-acerto" />`).

**Regras de uso**

- O prêmio do Quiz é um **troféu**, nunca uma medalha. Bronze tem 1 estrela, Prata 2 e Ouro 3. Use `Trophy`, `LevelCard`, `TierCard` ou `HistorySummary`: eles já usam a arte certa.
- O mascote da lata aparece só no resultado da resposta (`AnswerResult`): feliz no acerto, em dúvida no erro. Não use em outro lugar.
- As ilustrações são decorativas: `alt` vazio quando o texto da tela já diz o que elas mostram. Troféu leva texto alternativo ("Troféu Bronze, 1 estrela").
- Não recolora nem recorta a arte. Ela já traz o círculo de fundo (troféus e mascote) ou o próprio fundo (cenas).
- Tamanhos do Figma: troféu 96px nos cartões e no Histórico, 120px no topo do Quiz, conquista 148px, mascote 200px, convite 280×239, ranking vazio 280×210, Doar 313×280. Os arquivos são o tamanho original das telas; para uma tela maior ou impressão, peça os originais ao time de design.

## Catálogo

| Nome | Tamanho | Onde é usada | Nó do Figma | Arquivo |
|---|---|---|---|---|
| `trofeu-bronze-120` | 120×120 | LevelCard (Telas 1 e 3) | 443:15377 | `assets/illustrations/trofeu-bronze-120.png` (embutida) |
| `trofeu-bronze-96` | 96×96 | TierCard (Tela 5), HistorySummary (Tela 4) | 443:15947 | `assets/illustrations/trofeu-bronze-96.png` (embutida) |
| `trofeu-prata-96` | 96×96 | TierCard (Tela 5), HistorySummary, LevelCard | 443:15956 | `assets/illustrations/trofeu-prata-96.png` (embutida) |
| `trofeu-ouro-96` | 96×96 | TierCard (Tela 5), HistorySummary, LevelCard | 443:15965 | `assets/illustrations/trofeu-ouro-96.png` (embutida) |
| `conquista-bronze-148` | 148×148 | MilestoneResult (Telas 7 e 8) | 443:16155 | `assets/illustrations/conquista-bronze-148.png` (embutida) |
| `mascote-lata-acerto` | 200×200 | AnswerResult correct (Tela 2A) | 443:15533 | `assets/illustrations/mascote-lata-acerto.png` (embutida) |
| `mascote-lata-erro` | 200×200 | AnswerResult correct=false (Tela 2B) | 443:15867 | `assets/illustrations/mascote-lata-erro.png` (embutida) |
| `convite-pontos` | 280×239 | Tela Convidar amigos (Ranking e Social, Tela 9) | 443:18548 | `assets/illustrations/convite-pontos.png` (embutida) |
| `ranking-vazio` | 280×210 | Estado vazio do ranking de amigos (Tela 8) | 443:19642 | `assets/illustrations/ranking-vazio.png` (embutida) |
| `doar-sucesso` | 313×280 | Sucesso da doação | 463:4740 | `assets/illustrations/doar-sucesso.png` (embutida) |
| `doar-saldo-insuficiente` | 80×80 | Doação: saldo insuficiente | 463:4263 | `assets/illustrations/doar-saldo-insuficiente.png` (embutida) |
| `confete-entrega` | 390×908 | Tela Entrega registrada (Ativação, Tela 12) | 443:13640 | `assets/illustrations/confete-entrega.png` |
| `instituicao-logo` | 64×64 | InstitutionCard | 463:4257 | `assets/illustrations/instituicao-logo.png` |
| `instituicao-banner` | 320×160 | Modal da instituição | 463:5057 | `assets/illustrations/instituicao-banner.png` |

## Descrição de cada uma

- **Troféu Bronze (selo grande)** (`trofeu-bronze-120`): Nível Bronze, 1 estrela. Topo do Quiz.
- **Troféu Bronze** (`trofeu-bronze-96`): Nível Bronze, 1 estrela.
- **Troféu Prata** (`trofeu-prata-96`): Nível Prata, 2 estrelas.
- **Troféu Ouro** (`trofeu-ouro-96`): Nível Ouro, 3 estrelas.
- **Conquista de sequência** (`conquista-bronze-148`): Troféu Bronze com 4 estrelas de contorno em volta.
- **Mascote da lata: acertou** (`mascote-lata-acerto`): Lata feliz, braços para cima, cidade ao fundo.
- **Mascote da lata: errou** (`mascote-lata-erro`): Lata em dúvida, gota de suor e interrogação.
- **Convidar amigos** (`convite-pontos`): Duas pessoas segurando uma moeda grande com estrela.
- **Ranking vazio** (`ranking-vazio`): Pódio com avatar no topo e vagas tracejadas.
- **Doação concluída** (`doar-sucesso`): Duas pessoas batendo as mãos (high five).
- **Saldo insuficiente** (`doar-saldo-insuficiente`): Símbolo de reciclagem laranja em círculo claro.
- **Confete da entrega registrada** (`confete-entrega`): Confete laranja e rosa, 390x908, por cima da tela cheia. Fundo transparente.
- **Logo de instituição (exemplo)** (`instituicao-logo`): Imagem de exemplo 64x64 do cartão de instituição.
- **Banner de instituição (exemplo)** (`instituicao-banner`): Foto de exemplo 320x160 do modal da instituição.

## Não são ilustrações

- **Logos de instituição** (Doar, nós 463:4362 a 463:4406): são quadrados de 40px com borda e um ícone Lucide dentro, não imagens. Cufa = `shopping-bag`, Ação da Cidadania = `heart`, Mesa Brasil Sesc = `utensils`, Instituto Esporte e Educação = `award`, Gol de Letra = `sport`, APAE = `users`, Assoc. São Francisco = `heart`.
- **Foto de recompensa e de instituição**: são imagens de conteúdo do parceiro, chegam do back-end. `instituicao-logo` e `instituicao-banner` são só exemplos do Figma.
- **Capturas das telas atuais** ("ATUAL") ficam no Figma só como comparação e não entram no sistema.

## Como pedir as artes em tamanho maior

O Figma entrega estas imagens no tamanho em que estão aplicadas nas telas. Se o produto precisar de 2x ou 3x (telas densas, impressão), peça ao time de design os arquivos originais dos nós listados na tabela e substitua os PNG em `assets/illustrations/` mantendo os nomes; depois rode a geração para atualizar o bundle.
