# Relatório das verificações

Gerado em 12/11/2026. Quem gera: `checks/ds_checks.py` (regras estáticas), `checks/axe.js` (ACC-01) e `checks/touch.js` (ACC-02).

| ID | Resultado | Detalhe |
|---|---|---|
| TOK-03 | OK | 34 pares de token medidos |
| TOK-03 | Exceção registrada | exceção registrada em excecoes.json: selected-indicator sobre surface-primary = 2.00:1 (mínimo 3.0:1) |
| TOK-01 | OK | toda classe de cor e medida existe no CSS gerado |
| TOK-02 | OK | nenhum hex, rgb ou hsl nos componentes |
| TOK-04 | OK | todo texto está na escala 12/14/16/18/20/24/32 |
| TOK-04b | OK | estilos de texto fora da escala: tab-label (esperado só tab-label, exceção documentada) |
| TOK-05 | OK | raios só da escala (4, 8, 12, 16, 24, pílula) |
| SPC-01 | OK | 13 medidas fora da escala, todas já listadas em excecoes.json |
| CTR-01 | OK | 123 componentes com contrato (Usar para, Nunca, Verificado por) |
| CAT-01 | OK | 123 componentes com categoria |
| IDX-01 | OK | todo componente está no índice da doc 1 |
| NAME-01 | OK | 185 nomes `Soma.X` citados nas docs existem na API |
| DEC-01 | OK | mapa de decisão em dia com os contratos |
| ACC-01 | OK | 146 visualizações no axe (WCAG 2.2 AA e boas práticas): 0 violações, 0 erros de console |
| ACC-02 | OK | 460 controles tocáveis medidos a 360px: 0 abaixo de 44×44px |

## Exceções abertas

Ficam em `checks/excecoes.json`, cada uma com motivo. O número só pode cair.

- SPC-01: 13 medidas fora da escala (ajustes ópticos do Figma no Quiz, ícones e pílulas).
- TOK-03, selected-indicator sobre surface-primary: Indicador laranja da aba e do ponto atual tem 2,00:1. A aba ativa também muda para negrito e texto escuro, mas o ponto do carrossel só muda de cor. Decisão aberta com Claudia e Tatiana: escurecer o indicador (orange-deep) ou manter.
- TOK-04: `tab-label` (11px) na TabBar, para caber os cinco rótulos em 360px.
- TOK-05: `rounded-[inherit]` na área de rolagem (herda o raio do contêiner).
