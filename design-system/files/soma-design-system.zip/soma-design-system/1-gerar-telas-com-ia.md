# Gerar telas com IA

Roteiro, índice de componentes, sinônimos e prompt base para desenhar telas com IA.

## Visão geral

Roteiro para qualquer IA (Claude, Claude Design, IA do Figma, Claude Code) desenhar telas de qualquer produto do ecossistema So+ma com o Campana. Cole a seção "Prompt base" junto do pedido. Comece pelo `AGENTS.md`.

O sistema segue a versão 2 do app, a referência oficial (Padrões › Telas da v2). Componentes e telas da versão anterior foram removidos e não devem ser recriados. O que ainda é só proposta (PROPOSTA no Figma) está listado em "histórico de versões", junto do mapa tela → componentes. Para um produto novo, comece pelo núcleo e adicione módulos só se a funcionalidade existir (veja "Para qualquer produto").

## Processo em quatro fases

**Fase 0. Idear a tela como árvore.** Antes de abrir qualquer ferramenta, escreva a tela como lista de camadas, de cima para baixo:

```
Tela: Reciclar (fundo background-primary)
  ├── "Reciclar" (screen-title)
  ├── SectionHeader "Sua próxima entrega" → DeliveryCard state=scheduled
  ├── SectionHeader "O que posso reciclar" → SearchField + ChoiceChips variant=soft
  ├── SectionHeader "Espaços de recebimento perto de você" → SpaceCard × n
  └── TabBar active=reciclar

```

**Fase 1. Casar cada camada com o índice.** Para cada linha, marque a fonte antes de construir:

```
├── Header          → ✅ Header
├── Resumo          → ✅ StatTile (layout row)
├── Mapa dos espaços → ⚠️ não existe → ##SpaceMap## (primitivo, justificar)

```

Regra da porta: não construa enquanto houver ⚠️ sem justificativa. Procure pelo sentido, não pelo nome exato (veja "Sinônimos").

**Fase 2. Construir.** Só componentes de `window.Soma`, estilos de texto e tokens semânticos. Em código, classes Tailwind só das escalas do preset (`p-mini`, `gap-nano`, `bg-surface-accent`, `rounded-lg`) e `cn()` para juntar. Auto-layout em tudo, sem posição absoluta e sem frames vazios como espaçador: o espaço vive no gap e no padding (`space-*`). Primitivo novo leva o nome `##NomeDoComponente##`.

**Fase 3. Conferir e anotar.** Rode a checagem do fim desta página e preencha o handoff.

## Índice de componentes

Cada componente tem contrato no README (Usar para, Nunca, Verificado por). Para achar pela necessidade da tela, use o `decision-map.md`.

| Componente | Para quê | Props principais |
|---|---|---|
| `Button` | Ação | `hierarchy` loud · quiet · transparent · destructive, `size` large · compact, `fullWidth`, `icon`, `loading`, `asChild` |
| `Icon` / `IconButton` | Ícone Lucide / ação só com ícone | `name`, `size`, `tone`, `label` |
| `Header` | Topo da tela | `title`, `onBack`, `action`, `variant` center · round · start, `divider` |
| `HomeGreeting` | "Olá {nome}" + QR + ajuda (Início) | `name`, `onQr`, `onHelp` |
| `LocationBar` | "Entregando em {local}", uma linha | `location` (vazio vira chamada), `sticky` |
| `TabBar` | Navegação inferior fixa | `active` inicio · reciclar · recompensas · impacto · menu |
| `Tabs` | Filtro do mesmo conteúdo (período) | `items`, `value`, `label` |
| `SegmentedControl` | Alternar seções (Quiz / Histórico) | `items`, `value`, `label` |
| `PillTabs` | Catálogo / Meus resgates | `items`, `value`, `label` |
| `SectionHeader` | Título de bloco + link | `title`, `action` |
| `Tile` + `TileGrid` | Atalhos da Home | `icon`, `label` |
| `BalanceCard` | Saldo de pontos | `points`, `hint`, `tone` light · dark, `action` |
| `QuestionTeaser` | "Pergunta do dia" no Início (sob um `SectionHeader`) | `question`, `hint`, `href` |
| `GoalSummaryCard` | Meta ativa no Início | `title`, `goal`, `remaining`, `icon`, `href` |
| `ActivityRow` | Atividade recente | `title`, `detail`, `icon`, `action` |
| `LevelCard` | Nível atual do quiz (troféu grande): Bronze, Prata ou Ouro | `tier`, `remaining` |
| `QuestionCard` | Pergunta do dia (Quiz) | `question`, `options`, `value`, `onSubmit`, `points`, `info`, `submitting` |
| `AnswerResult` | Resultado da pergunta, tela cheia | `correct`, `answer`, `explanation`, `points`, `weeks`, `art`, `onContinue`, `secondary` |
| `DailyDone` | "Tarefa cumprida!" | `title`, `children`, `countdown` |
| `MilestoneResult` | Conquista de semanas seguidas | `weeks`, `points`, `nextReward`, `onContinue` |
| `ProtectionNotice` | Proteção semanal da sequência | `variant` inline · card, `onInfo` |
| `HistorySummary` + `AnswerHistory` | Histórico do quiz | `tier`, `total`, `last` · `month`, `onPrev`, `onNext`, linhas `AnswerHistoryRow` |
| `LevelBadge` | Selo "BRONZE" / "Iniciante" | `tier`, `kind` name · level |
| `PointsBadge` | "+15 pontos" | `points`, `kind` gain · cost |
| `StreakTrail` | Semana do quiz | `days[{label,state}]` done · protected · today · future |
| `StreakSection` | Bloco "Sua trilha" (dias, semanas, proteção, "Ver histórico") | `days`, `weeks`, `nextReward`, `protection`, `onHistory` |
| `StreakProgress` | Sequência em semanas, marcos 1·5·10·20 | `weeks`, `nextReward`, `hideLabel` |
| `Trophy` + `TierCard` | Troféu do nível e a lista de níveis (Bronze, Prata, Ouro) | `tier`, `size` md · lg · `tier`, `current`, `questions` |
| `Illustration` | Qualquer ilustração do sistema pelo nome (mascote da lata, troféus, conquista, Doar, convite, ranking vazio) | `name`, `size`, `alt` |
| `StatTile` + `StatGrid` | Indicador de impacto | `icon`, `lead`, `value`, `equivalence`, `layout` |
| `PositionCard` | "Você reciclou mais que X%" | `percent` (null = sem entrega) |
| `FriendRequestSheet` | Pedido de amizade recebido (bottom sheet) | `name`, `open`, `onAccept`, `onDecline` |
| `RankingStarterCard` | "Sua jornada começa na 1ª entrega" (0 kg no período) | `onAction` |
| `Podium` | Três primeiros | `entries[{position,name,kg,self,initials,photo,anonymous}]` |
| `ImpactTiles` | Três números da entrega | `title`, `items[{value,label,highlight}]`, `onShare` |
| `RankingRow` + `RankingList` | Linha da classificação | `position`, `name`, `kg`, `self`, `initials`, `hint` |
| `StatsRow` | Números lado a lado | `items[{value,label,icon}]` |
| `DeliveryCard` | "Sua próxima entrega" | `state` empty · scheduled · past, `space`, `date`, `address`, `onAction` |
| `SpaceCard` | Espaço de recebimento: na lista "perto de você", como opção do agendamento e da troca, ou como espaço atual. | mostrar uma opção sem endereço. |
| `SlotPicker` | Escolha de data ou horário no agendamento da entrega, em grade ou fileira. | mostrar horário fechado sem marcar "indisponível" para o leitor de tela. |
| `GoalCard` | Minha meta no catálogo (tocável) | `reward`, `points`, `goal`, `missingKg`, `onPress` |
| `CampaignBanner` | Campanha ativa, faixa de uma linha | `children`, `icon` |
| `RewardRow` | Item do catálogo | `title`, `points`, `tags`, `current`, `icon` |
| `RedeemCode` | Código do resgate | `code`, `validity`, `hint`, `onCopy` |
| `RewardDetail` | Detalhe da recompensa | `category`, `title`, `points`, `tags`, `source`, `image` |
| `InstitutionCard` | Quem recebe a doação | `name`, `description`, `image`, `onMore` |
| `RedemptionItem` + `RedemptionGroup` | Histórico de resgates | `title`, `points`, `time`, `status`, `logo` |
| `QrCheckinCard` | QR de atendimento | `qr`, `name`, `steps` |
| `SpaceDetail` | Painel de detalhe de um espaço. O agendamento da v2 não usa mais: prefira SpaceCard com SpaceMapSheet. | usar no agendamento. |
| `SpacePickerSheet` | Folha "Escolha seu espaço", para trocar o espaço de recebimento. | confirmar a troca sem uma escolha. |
| `SpaceMapSheet` | Folha "Como chegar" do espaço tocado, com mapa ilustrativo. | mostrar outro espaço que não o tocado. |
| `InviteCodeCard` + `ContactRow` | Convidar amigos | `code`, `onCopy` · `name`, `space`, `status`, `onInvite` |
| `SearchField` | Busca | `label`, `value` |
| `MaterialResult` | Resultado de material | `name`, `accepted`, `recyclable`, `category` |
| `ListRow` | Linha de ajuda / de menu | `variant` help · menu, `title`, `description`, `icon` |
| `HelpfulVote` | Pergunta "Isso ajudou?" com Sim e Não, ao fim de um artigo de ajuda. | `value` |
| `Tag` | Categoria | `icon` |
| `StatusChip` | Status de resgate | `status` done · pending · expired |
| `TextField` | Campo de formulário | `label`, `helper`, `error`, `inputMode` |
| `ChoiceChips` | Escolha única em pílula (valor, categoria, material) | `options[{value,label,icon}]`, `value`, `variant` outline · soft, `scroll` |
| `RadioList` | Escolha única em lista | `options`, `value` |
| `Modal` | Confirmação ou escolha com uma ação | `title`, `actionLabel`, `open`, `trigger` |
| `Dialog` (primitivas) | Diálogo com conteúdo ou ações próprias | `DialogContent`, `DialogHeader`, `DialogFooter` |
| `AlertDialog` | Confirmar sair, apagar, desfazer | `AlertDialogAction hierarchy="destructive"`, `AlertDialogCancel` |
| `Sheet` | Bottom sheet para escolha rápida | `SheetContent`, `SheetTitle` |
| `Popover` | Balão de ajuda curta ao tocar no (i) | `PopoverTrigger`, `PopoverContent aria-label` |
| `Accordion` | Perguntas frequentes | `type` single · multiple |
| `Card` | Contêiner de conteúdo | `variant` outline · flat · accent · inverse |
| `Badge` | Selo não interativo | `tone` |
| `Avatar` | Foto ou iniciais | `size` medal · thumb · avatar |
| `Progress` | Barra de progresso | `value`, `label` |
| `Separator` | Divisória | `orientation` |
| `Input` + `Label` | Campo solto | `type`, `inputMode` |
| `Textarea` | Texto longo | `rows` |
| `Select` | Lista suspensa longa (estado, cidade) | `SelectTrigger`, `SelectItem` |
| `Checkbox` | Aceite, preferências independentes | `checked`, `onCheckedChange` |
| `Switch` | Liga e desliga imediato | `checked`, `onCheckedChange` |
| `Toast` | Aviso passageiro | `message`, `kind` error · success · info |
| `Message` | Aviso que fica na tela | `tone` informative · positive · caution · negative |
| `EmptyState` | Nada para mostrar | `title`, `description`, `action` |
| `ResultScreen` | Sucesso, erro ou permissão no fim de um fluxo | `tone`, `title`, `description`, `primaryAction`, `secondaryAction`, `onHome` |
| `Skeleton` | Carregando | `variant` text · row · card, ou bloco livre com `className` |
| `Spinner` | Espera em trecho pequeno | `label` |
| `Toaster` + `notify()` | Dispara avisos com fila e tempo | `notify(mensagem, { kind })` |
| `Field` (+ `FieldLabel`, `FieldDescription`, `FieldError`, `FieldSet`, `FieldGroup`) | Estrutura de campo | `orientation`, `invalid`, `disabled` |
| `InputGroup` | Campo com ícone, texto ou botão | `InputGroupInput`, `InputGroupAddon align` |
| `InputOTP` | Código de verificação | `maxLength`, `value`, `InputOTPSlot index` |
| `NativeSelect` | Lista simples no seletor do aparelho | `<option>` |
| `Combobox` | Lista longa com busca (cidade) | `options`, `value`, `placeholder`, `searchPlaceholder`, `emptyText` |
| `Command` | Lista com busca e teclado | `CommandInput`, `CommandList`, `CommandItem` |
| `Slider` | Valor ou faixa arrastando | `value[]`, `min`, `max`, `step` |
| `Toggle` / `ToggleGroup` | Liga e desliga; escolha única ou múltipla | `pressed`, `type` single · multiple, `variant` ghost · outline |
| `ButtonGroup` | Botões colados | `orientation` |
| `DropdownMenu` | Menu de ações de um item | `DropdownMenuItem variant`, `CheckboxItem`, `RadioItem` |
| `Drawer` | Bottom sheet com gesto de arrastar | `DrawerContent`, `DrawerTitle`, `DrawerFooter` |
| `Carousel` | Slides por gesto | `label`, `CarouselItem`, `CarouselDots` |
| `Collapsible` | Um trecho que abre e fecha | `open`, `CollapsibleTrigger` |
| `Table` | Tabela simples (extrato) | `TableHeader`, `TableRow`, `TableCell` |
| `Pagination` | Páginas de uma lista | `PaginationLink isActive` |
| `ScrollArea` | Rolagem dentro de um bloco | altura por `className` |
| `AspectRatio` | Proporção fixa de imagem ou mapa | `ratio` |
| `AccountExistsSheet` | Número já cadastrado (passo do celular) | `phone`, `onSignIn`, `onUseOther` |
| `SignupStep` | Corpo de um passo do cadastro (um dado por tela) | `title`, `description`, `step`, `total`, `action` |
| `PasswordField` | Senha com mostrar e ocultar | `label`, `value`, `onChange`, `error` |
| `TermsConsent` | Aceite do regulamento e da privacidade | `checked`, `onCheckedChange`, `regulationHref`, `privacyHref` |
| `InviteCodeField` | Código de convite opcional | `value`, `onChange`, `applied`, `error`, `onHelp` |
| `InviteCodeHelpSheet` | "Onde encontro o código?" | `sender`, `code` |
| `InviteMessageExample` | Simulação da mensagem de convite | `sender`, `code` |
| `NeighborhoodNote` | Bairro achado pelo CEP | `neighborhood`, `onFix` |
| `RewardChoiceList` | Escolha da meta no cadastro | `label`, `options`, `value`, `onChange` |
| `DeliveryDayCard` | Espera no dia da entrega | `title`, `address`, `hours` |
| `DeliveryHistoryRow` | Entrega anterior em Meus agendamentos | `space`, `date`, `status` |
| `DeliverySummaryCard` | Resumo do agendamento | `date`, `time`, `space`, `address`, `onDirections`, `notice` |
| `ReminderCard` | Lembrete da próxima entrega | `title`, `description`, `date`, `added`, `onAdd` |
| `GoalNote` | Nota "Sua meta" na Entrega registrada | sem props |
| `GoalProgressCard` | Progresso da meta escolhida | `points`, `goal`, `missingKg` |
| `InstitutionRow` | Instituição na lista de doação | `name`, `description`, `icon`, `href`, `onPress` |
| `InstitutionDetailModal` | Modal "Saber mais" da instituição | `name`, `description`, `address`, `phone`, `site`, `image`, `trigger` |
| `DonationAmountCard` | Valor da doação: número grande, saldo e erro em espaço reservado, com NumericKeypad. | esconder o saldo nem mover o botão quando o erro aparece. |
| `DonationStateCard` | Estado que toma o lugar do valor da doação quando a pessoa não pode doar ainda. | aparecer junto do valor da doação. |
| `ShareImpactModal` | Compartilhar meu impacto | `stats`, `options`, `trigger` |

## Sinônimos

| Se o pedido diz… | Use |
|---|---|
| botão, CTA, ação | `Button` |
| link, "ver mais", "ver níveis" | `Button hierarchy="transparent"` |
| navbar, topo, app bar | `Header` |
| seletor de local, endereço, unidade | `LocationBar` |
| bottom nav, menu inferior | `TabBar` |
| streak, ofensiva, dias seguidos, trilha da semana | `StreakTrail` + `StreakProgress` |
| pontos que vale, recompensa da pergunta | `PointsBadge` |
| selo bronze/prata/ouro | `LevelBadge` |
| lista do ranking, amigos, leaderboard | `RankingRow` |
| próxima entrega, agendamento marcado | `DeliveryCard` |
| ecoponto, ponto de coleta, espaço, unidade | `SpaceCard` |
| calendário, data, horário, slot | `SlotPicker` |
| meta, objetivo de pontos | `GoalCard` |
| campanha, promoção, 2× pontos | `CampaignBanner` |
| item do catálogo, produto, cupom | `RewardRow` |
| cupom, voucher, código | `RedeemCode` |
| ONG, instituição, causa | `InstitutionCard` |
| tela de sucesso, confirmação final, permissão | `ResultScreen` |
| abas, filtro de período | `Tabs` |
| toggle, pílula de seções | `SegmentedControl` · `PillTabs` (Recompensas) |
| atalho, card de menu da Home | `Tile` |
| saldo, pontos | `BalanceCard` |
| saudação, "Olá", nome na Home | `HomeGreeting` |
| nível, troféu, badge de nível | `LevelCard`, `Trophy`, `TierCard`, `LevelBadge` |
| ilustração, mascote, arte | `Illustration` (lista em `6-ilustracoes.md`) |
| pergunta, quiz, alternativas | `QuestionCard` (no Início, `QuestionTeaser`) |
| resposta certa, errou, resultado do quiz | `AnswerResult` |
| meta no Início, quanto falta | `GoalSummaryCard` |
| atividade recente, últimas entregas | `ActivityRow` |
| números da entrega, impacto da entrega | `ImpactTiles` |
| convidar amigo, código de convite | `InviteCodeCard`, `ContactRow` |
| pedido de amizade, aceitar amigo | `FriendRequestSheet` |
| aviso "subiu no ranking", "amigo entrou" | `Toast surface="card"` via `notify(..., { position: 'top-center' })` |
| métrica, KPI, indicador, card de impacto | `StatTile` |
| posição, colocação | `PositionCard`, `Podium`, `RankingRow` |
| histórico, extrato de resgates | `RedemptionItem` |
| QR, atendimento, check-in | `QrCheckinCard` |
| busca, pesquisa | `SearchField` + `MaterialResult` |
| item de lista, FAQ, opção de menu | `ListRow` |
| tag, etiqueta, categoria | `Tag` |
| status, selo de estado | `StatusChip` |
| input, campo, formulário | `TextField` |
| chips de valor, seletor de valor | `ChoiceChips` |
| radio, opções | `RadioList` |
| dialog, popup | `Modal` (uma ação) ou `Dialog` |
| confirmar, tem certeza | `AlertDialog` |
| bottom sheet, gaveta, drawer | `Sheet` |
| tooltip, dica, (i) | `Popover` |
| FAQ, perguntas, sanfona | `Accordion` |
| dropdown, combo, lista de estados | `Select` |
| aceite, termos, caixa de seleção | `Checkbox` |
| toggle de configuração, notificação | `Switch` |
| foto de perfil | `Avatar` |
| card, painel, caixa | `Card` |
| barra de progresso | `Progress` |
| divisor, linha | `Separator` |
| comentário, sugestão, texto longo | `Textarea` |
| snackbar, erro rápido, "copiado" | `Toast` |
| banner de aviso, alerta, info | `Message` |
| tela vazia, sem resultado | `EmptyState` |
| loading, shimmer | `Skeleton` |
| spinner, carregando pequeno | `Spinner` |
| código SMS, OTP, PIN, verificação | `InputOTP` |
| autocomplete, select com busca, cidade | `Combobox` |
| três pontinhos, mais ações, menu de contexto | `DropdownMenu` |
| favoritar, botão de alternar, filtro múltiplo | `Toggle`, `ToggleGroup` |
| stepper de quantidade, botões grudados | `ButtonGroup` |
| range, barra de arrastar | `Slider` |
| banner rotativo, onboarding em slides | `Carousel` |
| ver mais, mostrar detalhes | `Collapsible` |
| extrato, tabela | `Table` |
| campo com prefixo, sufixo, R$, botão de limpar | `InputGroup` |
| gaveta com gesto, swipe para fechar | `Drawer` |

## Decisões padrão

- Ênfase: um `loud` por tela; o resto `quiet` ou `transparent`.
- Fundo: telas de lista e fluxo em `background-primary`; telas de painel com cards (Meu impacto, Ranking) em `background-secondary`.
- Margem lateral `space-xsmall` (20px); do cabeçalho ao conteúdo e entre blocos `space-small` (24px); entre título de bloco e conteúdo `space-nano`; do último bloco ao botão principal `space-medium` (32px); botões empilhados a `space-nano`. Em tela de resultado, o ícone fica a `space-large` (40px) do cabeçalho.
- Largura de referência: 390px, a das telas de menor largura (a referência da v2 é 390px; vale de 360 a 430px, com margem fixa e conteúdo que estica). O sistema é mobile-first.
- Título de tela raiz de aba ("Reciclar") em `screen-title` à esquerda, sem `Header`; telas internas usam `Header`.
- Fluxo que termina (doação, resgate, agendamento) acaba em `ResultScreen` com "Ir para o início".
- Ação principal de modal, formulário e bottom sheet: `Button fullWidth`.
- Toda tela principal tem `Header` e `TabBar`; modal e fluxo de etapas não têm `TabBar`.

## Estados que toda tela precisa

Desenhe e entregue os cinco, não só o caminho feliz:

1. **Conta nova / zero.** Saldo 0, nenhuma entrega, sem local: textos de primeira vez e chamada para a primeira entrega.
2. **Carregando.** `Skeleton` do tamanho do conteúdo.
3. **Vazio.** `EmptyState` com saída real.
4. **Erro.** `Toast` para falha passageira; `Message tone="negative"` para o que precisa ficar.
5. **Sucesso.** Resultado visível na própria tela depois de fechar o modal.

## Regras e anti-padrões

| ❌ Não | ✅ Sim |
|---|---|
| `#FFA125`, `orange` direto na tela | `interactive-fill-loud` (`bg-primary`), `selected-indicator`, `icon-brand` |
| `p-4`, `bg-orange-500`, `text-sm` | `p-mini`, `bg-primary`, classe `body` |
| Tooltip ao passar o dedo | `Popover` ao tocar |
| Estado só com classe (`.ativo`) | Atributo: `aria-current`, `aria-pressed`, `data-state` |
| `opacity-50` no desabilitado | `interactive-fill-disabled` + `interactive-text-disabled` |
| Texto branco sobre laranja | `text-on-loud` (navy) |
| Texto laranja claro sobre branco (#DD8613, #F36208, #E8823F da versão anterior) | `text-link` |
| Inter, Sora ou Manrope (conceitos antigos) | Lexend, a única família |
| Texto de 9 ou 10px (endereço, chip) | `caption` (12px); só `tab-label` fica abaixo de 12px |
| Paleta própria por fluxo (cinza quente no Ranking, bege na Ativação) | Os mesmos tokens em todo o produto; veja Fundamentos › Cores |
| `padding: 13px`, `gap: 10px` | `space-micro` (12), `space-nano` (8) |
| Sombra solta, preta ou fora dos seis níveis | Elevação do sistema: `shadow-card` no cartão e no botão claro, `shadow-dark` no botão escuro, `shadow-glow` só no primário; sombra preta ou solta não |
| Dois `loud` lado a lado | Um `loud` + um `quiet` |
| "<" e "Fechar" no mesmo cabeçalho | Uma saída, que volta à tela anterior real |
| Estado só em cor | Ícone + palavra |
| Modal pequeno de "resposta correta" | `AnswerResult` em tela cheia |
| Níveis Ferro e Platina, `LevelList`, `LevelCard` com barra | `LevelCard` e `TierCard` só com Bronze, Prata e Ouro |
| Banner "Ganhe suas medalhas" na Home | `QuestionTeaser` |
| Sequência em dias | Sequência em semanas (`StreakProgress`) |
| "Sem preferência de espaço" como local | `LocationBar` vazia, que chama para adicionar |
| "Sua posição: Nenhuma" | `PositionCard percent={null}` |
| "Item não encontrado :(" | "Nenhum material encontrado" + saída |
| WhatsApp como contato | "Enviar e-mail" |
| Toast vermelho para aviso neutro | `Toast kind="info"` ou `Message` |
| Tooltip, hover card, menu de contexto por toque longo | `Popover`, `DropdownMenu` |
| Frame vazio como espaçador | Gap e padding |
| Componente novo sem nome | `##NomeDoComponente##` e registro no handoff |

## Prompt base

```
Desenhe [tela] do produto [nome do produto] usando o design system Campana.
- Use só os componentes do índice (window.Soma) e os tokens semânticos (text-*, surface-*, interactive-*, feedback-*, border-*) ou os aliases de compatibilidade (primary, accent, ring…). Nada de hex ou px fora da grade de 4px.
- Em código: estrutura de componentes React, classes Tailwind só do preset do Campana, estados por atributo (aria-*, data-state) e hover, pressionado, foco e desabilitado em todo controle.
- Antes de construir, liste a tela como árvore de camadas e marque cada camada com o componente (✅) ou ##Primitivo## (⚠️ com motivo).
- Um botão loud por tela, rótulo navy sobre laranja. Sentence case. "Tocar", "participante", "espaço de recebimento", "Enviar e-mail".
- Entregue os estados: conta nova/zero, carregando, vazio, erro e sucesso.
- Largura 360px, margem lateral 20px, área tocável mínima 44px, contraste 4,5:1. Fonte Lexend, ícones Lucide pelos nomes do sistema.
- No fim, preencha o handoff: componentes usados, primitivos criados, estados, interações e textos.
Objetivo da tela: [o que a pessoa precisa conseguir fazer]
Conteúdo real: [dados, textos, números]

```

## Checagem final

- [ ] Todo elemento é componente do índice ou `##Primitivo##` justificado.
- [ ] Só tokens semânticos; nenhum hex; espaços da grade de 4px.
- [ ] Um `loud`; nenhum texto branco sobre laranja; laranja em texto só como `text-link`.
- [ ] Controles com 44px; contraste 4,5:1 (texto) e 3:1 (ícone, borda).
- [ ] Textos em sentence case, sem emoticon, com verbo de toque.
- [ ] Os cinco estados desenhados.
- [ ] Voltar leva à tela anterior real.
- [ ] Rodou `checks/run.sh` e nenhuma regra falhou (veja `7-regras-e-verificacoes.md`). Peça nova passou pela triagem.

## Handoff

```
HANDOFF · [nome da tela]
Componentes: [lista com variantes, ex.: Button loud fullWidth "Enviar resposta"]
Primitivos: ##Nome## — o que é, por que não há componente, medidas e tokens
Estados: conta nova · carregando · vazio · erro · sucesso (o que muda em cada)
Interações: [elemento] → [o que acontece]; voltar → [tela]
Textos: [lista final, com variáveis entre chaves]
Dados: [campo → origem; regras, ex.: "valor ≤ saldo"]
Notas para engenharia: [eventos de analytics, regras de negócio a confirmar]

```
