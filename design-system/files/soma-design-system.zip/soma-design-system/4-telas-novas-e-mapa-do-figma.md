# Telas novas e mapa do Figma

Como o sistema encontra as telas novas do arquivo "So+ma Vantagens – Pontos críticos e novos conceitos" (Figma `AMfte9XW4rEFYw18xjeeBC`). Use esta página no handoff: para cada tela, quais componentes a montam; para cada hex do arquivo, qual token usar.

## O que mudou para alinhar com o Figma

Só o necessário. Nenhum componente foi removido; o que mudou de desenho ganhou `version="anterior"` para o app em produção.

| Área | Antes | Agora |
|---|---|---|
| Barra inferior | Início · Recompensas · Resgates · Impacto · Menu | Início · **Reciclar** · Recompensas · Impacto · Menu (`version="anterior"` mantém Resgates). Ativo em #A64B00, peso 600 |
| Laranja de texto (`orange-deep`) | #B05A00 | #A64B00, o do item ativo no Figma; agora passa também sobre `surface-secondary` |
| Texto principal | navy #1E2A3B | `ink` #21344E (Neutral/Level 3). O navy continua no texto sobre o botão laranja |
| Texto de apoio | #585F69 | #5C7089 |
| Divisor e trilho | #D9DCE1 | #DDE4EE (Neutral/Level 6) |
| Fundo e card | #FFFFFF | `paper` #FDFEFF (Neutral/Level 8) |
| Destaque | — | `highlight` #FFA125: `border-highlight`, `selected-indicator` |
| Novos tokens | — | `surface-track`, `indicator-inactive`, `surface-info`, `icon-info`, `award-gold`, `award-silver`, `award-bronze` |
| Tipografia | 3 pesos; page-title 22/28; body 15/22; caption 13/18 | 4 pesos (700 entra); estilos do Figma: `page-title` 24/32, `screen-title` 20/28, `subtitle` 16/24, `body` 16/24, `body-small` 14/20, `caption` 12/16 |
| Espaço de tela | margem 16, blocos a 32 | margem 20 (`space-xsmall`), blocos a 24 (`space-small`), botão a 32 do último bloco |
| Ícones | Lucide provisório, 1,75px | Lucide definitivo (é o set do Figma), 2px, ~90 nomes e apelidos do Figma |
| Componentes novos | — | `StepDots`, `LevelBadge`, `PointsBadge`, `StreakTrail`, `StreakProgress`, `RankingRow`, `StatsRow`, `DeliveryCard`, `SpaceCard`, `SlotPicker`, `GoalCard`, `CampaignBanner`, `RewardRow`, `RedeemCode`, `InstitutionCard`, `ResultScreen` |
| Componentes com versão | — | `TabBar`, `SectionHeader`, `QuestionCard`, `Podium` (`version` atual · anterior) |
| Componentes ampliados | — | `Header` (`variant` center · round · start, `divider`), `ChoiceChips` (ícone, `variant="soft"`, `scroll`), `Toast` (`kind` success · info), `Progress` (`indicatorClassName`) |

## Tela do Figma → componentes

| Seção / tela (nó) | Componentes |
|---|---|
| Quiz (477:20539) | `Header variant="round"`, `SegmentedControl`, `LevelCard`, `LevelBadge`, `StreakTrail`, `StreakProgress`, `QuestionCard points`, `PointsBadge`, `Modal`/`Sheet` (acertou, errou, proteção, conquistas), `ResultScreen` (novo nível) |
| Ranking (478:10126) e Telas 9, 14–16 | `Header variant="start"`, `SegmentedControl` (período), `Tabs` (Amigos · Meu espaço · Geral), `Podium`, `RankingList` + `RankingRow`, `Button quiet` "Encontrar amigos nos contatos", `ResultScreen tone="neutral"` (permissão e permissão negada), `EmptyState` |
| Recompensas, home-campaign-on (477:22160) | `SegmentedControl` (Catálogo · Meus resgates), `GoalCard`, `CampaignBanner`, `ChoiceChips scroll` com ícones, `RewardRow`, `Sheet` (confirmar resgate), `ResultScreen` + `RedeemCode`, `RedemptionItem` |
| Doar pontos (478:12858, 478:12927) | `Header`, `InstitutionCard`, `Card`, `TextField`, `Button`, `Sheet` (confirmação), `ResultScreen`, `Toast` |
| Cadastro, 01 Nome e data (476:7330) | `Header` "Cadastro" + ajuda, `TextField`, `Checkbox`, `Button`, `StepDots`, `Sheet` |
| Aba Reciclar (478:14928) | `screen-title`, `SectionHeader`, `DeliveryCard`, `SearchField`, `ChoiceChips variant="soft"`, `SpaceCard`, `TabBar active="reciclar"` |
| Ativação, escolha-espaco (477:9296) | `Header`, `SpaceCard onSelect`, `SlotPicker` (data e horário), `Button`, `Toast kind="success"` |
| Ativação, QR, resumo e compartilhar | `MemberCard`, `StatsRow`, `ResultScreen`, `Sheet` + `ListRow` (compartilhar) |
| Meus agendamentos (mapa de 27/10) | `Header`, `DeliveryCard state="scheduled"` × n |
| Início (5 telas, estilo anterior) | `LocationBar`, `BalanceCard`, `MissionBanner`, `SectionHeader version="anterior"`, `TileGrid`, `DeliveryCard` (bloco novo), `TabBar` |
| Bottom Navigation (todas) | `TabBar` (atual) |
| Toasts (478:10671) | `Toast` |

## Hex do Figma → token

| Hex no Figma | Onde aparece | Token |
|---|---|---|
| #21344E · #333230 · #1C1917 · #0F1E2C | texto principal (os três últimos são dos conceitos de Ranking, Recompensas e Ativação) | `text-primary` |
| #1E2A3B · #001633 | texto do botão laranja | `text-on-loud` |
| #5C7089 · #56708F · #82807D · #5C5A58 · #4A5768 · #8C8A87 | apoio, placeholder, posição | `text-secondary` |
| #A64B00 | aba ativa | `text-link`, `icon-brand-strong` |
| #DD8613 · #F36208 · #E8823F (como texto) | eyebrow, pontos, "você" | `text-link` (os originais reprovam) |
| #2563EB | "Saber mais" | `text-link` |
| #F2A545 | botão principal, chip escolhido | `interactive-fill-loud` (`bg-primary`) |
| #F36208 · #E8823F (como preenchimento) | botão e meta nos conceitos | `interactive-fill-loud` / `surface-brand` |
| #FFA125 | borda do card do quiz, campo em foco, dia de hoje, ponto do passo, botão do Cadastro | `border-highlight`, `selected-indicator` (no botão: `interactive-fill-loud`) |
| #FFD3BE | borda da linha "você" no ranking | `border-highlight` |
| #FDFEFF · #FFFFFF | fundo, card, barra | `background-primary`, `surface-primary` |
| #FAF9F6 · #FAF9F5 · #FBF7F2 | fundo dos conceitos | `background-primary` |
| #F2F5F8 · #EFEDE9 · #ECEAE7 | card cinza, trilho do toggle, botão redondo | `surface-secondary` (`background-secondary` como fundo de tela) |
| #FFF5E9 · #FFF2EA · #FFF0EA · #FFF4EB | opção marcada, linha "você", detalhe do espaço, etiqueta de meta | `surface-accent` |
| #DDE4EE · #E6E4E1 · #E9DFD3 | divisor, borda de card, trilho, dia futuro | `border-primary`, `surface-track` |
| #DDE4EE (borda de campo) | campo de texto | `input` / `border-strong` (o claro tem 1,27:1) |
| #ACBDD2 | ponto de passo pendente | `indicator-inactive` |
| #E4F2D9 · #EAF7EE / #2D6A4F | dia feito, campanha | `feedback-fill-positive` / `feedback-text-positive` |
| #E0ECFF | dia protegido | `surface-info` (ícone `icon-info`) |
| #E2AF35 · #C1BEBC · #8D6045 | ouro, prata, bronze | `award-gold`, `award-silver`, `award-bronze` |
| #E0DBCE / #9CA3AF | dia indisponível | `interactive-fill-disabled` / `interactive-text-disabled` |

## Fonte, raio e medidas

- **Fonte:** Lexend em tudo. Inter (Quiz, Ranking, Ativação), Sora e Manrope (Recompensas) eram exploração de conceito e vão para Lexend com o estilo equivalente.
- **Peso:** ExtraBold (800) do Figma vira 700.
- **Tamanho:** 9, 10 e 11px de texto (exceto o rótulo da barra) sobem para `caption` 12px. 13px vira `body-small` (14) ou `caption` (12) conforme o papel.
- **Raio:** 8 → `radius-small`; 10 → `radius-small`; 12 → `radius-medium`; 14 → `radius-medium`; 16 → `radius-large`; 18 e pílulas → `radius-full`; 24 → `radius-xlarge`.
- **Área tocável:** botões redondos de 32 e 36px do Figma ficam com 44px de área (`size-touch`); o círculo visível pode continuar menor dentro dela.
- **Sombra:** a sombra suave das linhas de Recompensas vira borda `border-primary`; só o que flutua tem `shadow-high`.

## Lacunas que ficam para o produto

- Mapa dos espaços de recebimento: não há componente de mapa; use a abertura do app de mapas por "Como chegar".
- Ilustrações dos selos de nível (120px no Figma) e da tela de conquistas: entram como `art` em `ResultScreen` e `Modal`, mas a arte não está no sistema.
- Card de entrega com data vencida: `DeliveryCard state="past"` é proposta; o Figma marca como pendente.
