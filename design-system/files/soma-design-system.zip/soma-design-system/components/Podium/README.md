Os três primeiros do período: avatares sobre degraus ouro, prata e bronze.

**Você fornece:** posição, nome, quilos e, se houver, foto de cada um; `self` na própria pessoa; `initials` se as letras do avatar diferem do nome ("Você" → "P"); `anonymous` na aba Geral.

- Ordem visual 2 · 1 · 3, três colunas de 100px com `space-micro` entre elas. Avatar de 64px no primeiro e 54px nos outros, preenchido com `award-gold`, `award-silver`, `award-bronze` quando não há foto. Degraus **retos** (sem raio), com 46/34/26px de altura e o número centralizado em 16px bold.
- `self`: avatar e degrau na cor de destaque (`interactive-fill-loud`, laranja no Figma), nome "Você" em bold e quilos em `text-link`. Só a pessoa tem essa cor; os outros degraus seguem ouro, prata e bronze.
- `anonymous` (Geral): avatar "?" e o nome "Participante". O ranking geral não identifica ninguém.
- Número do degrau em `foreground` sobre ouro e prata, `text-inverse` sobre bronze (o Figma usa branco, que não passa em contraste sobre ouro e prata).
- Quilos com separador de milhar. Quem não está no pódio aparece em `RankingRow`. Com menos de 3 participantes, não use pódio: só a lista (Tela 7).

**Acessibilidade:** lista ordenada em ordem de posição (1, 2, 3) mesmo com a ordem visual 2 · 1 · 3; cada item é lido como "1º lugar: Ana Souza, 42,5 kg" ou "1º lugar: Participante, 34.842 kg".

**Figma:** pódio no Ranking, abas Amigos, Meu espaço e Geral (443:18116, 443:18270, 443:18419).

**React:** `<Soma.Podium entries={[{ position: 1, name: 'Ana Souza', kg: 42.5 }]} />` · `<Soma.Podium entries={geral.map((e) => ({ ...e, anonymous: true }))} />`
