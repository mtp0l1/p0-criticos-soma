# Podium

Os três primeiros do período: avatares em tom claro sobre degraus laranja, areia e pêssego.

## O que você fornece

Posição, nome, quilos e, se houver, foto de cada um; `self` na própria pessoa; `initials` se as letras do avatar diferem do nome ("Você" → "P"); `anonymous` na aba Geral.

## Especificação

- Três degraus de topo arredondado (72, 56 e 44px), com os avatares em tom claro. A ordem visual é 2 · 1 · 3.

## Acessibilidade

Lista ordenada em ordem de posição (1, 2, 3) mesmo com a ordem visual 2 · 1 · 3; cada item é lido como "1º lugar: Ana Souza, 42,5 kg" ou "1º lugar: Participante, 34.842 kg".

## Nas telas da v2

Pódio no Ranking, abas Amigos, Meu espaço e Geral ([Ranking · Amigos](prototipo/#859-9252), [Ranking · Meu espaço](prototipo/#859-9406) e [Ranking · Geral](prototipo/#859-9557)).

## Código

```
<Soma.Podium entries={[{ position: 1, name: 'Ana Souza', kg: 42.5 }]} />
```

```
<Soma.Podium entries={geral.map((e) => ({ ...e, anonymous: true }))} />
```

---
**Usar para:** Os três primeiros do período: avatares em tom claro sobre degraus laranja, areia e pêssego.
**Nunca:** ordenar visualmente sem manter a ordem 1 · 2 · 3 para o leitor de tela.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
