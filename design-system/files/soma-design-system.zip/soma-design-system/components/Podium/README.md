Os três primeiros do período: avatares sobre degraus ouro, prata e bronze.

**Você fornece:** posição, nome, quilos e, se houver, foto de cada um; `self` na própria pessoa; `anonymous` na aba Geral.

- Ordem visual 2 · 1 · 3. Avatar de 64px no primeiro e 54px nos outros, preenchido com `award-gold`, `award-silver`, `award-bronze` quando não há foto. Degraus com raio de 10px no topo e alturas 46/34/26px.
- A própria pessoa ganha anel `border-highlight` e nome em `text-link`.
- `anonymous` (Geral): avatar "?" e o nome "Participante", sem foto nem nome real. O ranking geral não identifica ninguém.
- Quilos com separador de milhar. Quem não está no pódio aparece em `RankingRow`. A versão "anterior" de três cards foi removida.

**Acessibilidade:** lista ordenada em ordem de posição (1, 2, 3) mesmo com a ordem visual 2 · 1 · 3; cada item é lido como "1º lugar: Ana Souza, 42,5 kg" ou "1º lugar: Participante, 34.842 kg".

**Figma:** pódio no Ranking, abas Amigos, Meu espaço e Geral (438:1973).

**React:** `<Soma.Podium entries={[{ position: 1, name: 'Ana Souza', kg: 42.5 }]} />` · `<Soma.Podium entries={geral.map((e) => ({ ...e, anonymous: true }))} />`
