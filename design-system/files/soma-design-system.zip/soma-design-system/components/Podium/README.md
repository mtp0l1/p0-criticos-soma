# Podium

Os três primeiros do período: avatares em tom claro sobre degraus laranja, areia e pêssego.

## O que você fornece

Posição, nome, quilos e, se houver, foto de cada um; `self` na própria pessoa; `initials` se as letras do avatar diferem do nome ("Você" → "P"); `anonymous` na aba Geral.

## Especificação

- Ordem visual 2 · 1 · 3, três colunas de 100px com `space-micro` entre elas. Avatar de 64px no primeiro e 52px nos outros, em tom claro quando não há foto: `surface-tint-peach` (1º), `surface-tint-blue` (2º) e `surface-tint-lavender` (3º). Degraus retos (sem raio), com 46/34/26px de altura e o número centralizado em 16px bold.
- Degraus: o 1º em `primary` (laranja da marca), o 2º em `surface-podium-2` (areia) e o 3º em `surface-podium-3` (pêssego), todos com o número em foreground.
- `self`: avatar laranja com contorno de 2,5px em foreground e degrau laranja, nome "Você" em bold e quilos em `text-link`. Só a pessoa tem esse contorno.
- `anonymous` (Geral): avatar "?" e o nome "Participante". O ranking geral não identifica ninguém.
- Quilos com separador de milhar. Quem não está no pódio aparece em `RankingRow`. Com menos de 3 participantes, não use pódio: só a lista (Tela 7).

## Acessibilidade

Lista ordenada em ordem de posição (1, 2, 3) mesmo com a ordem visual 2 · 1 · 3; cada item é lido como "1º lugar: Ana Souza, 42,5 kg" ou "1º lugar: Participante, 34.842 kg".

## Nas telas da v2

Pódio no Ranking, abas Amigos, Meu espaço e Geral ([Ranking · Amigos](prototipo/#859-9252), [Ranking · Meu espaço](prototipo/#859-9406) e [Ranking · Geral](prototipo/#859-9557)).

## Código

```
<Soma.Podium entries={[{ position: 1, name: 'Ana Souza', kg: 42.5 }]} />
```

```
<Soma.Podium entries={geral.map((e) => ({ ...e, anonymous: true }))} />
```

---
**Usar para:** Os três primeiros do período: avatares em tom claro sobre degraus laranja, areia e pêssego.
**Nunca:** ordenar visualmente sem manter a ordem 1 · 2 · 3 para o leitor de tela.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
