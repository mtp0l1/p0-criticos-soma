Os três primeiros do período. Duas versões: **atual**, com avatares sobre degraus ouro, prata e bronze (Figma do Ranking), e **anterior**, com três cards.

**Você fornece:** posição, nome, quilos e, se houver, foto de cada um; marque `self` se a pessoa estiver entre eles.

- `version="atual"` (padrão): ordem visual 2 · 1 · 3. Avatar de 64px no primeiro e 54px nos outros, preenchido com `award-gold`, `award-silver`, `award-bronze` quando não há foto. Degraus com raio de 10px no topo e alturas 46/34/26px. A própria pessoa ganha anel `border-highlight` e nome em `text-link`.
- `version="anterior"`: três cards `surface-primary` com selo de reciclagem.
- Quilos com separador de milhar. Quem não está no pódio aparece em `RankingRow`.

**Acessibilidade:** lista ordenada em ordem de posição (1, 2, 3) mesmo com a ordem visual 2 · 1 · 3; cada item é lido como "1º lugar: Ana Lima, 34.548 kg".

**Figma:** pódio no Ranking (478:10126). O laranja #F36208 do "você" vira `border-highlight` no anel e `text-link` no texto.

**React:** `<Soma.Podium entries={[{ position: 1, name: 'Ana Lima', kg: 34548 }]} />` · `<Soma.Podium version="anterior" entries={…} />`
