Bottom sheet, sobre Radix Dialog (shadcn Sheet com `side="bottom"`). Para escolhas rápidas sem sair da tela: trocar local, filtrar, compartilhar.

**Você fornece:** título, descrição opcional, o conteúdo e uma ação.

- Sobe da base, raio `radius-xlarge` no topo, alça de 40px em `border`, sombra `shadow-high`, padding `space-mini`, até 90% da altura com rolagem.
- Uma ação `loud` em largura total no fim. Fecha ao tocar fora, com Esc ou com o voltar do aparelho.
- Conteúdo longo ou com várias etapas vira tela, não sheet.

**Acessibilidade:** mesmo comportamento do `Dialog`: foco preso, título ligado, foco volta ao gatilho.

**React:** `<Soma.Sheet><Soma.SheetTrigger asChild>…</Soma.SheetTrigger><Soma.SheetContent><Soma.SheetHeader><Soma.SheetTitle>…</Soma.SheetTitle></Soma.SheetHeader>…</Soma.SheetContent></Soma.Sheet>`
