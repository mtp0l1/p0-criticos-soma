Bottom sheet, sobre Radix Dialog (shadcn Sheet com `side="bottom"`). Para escolhas rápidas sem sair da tela: trocar local, filtrar, compartilhar.

**Você fornece:** título, descrição opcional, o conteúdo e uma ação.

- Sobe da base, raio `radius-xlarge` no topo, alça de 40px em `border` (`handle={false}` tira a alça, como nas folhas do Cadastro, que também usam `radius-large` no topo e fundo `surface-secondary`), sombra `shadow-high`, padding `space-mini`, até 90% da altura com rolagem.
- Uma ação `loud` em largura total no fim. Fecha ao tocar fora, com Esc ou com o voltar do aparelho.
- Conteúdo longo ou com várias etapas vira tela, não sheet.
- `side`: `bottom` (padrão), `top`, `left` e `right`, todos com animação de entrada e de saída. Com gesto de arrastar, use `Drawer`.

**Acessibilidade:** mesmo comportamento do `Dialog`: foco preso, título ligado, foco volta ao gatilho.

**React:** `<Soma.Sheet><Soma.SheetTrigger asChild>…</Soma.SheetTrigger><Soma.SheetContent><Soma.SheetHeader><Soma.SheetTitle>…</Soma.SheetTitle></Soma.SheetHeader>…</Soma.SheetContent></Soma.Sheet>`

---
**Usar para:** Bottom sheet, sobre Radix Dialog (shadcn Sheet com `side="bottom"`).
**Nunca:** usar para confirmação destrutiva (use `AlertDialog`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
