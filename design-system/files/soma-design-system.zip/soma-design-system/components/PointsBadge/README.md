Pílula de pontos: quanto uma ação vale ("+15 pontos") ou quanto algo custa.

**Você fornece:** os pontos e, se for custo, `kind="cost"`.

- Fundo `surface-accent`, texto `text-link` em 12px e 600, raio cheio. Número com ponto de milhar e "ponto" no singular quando for 1.
- No Figma o texto é #DD8613 (2,6:1 sobre o creme, reprova): aqui é `text-link` (5,37:1).

**Figma:** "+15 pontos" na pergunta do dia (477:20539).

**React:** `<Soma.PointsBadge points={15} />` · `<Soma.PointsBadge points={1200} kind="cost" />`
