# PointsBadge

Pílula com os pontos de uma pergunta, de um prêmio ou de um custo.

## O que você fornece

Os pontos (`points`) e o tipo (`kind`): `gain` (padrão, "+15 pontos") ou `cost` ("450 pontos").

## Especificação

- Ganho em `surface-accent` com estrela em `icon-brand-strong`; custo em `surface-secondary`.
- Número com separador de milhar.

## Acessibilidade

É texto; a estrela é decorativa.

## Código

```
<Soma.PointsBadge points={15} />
```

---
**Usar para:** Pílula com os pontos de uma pergunta, de um prêmio ou de um custo.
**Nunca:** usar para outro número que não seja pontos.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
