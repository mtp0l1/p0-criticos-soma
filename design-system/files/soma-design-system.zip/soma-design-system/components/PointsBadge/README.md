Pílula com os pontos de uma pergunta, de um prêmio ou de um custo.

**Você fornece:** os pontos (`points`) e o tipo (`kind`): `gain` (padrão, "+15 pontos") ou `cost` ("450 pontos").

- Ganho em `surface-accent` com estrela em `icon-brand-strong`; custo em `surface-secondary`.
- Número com separador de milhar.

**Acessibilidade:** é texto; a estrela é decorativa.

**React:** `<Soma.PointsBadge points={15} />`
