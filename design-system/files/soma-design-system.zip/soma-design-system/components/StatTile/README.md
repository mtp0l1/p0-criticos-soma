Indicador de impacto: ícone, frase de entrada, valor e equivalência. Em grade (`StatGrid`) no painel ou em linha no resumo.

**Você fornece:** o ícone, a frase de entrada, o valor com unidade e, se houver, a equivalência concreta.

- Card `surface-primary` sobre `background-secondary`, raio `radius-large`. Entrada em `caption`, valor em `stat-number` e `text-primary`, equivalência em `caption` e `text-secondary`.
- O primeiro produto pinta cada valor com a cor do ícone (verde, azul, roxo). Essas cores não estão no sistema e algumas não passam de 4,5:1: use `text-primary` no valor.
- `layout="row"` para o resumo (Total de entregas).
- Conta nova com zero: troque o zero por uma projeção ("Recicle 1 kg e evite…") em vez de painel zerado.

**Base técnica:** `statTileVariants` (CVA) com `layout`.

**React:** `<Soma.StatGrid><Soma.StatTile icon="drop" lead="Você economizou" value="948 litros de água" equivalence="Equivale a abastecer 5 pessoas por dia" /></Soma.StatGrid>`

---
**Usar para:** Indicador de impacto: ícone, frase de entrada, valor e equivalência.
**Nunca:** usar sem equivalência quando o dado a tem.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
