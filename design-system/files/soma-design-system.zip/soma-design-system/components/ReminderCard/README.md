# ReminderCard

Lembrete da próxima entrega: data sugerida e botão "Adicionar ao calendário".

## O que você fornece

A data já escrita (`date`, "Segunda, 14 de setembro · 08:00"), `onAdd` e, para mudar a data, `onDatePress`. Opcional: `title`, `description` e `added`.

## Especificação

- Cartão pêssego com o sino, o texto, a data numa pílula branca (abre o seletor) e "Adicionar ao calendário".

## Acessibilidade

`section` com o título como nome; o aviso de sucesso ou erro vai por `notify()` (região viva).

## Nas telas da v2

Ativação: [Entrega registrada](prototipo/#842-10230), [Seletor de data e horário](prototipo/#842-10344), [Lembrete adicionado](prototipo/#842-10479) e [Erro ao adicionar](prototipo/#842-10589).

## Código

```
<Soma.ReminderCard date="Segunda, 14 de setembro · 08:00" onDatePress={abrirSeletor} onAdd={salvar} added={salvo} />
```

---
**Usar para:** Lembrete da próxima entrega: data sugerida e botão "Adicionar ao calendário".
**Nunca:** trocar o botão "Adicionar ao calendário" por outra ação.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
