Lembrete da próxima entrega: data sugerida e botão "Adicionar ao calendário".

**Você fornece:** a data já escrita (`date`, "Segunda, 14 de setembro · 08:00"), `onAdd` e, para mudar a data, `onDatePress`. Opcional: `title`, `description` e `added`.

- Card `surface-card` com borda de 1,5px, raio `radius-large`, padding 16px. Título em `body-strong`, descrição em `caption`, linha da data com `calendar` e o botão `loud` de largura total.
- A linha da data é um botão (44px) que abre o seletor de data e horário: bottom sheet com "Data" e "Horário" em seletores do aparelho (`NativeSelect`), a frase "Avisamos 1 hora antes.", o botão e "Cancelar" em texto. Horários de 8h às 18h.
- Depois de salvar: o botão vira cinza com check e "Adicionado ao calendário" (`added`), sem toque, e um aviso dark confirma "Lembrete adicionado ao calendário". Se falhar, o aviso diz "Não conseguimos adicionar ao calendário. Tente de novo." e o botão continua ativo.
- **Pendente de validação (nota do Figma):** o intervalo padrão de 1 semana e o horário sugerido.

**Acessibilidade:** `section` com o título como nome; o aviso de sucesso ou erro vai por `notify()` (região viva).

**Figma:** Telas 12 a 15 (443:13637 e seguintes).

**React:** `<Soma.ReminderCard date="Segunda, 14 de setembro · 08:00" onDatePress={abrirSeletor} onAdd={salvar} added={salvo} />`

---
**Usar para:** Lembrete da próxima entrega: data sugerida e botão "Adicionar ao calendário".
**Nunca:** trocar o botão "Adicionar ao calendário" por outra ação.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
