# StreakSection

Bloco "Sua trilha" das Telas 1 e 3 do Quiz: título, os sete dias, a barra de semanas, o aviso de proteção e o link "Ver histórico".

## O que você fornece

Os sete dias (`days`) e as semanas (`weeks`). Opcional: `nextReward`, `protection` (texto do aviso) e `onHistory`.

## Especificação

- Junta `StreakTrail`, `StreakProgress` e `ProtectionNotice` `inline`. Título "Sua trilha" em 14px 700. Espaço de 8px entre as partes.
- "Ver histórico" é link sublinhado em `text-link`, alinhado à esquerda, e abre o `AnswerHistory`.
- Depois dele vem o `QuestionCard` (Tela 1) ou o `DailyDone` (Tela 3).

## Acessibilidade

`section` nomeada pelo título "Sua trilha".

## Nas telas da v2

Quiz: [Pergunta do dia](prototipo/#849-8934) e [Já respondeu hoje](prototipo/#849-9175), na "TrailSection".

## Código

```
<Soma.StreakSection days={dias} weeks={2} nextReward={{ points: 500, inWeeks: 3 }} protection="Proteção usada. Renova em 2 dias" onHistory={abrirHistorico} />
```

---
**Usar para:** Bloco "Sua trilha" das Telas 1 e 3 do Quiz: título, os sete dias, a barra de semanas, o aviso de proteção e o link "Ver histórico".
**Nunca:** esconder o link "Ver histórico".
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
