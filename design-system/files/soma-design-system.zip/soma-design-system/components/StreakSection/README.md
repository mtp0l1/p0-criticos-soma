Bloco "Sua trilha" das Telas 1 e 3 do Quiz: título, os sete dias, a barra de semanas, o aviso de proteção e o link "Ver histórico".

**Você fornece:** os sete dias (`days`) e as semanas (`weeks`). Opcional: `nextReward`, `protection` (texto do aviso) e `onHistory`.

- Junta `StreakTrail`, `StreakProgress` e `ProtectionNotice` `inline`. Título "Sua trilha" em 14px 700. Espaço de 8px entre as partes.
- "Ver histórico" é link sublinhado em `text-link`, alinhado à esquerda, e abre o `AnswerHistory`.
- Depois dele vem o `QuestionCard` (Tela 1) ou o `DailyDone` (Tela 3).

**Acessibilidade:** `section` nomeada pelo título "Sua trilha".

**Figma:** Quiz, Telas 1 e 3 "TrailSection" (443:15355, 443:15595).

**React:** `<Soma.StreakSection days={dias} weeks={2} nextReward={{ points: 500, inWeeks: 3 }} protection="Proteção usada. Renova em 2 dias" onHistory={abrirHistorico} />`
