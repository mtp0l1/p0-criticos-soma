Item do histórico de resgates: logo do parceiro, nome da recompensa, pontos e hora, e o status. Agrupe por data com `RedemptionGroup`.

**Você fornece:** o título, os pontos, a hora, o status, o logo (`logo.src`) e o destino.

- Logo em `Thumb` de `size-thumb`. Título em `label` (até duas linhas), meta "600 pontos · 19:55" em `caption` e `text-secondary`, `StatusChip` abaixo.
- Data do grupo em `label` e `text-primary`, no formato 15/08/2026.
- Divisor `border-primary` entre itens. O item inteiro é tocável e leva aos detalhes.

**Estados:** hover e toque em `interactive-fill-quiet-*`, foco com anel `ring`. Com `href`, vira link.

**React:** `<Soma.RedemptionGroup date="15/08/2026"><Soma.RedemptionItem title="…" points={600} time="19:55" status="done" /></Soma.RedemptionGroup>`
