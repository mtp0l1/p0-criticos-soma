Foto ou iniciais da pessoa em círculo, sobre Radix Avatar (shadcn Avatar).

**Você fornece:** a foto (`AvatarImage`) e as iniciais de reserva (`AvatarFallback`).

- `size`: `medal` (40px), `thumb` (48px, padrão), `avatar` (96px, cartão do participante).
- Sem foto, iniciais em `label` e `text-link` sobre `surface-accent` (4,51:1). A reserva aparece também enquanto a foto carrega ou se ela falhar.
- Foto decorativa ao lado do nome usa `alt=""`.

**React:** `<Soma.Avatar size="avatar"><Soma.AvatarImage src={foto} alt="" /><Soma.AvatarFallback>PL</Soma.AvatarFallback></Soma.Avatar>`

---
**Usar para:** Foto ou iniciais da pessoa em círculo, sobre Radix Avatar (shadcn Avatar).
**Nunca:** mostrar sem iniciais quando falta a foto.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
