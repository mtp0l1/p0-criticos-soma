# RedeemCode

Código do resgate num bilhete azul-marinho, com botão de copiar em largura total.

## O que você fornece

O código (`code`) e, se houver, a validade (`validity`) e a dica de uso (`hint`). `onCopy` avisa quando copiou.

## Especificação

- "Código de resgate", o código em 28px na cor primária, uma linha tracejada, a instrução e a validade.
- "Copiar código" vira "Copiado" por 2 segundos.

## Acessibilidade

O anúncio vai por `aria-live="polite"`; o código continua selecionável se o navegador negar a cópia.

## Nas telas da v2

Recompensas: [Resultado · Cupom](prototipo/#887-10644).

## Código

```
<Soma.RedeemCode code="RW-K7M2-XFPT" hint="Use na retirada ou no site do parceiro." />
```

---
**Usar para:** Código do resgate num bilhete azul-marinho, com botão de copiar em largura total.
**Nunca:** mostrar o código sem o botão de copiar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
