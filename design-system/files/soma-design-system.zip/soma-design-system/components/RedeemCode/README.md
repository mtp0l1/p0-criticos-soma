Código do resgate em caixa tracejada, com botão de copiar em largura total.

**Você fornece:** o código (`code`) e, se houver, a validade (`validity`) e a dica de uso (`hint`). `onCopy` avisa quando copiou.

- Caixa branca com borda tracejada de 2px `border-highlight`, "CÓDIGO DE RESGATE" em `eyebrow`, e o código em 24px bold com espaçamento largo e cor `text-link`. Abaixo, a dica ("Use na retirada ou no site do parceiro").
- "Copiar código" é `loud`, largura total; vira "Copiado" por 2 segundos e anuncia "Código copiado".
- Pendente no handoff: o link "Ver em Meus resgates" citado na nota da Tela 21 não está desenhado.

**Acessibilidade:** o anúncio vai por `aria-live="polite"`; o código continua selecionável se o navegador negar a cópia.

**Figma:** Recompensas, Tela 21 (438:1973).

**React:** `<Soma.RedeemCode code="RW-K7M2-XFPT" hint="Use na retirada ou no site do parceiro." />`

---
**Usar para:** Código do resgate em caixa tracejada, com botão de copiar em largura total.
**Nunca:** mostrar o código sem o botão de copiar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
