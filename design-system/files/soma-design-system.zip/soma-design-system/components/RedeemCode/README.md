Código do resgate em caixa tracejada, com botão de copiar em largura total.

**Você fornece:** o código (`code`) e, se houver, a validade (`validity`) e a dica de uso (`hint`). `onCopy` avisa quando copiou.

- Caixa branca com borda tracejada `border-highlight`, "CÓDIGO DE RESGATE" em `eyebrow`, e o código em 24px bold com espaçamento largo e cor `text-link`. Abaixo, a dica ("Use na retirada ou no site do parceiro").
- "Copiar código" é `loud`, largura total; vira "Copiado" por 2 segundos e anuncia "Código copiado".

**Acessibilidade:** o anúncio vai por `aria-live="polite"`; o código continua selecionável se o navegador negar a cópia.

**Figma:** Recompensas, Tela 21 (438:1973).

**React:** `<Soma.RedeemCode code="RW-K7M2-XFPT" hint="Use na retirada ou no site do parceiro." />`
