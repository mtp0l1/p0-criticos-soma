Código do resgate em caixa tracejada, com botão de copiar.

**Você fornece:** o código e, se houver, a validade.

- Fundo `surface-accent`, borda tracejada de 1,5px `border-highlight`, raio `radius-large`. Código em 24px bold com espaçamento largo, selecionável.
- "Copiar código" (`quiet` `compact`) vira "Copiado" por 2 segundos e anuncia "Código copiado".

**Acessibilidade:** o anúncio vai por `aria-live="polite"`; o código continua visível se o navegador negar a cópia.

**Figma:** card do código em Recompensas (sucesso do resgate).

**React:** `<Soma.RedeemCode code="SOMA-7K2Q" validity="Válido até 30/11/2026" />`
