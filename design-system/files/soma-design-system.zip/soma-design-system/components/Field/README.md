Estrutura de um campo de formulário: rótulo, controle, ajuda e erro (shadcn Field).

**Você fornece:** o controle (Input, Select, Checkbox, Switch…), o rótulo ligado por `htmlFor` e, se houver, descrição e erro ligados por `aria-describedby`.

- `Field` vertical (padrão): rótulo em `body-small` em cima, `space-nano` até o controle, ajuda e erro em `caption`.
- `Field orientation="horizontal"`: controle e rótulo lado a lado; Checkbox fica à esquerda e Switch à direita.
- `invalid` pinta o rótulo de `feedback-text-negative`; o controle recebe `aria-invalid`. `FieldError` só aparece com texto.
- `FieldSet` + `FieldLegend` agrupam campos de um assunto; `FieldGroup` dá o `space-small` (24px) entre campos; `FieldSeparator` divide blocos.
- `TextField` continua sendo o atalho para o caso comum (rótulo, ajuda e erro num componente só).

**Acessibilidade:** erro com `role="alert"`, anunciado na hora; a legenda do `fieldset` é lida antes de cada campo.

**Base técnica:** composição sem estado; `fieldVariants` (CVA) e atributos `data-invalid` e `data-disabled` para os filhos. Com React Hook Form, ligue `invalid` a `fieldState.invalid` e o texto de `FieldError` a `fieldState.error.message`.

**React:** `<Soma.Field invalid={!!erro}><Soma.FieldLabel htmlFor="cpf">CPF*</Soma.FieldLabel><Soma.Input id="cpf" aria-invalid={!!erro} aria-describedby="cpf-e" /><Soma.FieldError id="cpf-e">{erro}</Soma.FieldError></Soma.Field>`

---
**Usar para:** Estrutura de um campo de formulário: rótulo, controle, ajuda e erro (shadcn Field).
**Nunca:** repetir rótulo, ajuda e erro à mão: a estrutura já vem pronta.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
