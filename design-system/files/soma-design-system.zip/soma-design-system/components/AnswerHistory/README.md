Lista de respostas do Quiz por mês, com navegação entre os meses (Tela 4).

**Você fornece:** o mês (`month`, por extenso), `onPrev` e `onNext` e as linhas (`AnswerHistoryRow`) como filhos. Opcional: `title` (padrão "Histórico de respostas").

- Título em 14px 700. Seletor de mês em caixa de borda `border` com setas redondas de 44px em `surface-secondary` e o mês ao centro em 14px 700. Sem `onPrev` ou `onNext`, a seta fica desabilitada.
- Cada `AnswerHistoryRow` mostra a data (14px 600), a pergunta (uma linha, com reticências) e o resultado: `{ kind: 'points', points: 15 }` ("+15" verde), `{ kind: 'kept' }` ("Sequência mantida", creme, com escudo) ou `{ kind: 'zero' }` ("0", cinza).
- Mês vazio: use `EmptyState` com "Você ainda não respondeu neste mês".

**Acessibilidade:** `section` com o título como nome; o mês está em `aria-live="polite"`; a lista é `ul`.

**Figma:** Quiz, Tela 4 "history-list" (443:15739).

**React:** `<Soma.AnswerHistory month="Agosto 2026" onPrev={voltar} onNext={avancar}><Soma.AnswerHistoryRow date="28/08/2026" question="Qual destes materiais leva mais tempo para se decompor?" result={{ kind: 'points', points: 15 }} /></Soma.AnswerHistory>`

---
**Usar para:** Lista de respostas do Quiz por mês, com navegação entre os meses (Tela 4).
**Nunca:** misturar meses numa lista só: a navegação é mês a mês.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
