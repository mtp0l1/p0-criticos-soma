# AnswerHistory

Lista de respostas do Quiz agrupada por mês.

## O que você fornece

O mês (`month`, por extenso), `onPrev` e `onNext` e as linhas (`AnswerHistoryRow`) como filhos. Opcional: `title` (padrão "Histórico de respostas").

## Especificação

- Mês em eyebrow. As setas só aparecem quando há `onPrev` ou `onNext`.
- Cada resposta é um cartão: data, resultado em pílula e a pergunta inteira, sem cortar.

## Acessibilidade

`section` com o título como nome; o mês está em `aria-live="polite"`; a lista é `ul`.

## Nas telas da v2

Quiz: [Histórico](prototipo/#849-9313).

## Código

```
<Soma.AnswerHistory month="Agosto 2026" onPrev={voltar} onNext={avancar}><Soma.AnswerHistoryRow date="28/08/2026" question="Qual destes materiais leva mais tempo para se decompor?" result={{ kind: 'points', points: 15 }} /></Soma.AnswerHistory>
```

---
**Usar para:** Lista de respostas do Quiz por mês, com navegação entre os meses (Tela 4).
**Nunca:** misturar meses numa lista só sem o nome do mês.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
