Lista de respostas do Quiz por mês, com navegação entre os meses.

**Você fornece:** o mês (`month`, por extenso), `onPrev` e `onNext` e as linhas (`AnswerHistoryRow`) como filhos.

- Cabeçalho com setas de 44px ("Mês anterior", "Próximo mês") e o mês ao centro. Sem `onPrev` ou `onNext`, a seta fica desabilitada.
- Cada `AnswerHistoryRow` mostra a data, a pergunta (uma linha, reticências) e o resultado: `{ kind: 'points', points: 15 }` ("+15" em verde), `{ kind: 'kept' }` ("Sequência mantida", com escudo) ou `{ kind: 'zero' }` ("0").
- Mês vazio: use `EmptyState` com "Você ainda não respondeu neste mês".

**Acessibilidade:** `section` "Histórico de respostas"; o mês está em `aria-live="polite"`; a lista é `ul`.

**Figma:** Quiz, Tela 4 "Histórico" (443:15190).

**React:** `<Soma.AnswerHistory month="Agosto 2026" onPrev={voltar} onNext={avancar}><Soma.AnswerHistoryRow date="28/08/2026" question="Qual destes materiais leva mais tempo…" result={{ kind: 'points', points: 15 }} /></Soma.AnswerHistory>`
