Tela de conquista quando a pessoa completa um marco de semanas seguidas.

**Você fornece:** as semanas completas (`weeks`) e os pontos do prêmio (`points`). Opcional: `nextReward` (`{ week, points }`), `message`, `tier`, `art` e `onContinue`.

- Arte da conquista, "+100 pontos" em destaque, "Você completou 1 semana seguida!" e a `StreakProgress` com o marco alcançado.
- Fala do próximo prêmio ("Na 5ª semana seguida você ganha 500 pontos") e termina em "Continuar" (`loud`).
- Marcos: 1, 5, 10 e 20 semanas, com 100, 500, 1.000 e 2.000 pontos.

**Acessibilidade:** o prêmio é dito em texto, antes dos controles; a arte é decorativa.

**Figma:** Quiz, Telas 7 e 8 (443:15190).

**React:** `<Soma.MilestoneResult weeks={1} points={100} nextReward={{ week: 5, points: 500 }} onContinue={fechar} />`
