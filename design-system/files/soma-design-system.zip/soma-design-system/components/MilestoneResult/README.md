# MilestoneResult

Tela cheia de conquista quando a pessoa completa um marco de semanas seguidas (Telas 7 e 8).

## O que você fornece

As semanas completas (`weeks`) e os pontos do prêmio (`points`). Opcional: `nextReward` (`{ week, points }`), `message`, `art` e `onContinue`.

## Especificação

- Topo em `primary` com a conquista num círculo e "+N pontos"; folha clara com o título, o texto e os marcos num cartão.
- "Continuar" em botão `dark` no pé.

## Acessibilidade

O prêmio é dito em texto, antes dos controles; a arte é decorativa; os marcos têm um rótulo com a semana atual.

## Nas telas da v2

Quiz: [Conquista de 1 semana](prototipo/#849-9714) e [Conquista de 5 semanas](prototipo/#849-9797).

## Código

```
<Soma.MilestoneResult weeks={5} points={500} nextReward={{ week: 10, points: 1000 }} onContinue={fechar} />
```

---
**Usar para:** Tela cheia de conquista quando a pessoa completa um marco de semanas seguidas (Telas 7 e 8).
**Nunca:** disparar fora de marco de semanas seguidas.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
