Tela cheia de conquista quando a pessoa completa um marco de semanas seguidas (Telas 7 e 8).

**Você fornece:** as semanas completas (`weeks`) e os pontos do prêmio (`points`). Opcional: `nextReward` (`{ week, points }`), `message`, `art` e `onContinue`.

- Faixa de cima: arte da conquista de 148px (troféu com quatro estrelas de contorno em volta) e "+100 pontos" em 32px 800 `text-link`. A arte vem embutida (`conquista-bronze-148`).
- Depois: "Você completou 1 semana seguida!" (18px 700), a frase de apoio e os marcos em blocos: feito = 16px laranja com check; atual = o mesmo com anel de 22px; futuro = 10px cinza. Os blocos são espaçados por igual (diferente da barra proporcional da `StreakProgress`).
- Texto de apoio: na 1ª semana, "Continue assim. Na 5ª semana seguida você ganha 500 pontos."; depois, "Próximo prêmio: 1.000 pontos na 10ª semana.".
- Termina em "Continuar" (`loud`). Marcos: 1, 5, 10 e 20 semanas, com 100, 500, 1.000 e 2.000 pontos.

**Acessibilidade:** o prêmio é dito em texto, antes dos controles; a arte é decorativa; os marcos têm um rótulo com a semana atual.

**Figma:** Quiz, Telas 7 e 8 (443:16142, 443:16224).

**React:** `<Soma.MilestoneResult weeks={5} points={500} nextReward={{ week: 10, points: 1000 }} onContinue={fechar} />`

---
**Usar para:** Tela cheia de conquista quando a pessoa completa um marco de semanas seguidas (Telas 7 e 8).
**Nunca:** disparar fora de marco de semanas seguidas.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
