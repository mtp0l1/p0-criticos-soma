# SpaceMapSheet

Folha "Como chegar": o espaço tocado, se está aberto agora, um mapa ilustrativo e as ações para abrir o caminho ou copiar o endereço.

## O que você fornece

O nome (`name`), o endereço com a distância (`address`), a situação (`status`), o horário (`hours`), `onOpenMaps`, `onCopyAddress` e quem abre a folha (`trigger` ou `open`).

## Especificação

- Folha inferior com alça, raio `radius-xlarge` no topo e fundo `background`. Nome do espaço à esquerda e "Fechar" em círculo à direita.
- Selo de situação em `feedback-fill-positive` ao lado do horário.
- O `SpaceMap` (132px) é o mesmo para todos os espaços: marca o lugar com o pino, sem rota. O caminho abre no app de mapas.
- "Abrir no app de mapas" (`loud`) e "Copiar endereço" (`quiet`), em largura total.

## Acessibilidade

É um diálogo com o nome do espaço como título; o endereço é a descrição. O mapa é decorativo (`aria-hidden`): o endereço em texto é a informação.

## Nas telas da v2

[Como chegar · Vila Verde](prototipo/#916-10696), [Como chegar · Casa so+ma Batel](prototipo/#916-90002) e [Como chegar · Praça Central](prototipo/#916-90003).

## Código

```
<Soma.SpaceMapSheet open={aberto} onOpenChange={setAberto} name="Vila Verde" address="Rua das Flores, 120 · 800 m" status="Aberto até 18h" hours="Seg a sáb, 8h às 18h" onOpenMaps={abrirApp} onCopyAddress={copiar} />
```

---
**Usar para:** abrir o "Como chegar" de um espaço, sobre a tela em que a pessoa está.
**Nunca:** mostrar outro espaço que não seja o tocado, nem desenhar rota no mapa ilustrativo.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
