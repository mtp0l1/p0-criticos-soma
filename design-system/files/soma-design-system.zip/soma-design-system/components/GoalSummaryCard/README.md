Resumo da meta de pontos no Início: a recompensa escolhida e quanto falta.

**Você fornece:** o nome da recompensa (`title`), a meta (`goal`, em pontos), quanto falta (`remaining`) e o destino (`href` ou `onPress`). Opcional: `icon`.

- Card com borda de 2px `border-highlight`, ícone de 24px em quadro de 40px `surface-accent` (o ícone é o da recompensa), título em `body-strong`, "Meta: 800 pontos" e, embaixo, uma faixa de raio `radius-small` "Faltam 656 pontos para a meta" com bandeira (`flag`).
- Aparece no Início só quando há uma meta ativa; sem meta, a Home não mostra o card.

**Acessibilidade:** o card inteiro é um link ou botão; "Faltam N pontos" é texto.

**Figma:** Início, Tela 17 (438:1973 e 443:14233). Fica acima do `BalanceCard tone="dark"`, abaixo da saudação.

**React:** `<Soma.GoalSummaryCard title="Fones de ouvido Bluetooth" goal={800} remaining={656} href="/recompensas/meta" />`
