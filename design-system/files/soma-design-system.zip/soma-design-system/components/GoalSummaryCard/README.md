# GoalSummaryCard

Resumo da meta de pontos no Início: a recompensa escolhida e quanto falta.

## O que você fornece

O nome da recompensa (`title`), a meta (`goal`, em pontos), quanto falta (`remaining`) e o destino (`href` ou `onPress`). Opcional: `icon`.

## Especificação

- Cartão azul-marinho com a bandeira num disco primário, "Sua meta", o nome da recompensa e a meta em pontos.
- Barra com o que já foi juntado (meta menos o que falta) e "Faltam N pontos para a meta".
- A propriedade `icon` continua aceita, mas o desenho atual não a mostra.

## Acessibilidade

O card inteiro é um link ou botão; "Faltam N pontos" é texto.

## Nas telas da v2

Início: [Início pós-entrega](prototipo/#842-10848). Fica acima do `BalanceCard tone="dark"`, abaixo da saudação.

## Código

```
<Soma.GoalSummaryCard title="Fones de ouvido Bluetooth" goal={800} remaining={656} href="/recompensas/meta" />
```

---
**Usar para:** Resumo da meta de pontos no Início: a recompensa escolhida e quanto falta.
**Nunca:** aparecer sem meta definida (use `GoalCard` ou a chamada de escolher meta).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
