Resumo da meta de pontos no Início: a recompensa escolhida e quanto falta.

**Você fornece:** o nome da recompensa (`title`), a meta (`goal`, em pontos), quanto falta (`remaining`) e o destino (`href` ou `onPress`). Opcional: `icon`.

- Card com borda `border-highlight`, ícone em quadro `surface-accent`, título, "Meta: 800 pontos" e, embaixo, uma faixa "Faltam 656 pontos para a meta" com alvo.
- Aparece no Início só quando há uma meta ativa; sem meta, a Home não mostra o card.

**Acessibilidade:** o card inteiro é um link ou botão; "Faltam N pontos" é texto.

**Figma:** Início, Tela 17 (438:1973).

**React:** `<Soma.GoalSummaryCard title="Fones de ouvido Bluetooth" goal={800} remaining={656} href="/recompensas/meta" />`
