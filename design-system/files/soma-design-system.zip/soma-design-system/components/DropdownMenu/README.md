Menu de ações de um item, aberto por um botão (shadcn DropdownMenu, sobre Radix).

**Você fornece:** o gatilho e os itens; marque `variant="destructive"` no que apaga ou cancela.

- Superfície `popover` com borda, raio `radius-medium` e `shadow-high`. Itens de 44px em `body-small`, ícone de 16px em `icon-brand-strong`.
- Item em destaque (toque, hover ou teclado): `accent`. Desabilitado: `interactive-text-disabled`. Destrutivo: texto e ícone em `feedback-text-negative`, destaque em `feedback-fill-negative`.
- Tem rótulo de grupo, divisor, item de marcar (`CheckboxItem`), escolha única (`RadioGroup` + `RadioItem`) e submenu.
- No celular, até cinco ações. Lista maior ou com explicação vai em `Sheet` ou `Drawer`.

**Acessibilidade:** `role="menu"`; abre com Enter, Espaço ou seta para baixo; setas e letras navegam; Esc fecha e devolve o foco ao gatilho.

**Base técnica:** Radix DropdownMenu com `collisionPadding` de 16px; animação de entrada e saída pela origem do gatilho.

**React:** `<Soma.DropdownMenu><Soma.DropdownMenuTrigger asChild><Soma.IconButton icon="menu" label="Mais ações" /></Soma.DropdownMenuTrigger><Soma.DropdownMenuContent><Soma.DropdownMenuItem onSelect={reagendar}>Reagendar</Soma.DropdownMenuItem></Soma.DropdownMenuContent></Soma.DropdownMenu>`
