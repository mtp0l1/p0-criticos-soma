Aviso curto e passageiro: erro, confirmação ou aviso neutro, sempre com ícone e uma frase.

**Você fornece:** a mensagem, sem emoticon, e o tipo (`kind`).

- `kind="error"` (padrão): `feedback-fill-negative-loud` com `text-inverse` (4,83:1), ícone ×. "Não deu para enviar. Fale conosco por e-mail."
- `kind="success"`: `surface-inverse` com check. "Entrega agendada", "Código copiado".
- `kind="info"`: `surface-inverse` com (i). "Link do convite copiado".
- Raio `radius-small`, padding `space-micro` por `space-mini`, texto em `label`.
- `tone="app"` reproduz o vermelho atual do app (4,21:1, reprova). Só para documentar.
- Mensagem que precisa ficar na tela vai em `Message`.

**Acessibilidade:** erro usa `role="alert"`; sucesso e aviso usam `role="status"`.

**Base técnica:** visual do aviso (`toastVariants`). No app, dispare com `notify()` e monte o `Toaster` (Sonner) na raiz: ele cuida de tempo, fila e gesto.

**React:** `<Soma.Toast kind="success" message="Entrega agendada para seg, 07 set" />`
