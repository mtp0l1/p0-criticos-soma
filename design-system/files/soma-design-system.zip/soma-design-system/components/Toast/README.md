Aviso curto e passageiro: erro, confirmação, aviso neutro ou novidade do ranking, sempre com ícone e uma frase.

**Você fornece:** a mensagem, sem emoticon, e o tipo (`kind`). Opcional: `icon` e `surface`.

- `kind="error"` (padrão): `feedback-fill-negative-loud` com `text-inverse` (4,83:1), ícone ×. "Não deu para enviar. Fale conosco por e-mail."
- `kind="success"`: `surface-inverse` com check. "Entrega agendada", "Código copiado".
- `kind="info"`: `surface-inverse` com (i). "Link do convite copiado".
- `surface="card"`: cartão claro (`surface-primary`, borda, raio `radius-large`) com o ícone num círculo de 32px `surface-accent`. Para novidades do ranking, no **topo** da tela: "Ana Souza entrou no seu ranking de amigos!" (`user-plus`) e "Você subiu 3 posições no ranking de amigos!" (`arrow-up`). Com `notify()`, passe `position: 'top-center'`.
- Raio `radius-small`, padding `space-micro` por `space-mini`, texto em `label` (barra escura).
- `tone="app"` reproduz o vermelho atual do app (4,21:1, reprova). Só para documentar.
- Mensagem que precisa ficar na tela vai em `Message`.
- Pendente no handoff: quando dispara o aviso "subiu de posição" (na entrega registrada ou na próxima abertura) e se há notificação além do aviso.

**Acessibilidade:** erro usa `role="alert"`; os demais usam `role="status"`.

**Figma:** Ranking, Telas 5 e 10 (443:19443, 443:18600).

**Base técnica:** visual do aviso (`toastVariants`). No app, dispare com `notify()` e monte o `Toaster` (Sonner) na raiz: ele cuida de tempo, fila e gesto.

**React:** `<Soma.Toast kind="success" message="Entrega agendada para seg, 07 set" />` · `notify('Ana Souza entrou no seu ranking de amigos!', { kind: 'info', icon: 'user-plus', surface: 'card', position: 'top-center' })`

---
**Usar para:** Aviso curto e passageiro: erro, confirmação, aviso neutro ou novidade do ranking, sempre com ícone e uma frase.
**Nunca:** guardar informação que a pessoa precisa reler; some sozinho.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
