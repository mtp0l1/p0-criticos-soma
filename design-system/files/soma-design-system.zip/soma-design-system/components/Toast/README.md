# Toast

Aviso curto e passageiro: erro, confirmação, aviso neutro ou novidade do ranking, sempre com ícone e uma frase.

## O que você fornece

A mensagem, sem emoticon, e o tipo (`kind`). Opcional: `icon` e `surface`.

## Especificação

- `kind="error"` (padrão): `feedback-fill-negative-loud` com `text-inverse` (4,83:1), ícone ×. "Não deu para enviar. Fale conosco por e-mail."
- `kind="success"`: `surface-inverse` com check. "Entrega agendada", "Código copiado".
- `kind="info"`: `surface-inverse` com (i). "Link do convite copiado".
- `surface="card"`: cartão claro (`surface-primary`, sombra `shadow-high`, raio `radius-xlarge`) com o ícone num círculo de 32px `surface-accent`. Para novidades do ranking, no **topo** da tela: "Ana Souza entrou no seu ranking de amigos!" (`user-plus`) e "Você subiu 3 posições no ranking de amigos!" (`arrow-up`). Com `notify()`, passe `position: 'top-center'`.
- Raio `radius-medium` (16px), sombra `shadow-high`, padding `space-micro` por `space-mini`, texto em `label` (barra escura).
- `tone="app"` reproduz o vermelho de produção anterior do primeiro produto (4,21:1, reprova). Só para documentar.
- Mensagem que precisa ficar na tela vai em `Message`.
- Pendente no handoff: quando dispara o aviso "subiu de posição" (na entrega registrada ou na próxima abertura) e se há notificação além do aviso.

## Acessibilidade

Erro usa `role="alert"`; os demais usam `role="status"`.

## Nas telas da v2

Ranking: [Subiu no ranking](prototipo/#859-10593) e [Amigo entrou](prototipo/#859-9741).

## Base técnica

Visual do aviso (`toastVariants`). No produto, dispare com `notify()` e monte o `Toaster` (Sonner) na raiz: ele cuida de tempo, fila e gesto.

## Código

```
<Soma.Toast kind="success" message="Entrega agendada para seg, 07 set" />
```

```
notify('Ana Souza entrou no seu ranking de amigos!', { kind: 'info', icon: 'user-plus', surface: 'card', position: 'top-center' })
```

---
**Usar para:** Aviso curto e passageiro: erro, confirmação, aviso neutro ou novidade do ranking, sempre com ícone e uma frase.
**Nunca:** guardar informação que a pessoa precisa reler; some sozinho.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
