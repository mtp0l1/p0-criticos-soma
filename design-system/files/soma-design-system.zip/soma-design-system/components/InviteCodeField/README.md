# InviteCodeField

Campo opcional de código de convite, com o estado "Código aplicado" e o link "Onde encontro o código?".

## O que você fornece

O valor, `onChange` e `onHelp` (abre `InviteCodeHelpSheet`). Opcional: `applied` e `error`.

## Especificação

- `TextField` "Código de convite (opcional)", placeholder "Ex.: REC7X4KP", sempre em maiúsculas. Abaixo, a 8px, o link "Onde encontro o código?" em `text-link`.
- Aplicado: "Código aplicado ✓" em `body-small` entre o campo e o link.
- Opcional: quem não recebeu convite pula o campo e cria a conta.
- **Em aberto (Figma):** mensagens para código inválido ou expirado ainda não existem; o `error` fica pronto para receber o texto. O versão anterior também não desenha o botão "Aplicar" que a nota de comportamento cita; hoje o componente só mostra o estado.

## Acessibilidade

"Código aplicado" é `role="status"`, anunciado quando aparece. O link tem área de toque de 44px.

## Nas telas da v2

Cadastro: [Código de convite (vazio)](prototipo/#835-6657) e [Código aplicado](prototipo/#835-6601).

## Código

```
<Soma.InviteCodeField value={codigo} onChange={setCodigo} applied={aplicado} onHelp={() => setAjuda(true)} />
```

---
**Usar para:** Campo opcional de código de convite, com o estado "Código aplicado" e o link "Onde encontro o código?".
**Nunca:** bloquear o cadastro por código inválido: o campo é opcional.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
