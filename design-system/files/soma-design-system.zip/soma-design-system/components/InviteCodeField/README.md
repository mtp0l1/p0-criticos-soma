# InviteCodeField

Campo opcional de código de convite, com o estado "Código aplicado" e o link "Onde encontro o código?".

## O que você fornece

O valor, `onChange` e `onHelp` (abre `InviteCodeHelpSheet`). Opcional: `applied` e `error`.

## Especificação

- Código aplicado: `check` verde dentro do campo e "Código aplicado" em verde.
- "Onde encontro o código?" em botão de texto com seta.

## Acessibilidade

"Código aplicado" é `role="status"`, anunciado quando aparece. O link tem área de toque de 44px.

## Nas telas da v2

Cadastro: [Código de convite (vazio)](prototipo/#835-6657) e [Código aplicado](prototipo/#835-6601).

## Código

```
<Soma.InviteCodeField value={codigo} onChange={setCodigo} applied={aplicado} onHelp={() => setAjuda(true)} />
```

---
**Usar para:** Campo opcional de código de convite, com o estado "Código aplicado" e o link "Onde encontro o código?".
**Nunca:** bloquear o cadastro por código inválido: o campo é opcional.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
