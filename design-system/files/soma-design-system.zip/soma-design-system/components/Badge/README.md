Selo não interativo em pílula (shadcn Badge), em seis tons. É a base de `Tag` e `StatusChip`.

**Você fornece:** o texto e, se for estado, um ícone.

- `tone`: `neutral`, `informative`, `positive`, `caution`, `negative`, `brand`. Fundo e texto vêm dos tokens `feedback-*`, todos acima de 4,5:1.
- Texto de 12px peso 500, altura mínima 24px, `radius-full`, padding `space-micro`.
- Estado sempre com ícone e palavra. O selo não é tocável: se o item for, a linha inteira é.
- `asChild` transforma o selo em link ou botão, com foco visível e sublinhado no hover.

**React:** `<Soma.Badge tone="positive"><Soma.Icon name="check" />Concluído</Soma.Badge>` · `badgeVariants({ tone: 'caution' })`
