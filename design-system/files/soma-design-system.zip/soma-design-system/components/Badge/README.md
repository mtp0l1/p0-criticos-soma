# Badge

Selo não interativo em pílula, em seis tons. É a base de `Tag` e `StatusChip`.

## O que você fornece

O texto e, se for estado, um ícone.

## Especificação

- `tone`: `neutral`, `informative`, `positive`, `caution`, `negative`, `brand`. Fundo e texto vêm dos tokens `feedback-*`, todos acima de 4,5:1.
- Texto de 12px peso 700, altura mínima 24px, `radius-full`, padding de 10px.
- Estado sempre com ícone e palavra. O selo não é tocável: se o item for, a linha inteira é.
- `asChild` transforma o selo em link ou botão, com foco visível e sublinhado no hover.

## Código

```
<Soma.Badge tone="positive"><Soma.Icon name="check" />Concluído</Soma.Badge>
```

```
badgeVariants({ tone: 'caution' })
```

---
**Usar para:** Selo não interativo em pílula, em seis tons.
**Nunca:** ser tocável (use `Button` ou `Tag`) nem carregar texto longo.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
