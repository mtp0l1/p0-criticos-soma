# InstitutionRow

Instituição na lista "Escolha para quem você quer doar seus pontos": cartão branco com o tile do ícone em tom de categoria. Um toque abre a tela de doação daquela instituição.

## O que você fornece

O nome (`name`), a causa em uma linha (`description`), o ícone da causa (`icon`), o tom da categoria (`tint`, opcional: sem ele sai do nome) e `onPress` (ou `href`).

## Especificação

- Cartão `surface-primary`, raio `radius-2xlarge` (28px), sombra `shadow-card` e padding de 14px. Três colunas com `space-micro` entre elas: tile de 60px, texto e um botão redondo de 36px (`surface-secondary`) com a seta.
- Tile de 60px com raio `radius-large` no tom da categoria (`surface-tint-peach`, `-green`, `-blue`, `-lavender`, `-pink` ou `-yellow`) e o ícone de 24px em foreground. O tom muda por categoria da causa, nunca por estado.
- Nome em `label`, causa em `body-small` `text-secondary`. A causa quebra em quantas linhas precisar ("Abrigo, cuidados veterinários e adoção responsável de animais resgatados.").
- Na lista do app: CUFA `peach · shopping-bag`, Ação da Cidadania `green · heart`, Mesa Brasil SESC `blue · utensils`, Instituto Esporte e Educação `lavender · award`, Gol de Letra `pink · sport`, APAE `yellow · users` e Associação S. Francisco de Assis `green · heart`.
- Não é o `InstitutionCard`: o card com foto, descrição e "Saber mais" aparece depois da escolha, na tela de doação.

## Acessibilidade

É um botão (ou link) só; o leitor de tela lê nome e causa juntos. Área de toque maior que 44px.

## Nas telas da v2

Doar pontos: [Escolher instituição](prototipo/#832-6524).

## Código

```
<Soma.InstitutionRow icon="utensils" tint="blue" name="Mesa Brasil SESC" description="Distribuição de alimentos" onPress={abrir} />
```

---
**Usar para:** Instituição na lista "Escolha para quem você quer doar seus pontos".
**Nunca:** pôr dois alvos de toque na mesma linha.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
