# InstitutionRow

Instituição na lista "Escolha para quem você quer doar seus pontos": cartão branco com o tile do ícone em tom de categoria. Um toque abre a tela de doação daquela instituição.

## O que você fornece

O nome (`name`), a causa em uma linha (`description`), o ícone da causa (`icon`), o tom da categoria (`tint`, opcional: sem ele sai do nome) e `onPress` (ou `href`).

## Especificação

- Cartão branco com o ícone num tile pêssego (padrão; `tint` troca o tom), nome, causa e a seta num disco.

## Acessibilidade

É um botão (ou link) só; o leitor de tela lê nome e causa juntos. Área de toque maior que 44px.

## Nas telas da v2

Doar pontos: [Escolher instituição](prototipo/#832-6524).

## Código

```
<Soma.InstitutionRow icon="utensils" tint="blue" name="Mesa Brasil SESC" description="Distribuição de alimentos" onPress={abrir} />
```

---
**Usar para:** Instituição na lista "Escolha para quem você quer doar seus pontos".
**Nunca:** pôr dois alvos de toque na mesma linha.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
