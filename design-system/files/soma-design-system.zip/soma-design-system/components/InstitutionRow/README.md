# InstitutionRow

Instituição na lista "Escolha para quem você quer doar seus pontos". Um toque abre a tela de doação daquela instituição.

## O que você fornece

O nome (`name`), a causa em uma linha (`description`), o ícone da causa (`icon`) e `onPress` (ou `href`).

## Especificação

- Card `surface-secondary` (cinza), raio `radius-large`, padding `space-mini`, 8px entre um e outro. Quadro de 40px com raio `radius-medium` e borda `border-primary`, com o ícone de 20px dentro.
- Nome em `label`, causa em `body-small` `text-secondary`. A causa quebra em quantas linhas precisar ("Abrigo, cuidados veterinários e adoção responsável de animais resgatados.").
- Ícones do handoff anterior: Cufa `shopping-bag`, Ação da Cidadania `heart`, Mesa Brasil Sesc `utensils`, Instituto Esporte e Educação `award`, Gol de Letra `sport`, APAE `users`, Associação S. Francisco de Assis `heart`.
- Não é o `InstitutionCard`: o card com foto, descrição e "Saber mais" aparece depois da escolha, na tela de doação.

## Acessibilidade

É um botão (ou link) só; o leitor de tela lê nome e causa juntos. Área de toque maior que 44px.

## Nas telas da v2

Doar pontos: [Escolher instituição](prototipo/#832-6524).

## Código

```
<Soma.InstitutionRow icon="utensils" name="Mesa Brasil SESC" description="Distribuição de alimentos" onPress={abrir} />
```

---
**Usar para:** Instituição na lista "Escolha para quem você quer doar seus pontos".
**Nunca:** pôr dois alvos de toque na mesma linha.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
