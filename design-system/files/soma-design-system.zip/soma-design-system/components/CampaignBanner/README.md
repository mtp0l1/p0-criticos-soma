# CampaignBanner

Campanha ativa no catálogo e no Início: uma faixa de uma linha.

## O que você fornece

A frase como `children` ("Vidro vale 2× pontos até sexta-feira"). Opcional: `icon` (padrão `bolt`).

## Especificação

- Faixa verde suave, sem borda, com o ícone e o texto em verde.

## Acessibilidade

`section` com rótulo "Campanha ativa"; o ícone é decorativo.

## Nas telas da v2

Recompensas: [Catálogo com meta](prototipo/#854-9534) e [Categoria](prototipo/#854-9429). Antes era um card com título, texto e "Ver regras".

## Código

```
<Soma.CampaignBanner>Vidro vale 2× pontos até sexta-feira</Soma.CampaignBanner>
```

---
**Usar para:** Campanha ativa no catálogo e no Início: uma faixa de uma linha.
**Nunca:** passar de uma linha.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
