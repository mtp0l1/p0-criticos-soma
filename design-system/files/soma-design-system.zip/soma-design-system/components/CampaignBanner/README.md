Campanha ativa no catálogo ou no Início ("Vidro vale o dobro esta semana").

**Você fornece:** título, uma frase de regra e, se houver, um link.

- Fundo `feedback-fill-positive`, borda `feedback-text-positive`, raio `radius-large`. Ícone (padrão `bolt`) em círculo `surface-primary`. Título em `label`, texto em `caption`.
- Uma campanha por vez. Some quando a campanha acaba.

**Acessibilidade:** `section` com o título como nome; o link é botão com texto.

**Figma:** banner de campanha em Recompensas (477:22160): #EAF7EE/#2D6A4F viram os tokens de sucesso.

**React:** `<Soma.CampaignBanner title="Vidro vale o dobro esta semana">Entregas de vidro até domingo rendem 2× pontos.</Soma.CampaignBanner>`
