Campanha ativa no catálogo e no Início: uma faixa de uma linha.

**Você fornece:** a frase como `children` ("Vidro vale 2× pontos até sexta-feira"). Opcional: `icon` (padrão `bolt`).

- Faixa `feedback-fill-positive` com borda `feedback-text-positive`, raio `radius-medium`, padding 12 × 8. Ícone de 16px à esquerda e frase em `caption`, texto em `foreground`.
- Só informa. Não tem título, botão nem link: as regras ficam na própria frase.
- Máximo de uma linha; se a campanha não cabe, encurte a frase.

**Acessibilidade:** `section` com rótulo "Campanha ativa"; o ícone é decorativo.

**Figma:** Recompensas, Telas 1 e 23 (438:1973). Antes era um card com título, texto e "Ver regras".

**React:** `<Soma.CampaignBanner>Vidro vale 2× pontos até sexta-feira</Soma.CampaignBanner>`
