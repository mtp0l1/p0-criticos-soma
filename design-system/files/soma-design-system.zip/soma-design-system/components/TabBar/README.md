Barra de navegação inferior fixa, com os cinco destinos do app. Tem duas versões: a **atual**, das telas novas no Figma, e a **anterior**, do app em produção.

**Você fornece:** o item ativo (`active`), o que acontece ao tocar e, só em tela que ainda não migrou, `version="anterior"`.

- `version="atual"` (padrão): Início, Reciclar, Recompensas, Impacto, Menu. Ícones `home`, `recycle`, `gift`, `chart`, `menu` (os "SVG fornecido" do Figma são esses ícones do Lucide).
- `version="anterior"`: Início, Recompensas, Resgates, Impacto, Menu. Resgates passou para dentro de Recompensas ("Meus resgates").
- Rótulo em `tab-label` (11/14). Inativo: `text-secondary`, peso 400. Ativo: ícone e rótulo em `text-link` (#A64B00, 5,73:1), peso 600, como no Figma.
- Fundo `surface-primary`, divisor de topo `border-primary`, altura `size-tabbar` (64px).
- Cinco itens é o máximo. A barra some em modal, bottom sheet e fluxo de etapas (cadastro, agendamento).

**Acessibilidade:** `nav` com rótulo "Navegação principal"; o ativo leva `aria-current="page"`, então o estado não depende só da cor.

**Base técnica:** é navegação, não abas: `nav` com `aria-current="page"`, por isso não usa Radix Tabs. Itens em `TAB_ITEMS.atual` e `TAB_ITEMS.anterior`.

**Figma:** "Bottom Navigation" em todas as telas novas (ex.: 478:14929).

**React:** `<Soma.TabBar active="reciclar" onNavigate={ir} />` · `<Soma.TabBar version="anterior" active="resgates" />`
