# TabBar

Barra de navegação inferior flutuante, com os cinco destinos do produto.

## O que você fornece

O item ativo (`active`: `inicio`, `reciclar`, `recompensas`, `impacto`, `menu`) e o que acontece ao tocar (`onNavigate`).

## Especificação

- Início, Reciclar, Recompensas, Ranking, Menu, nessa ordem. Ícones `home`, `refresh`, `gift`, `trophy`, `menu` (os "SVG fornecido" da versão anterior são os do Lucide).
- Inativa: só o ícone, em `icon-secondary` (o nome fica para o leitor de tela). Ativa: pílula laranja (`interactive-fill-loud`) com ícone e nome em `text-on-loud` (azul-marinho, 6,2:1), nome em `caption` negrito.
- Barra flutuante: `surface-primary` a 86% com desfoque, raio `radius-3xlarge`, sombra `shadow-float`, altura `size-tabbar` (64px), 16px de cada lado e 24px do fundo. A aba ativa vira pílula laranja com o nome; as outras mostram só o ícone.
- Cinco itens é o máximo. A barra some em modal, bottom sheet e fluxo de etapas (cadastro, agendamento). "Resgates" não é mais um item: fica em Recompensas, em "Meus resgates". A barra antiga, com Resgates, foi removida.

## Acessibilidade

`nav` com rótulo "Navegação principal"; o ativo leva `aria-current="page"`, então o estado não depende só da cor.

## Nas telas da v2

Barra inferior de todas as telas de aba, por exemplo [Início · depois](prototipo/#829-6915) e [Aba Reciclar (nova)](prototipo/#829-7018).

## Base técnica

É navegação, não abas: `nav` com `aria-current="page"`, por isso não usa Tabs. Itens em `TAB_ITEMS`.

## Código

```
<Soma.TabBar active="reciclar" onNavigate={ir} />
```

---
**Usar para:** Barra de navegação inferior flutuante, com os cinco destinos do produto.
**Nunca:** ter mais ou menos de cinco destinos, nem esconder em tela de fluxo (cadastro, QR).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
