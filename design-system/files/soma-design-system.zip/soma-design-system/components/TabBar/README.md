Barra de navegação inferior fixa, com os cinco destinos do app.

**Você fornece:** o item ativo (`active`: `inicio`, `reciclar`, `recompensas`, `impacto`, `menu`) e o que acontece ao tocar (`onNavigate`).

- Início, Reciclar, Recompensas, Impacto, Menu, nessa ordem. Ícones `home`, `recycle`, `gift`, `chart`, `menu` (os "SVG fornecido" do Figma são os do Lucide).
- Rótulo em `tab-label` (11/14). Inativo: `text-secondary`, peso 400. Ativo: ícone e rótulo em `text-link` (#A64B00, 5,73:1), peso 600.
- Fundo `surface-primary`, divisor de topo `border-primary`, altura `size-tabbar` (64px).
- Cinco itens é o máximo. A barra some em modal, bottom sheet e fluxo de etapas (cadastro, agendamento). "Resgates" não é mais um item: fica em Recompensas, em "Meus resgates". A barra antiga, com Resgates, foi removida.

**Acessibilidade:** `nav` com rótulo "Navegação principal"; o ativo leva `aria-current="page"`, então o estado não depende só da cor.

**Base técnica:** é navegação, não abas: `nav` com `aria-current="page"`, por isso não usa Radix Tabs. Itens em `TAB_ITEMS`.

**Figma:** "Bottom Navigation" em todas as telas novas.

**React:** `<Soma.TabBar active="reciclar" onNavigate={ir} />`

---
**Usar para:** Barra de navegação inferior fixa, com os cinco destinos do app.
**Nunca:** ter mais ou menos de cinco destinos, nem esconder em tela de fluxo (cadastro, QR).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
