Escolha de data ou horário em fileira rolável, no agendamento da entrega.

**Você fornece:** o rótulo do grupo ("Escolha a data"), os horários ou dias (`slots`) e o valor escolhido.

- Rótulo em `eyebrow` maiúsculo. Cada opção: mínimo 44×44px, raio `radius-medium` (12px), borda `border-primary`. Dia com dia da semana em `caption` em cima e número em 14px bold.
- Escolhido: `interactive-fill-loud` com `text-on-loud` (no Figma o texto é branco, 2,05:1: aqui não).
- Indisponível (domingo, horário cheio): `interactive-fill-disabled` com texto apagado, **sem risco** (o Figma mostra só o cinza), lido como "indisponível".
- A fileira sangra até a borda da tela e rola na horizontal.

**Acessibilidade:** Radix RadioGroup: um ponto de tabulação, setas movem a escolha; cada opção é lida por completo ("Seg 07").

**Figma:** "Section-Date" e "Section-Hora" em escolha-espaco (477:9343, 578:5517); Telas 27 e 30 (443:12890 e 443:13368). As opções do Figma têm 42×52px (data) e 42×40px (hora); aqui mantêm 44px de largura e de altura mínimas.

**React:** `<Soma.SlotPicker label="Escolha a data" slots={[{ value: '07', label: '07', sublabel: 'Seg' }]} value={d} onChange={setD} />`

---
**Usar para:** Escolha de data ou horário em fileira rolável, no agendamento da entrega.
**Nunca:** mostrar horário cheio sem marcar "indisponível" para o leitor de tela.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
