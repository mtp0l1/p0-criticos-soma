# SlotPicker

Escolha de data ou horário no agendamento da entrega, em grade ou em fileira rolável.

## O que você fornece

O rótulo (`label`), os itens (`slots`), a escolha (`value` e `onChange`) e, se precisar, um aviso (`note`) e a grade (`wrap`).

## Especificação

- Rótulo em eyebrow. `note` aparece à direita e explica o que está fechado: "Domingo fechado", "Casa so+ma Batel abre às 9h".
- No agendamento da v2, `wrap` mostra 7 colunas. Os horários vão de 08h a 17h, a última hora antes de o espaço fechar às 18h.
- Sem `wrap`, é uma fileira rolável.
- Indisponível (domingo, antes de o espaço abrir): `interactive-fill-disabled` com texto apagado, sem risco, lido como "indisponível".

## Acessibilidade

RadioGroup: um ponto de tabulação, setas movem a escolha; cada opção é lida por completo ("Seg 07").

## Nas telas da v2

Escolha de data e horário no agendamento: [Espaço de recebimento](prototipo/#842-9952) e [Escolha do espaço](prototipo/#842-9467). As opções da versão anterior tinham 42×52px (data) e 42×40px (hora); aqui mantêm 44px de largura e de altura mínimas.

## Código

```
<Soma.SlotPicker label="Escolha o horário" note="Casa so+ma Batel abre às 9h" wrap slots={horarios} value={h} onChange={setH} />
```

---
**Usar para:** Escolha de data ou horário em fileira rolável, no agendamento da entrega.
**Nunca:** mostrar horário cheio sem marcar "indisponível" para o leitor de tela.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
