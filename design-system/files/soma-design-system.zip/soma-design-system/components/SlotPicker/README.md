Escolha de data ou horário em fileira rolável, no agendamento da entrega.

**Você fornece:** o rótulo do grupo ("Escolha a data"), os horários ou dias (`slots`) e o valor escolhido.

- Rótulo em `eyebrow` maiúsculo. Cada opção: mínimo 48×44px, raio `radius-small`, borda `border-primary`. Dia com dia da semana em `caption` em cima e número em 14px bold.
- Escolhido: `interactive-fill-loud` com `text-on-loud` (no Figma o texto é branco, 2,05:1: aqui não).
- Indisponível (domingo, horário cheio): `interactive-fill-disabled`, texto riscado, lido como "indisponível".
- A fileira sangra até a borda da tela e rola na horizontal.

**Acessibilidade:** Radix RadioGroup: um ponto de tabulação, setas movem a escolha; cada opção é lida por completo ("Seg 07").

**Figma:** "Section-Date" e "Section-Hora" em escolha-espaco (477:9343, 578:5517).

**React:** `<Soma.SlotPicker label="Escolha a data" slots={[{ value: '07', label: '07', sublabel: 'Seg' }]} value={d} onChange={setD} />`
