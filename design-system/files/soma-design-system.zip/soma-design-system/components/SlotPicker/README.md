# SlotPicker

Escolha de data ou horário em fileira rolável, no agendamento da entrega.

## O que você fornece

O rótulo do grupo ("Escolha a data"), os horários ou dias (`slots`) e o valor escolhido.

## Especificação

- Rótulo em `eyebrow` maiúsculo. Cada opção: mínimo 44×44px, raio `radius-medium` (12px), borda `border-primary`. Dia com dia da semana em `caption` em cima e número em 14px bold.
- Escolhido: `interactive-fill-loud` com `text-on-loud` (no handoff anterior o texto é branco, 2,05:1: aqui não).
- Indisponível (domingo, horário cheio): `interactive-fill-disabled` com texto apagado, **sem risco** (o handoff anterior mostra só o cinza), lido como "indisponível".
- A fileira sangra até a borda da tela e rola na horizontal.

## Acessibilidade

Radix RadioGroup: um ponto de tabulação, setas movem a escolha; cada opção é lida por completo ("Seg 07").

## Nas telas da v2

Escolha de data e horário no agendamento: [Espaço de recebimento](prototipo/#842-9952) e [Escolha do espaço](prototipo/#842-9467). As opções do handoff anterior tinham 42×52px (data) e 42×40px (hora); aqui mantêm 44px de largura e de altura mínimas.

## Código

```
<Soma.SlotPicker label="Escolha a data" slots={[{ value: '07', label: '07', sublabel: 'Seg' }]} value={d} onChange={setD} />
```

---
**Usar para:** Escolha de data ou horário em fileira rolável, no agendamento da entrega.
**Nunca:** mostrar horário cheio sem marcar "indisponível" para o leitor de tela.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
