Lista numerada das etapas de uma missão, com concluídas, atual e pendentes.

**Você fornece:** as etapas e o status de cada uma.

- Concluída: check em `feedback-fill-positive`/`feedback-text-positive`, texto `text-primary`. Atual: número em `interactive-fill-loud`, texto em negrito. Pendente: número em círculo `border-strong`, texto `text-secondary`.
- Uma etapa só conta como concluída quando a pessoa fez a ação. "Adicionar local de entrega" nunca vem marcada pelo padrão "Sem preferência de espaço".

**Acessibilidade:** lista ordenada; a atual tem `aria-current="step"` e cada item diz o status em texto oculto.

**React:** `<Soma.StepChecklist steps={[{ label: 'Cadastro concluído', status: 'done' }]} />`
