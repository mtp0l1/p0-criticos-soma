Troféu ilustrado do nível no Quiz: uma pilha de pontos com uma estrela, dentro de um círculo. Bronze tem 1 estrela, Prata 2 e Ouro 3. Substitui a medalha da versão anterior: no redesign o prêmio é um troféu.

**Você fornece:** o nível (`tier`: `bronze`, `prata` ou `ouro`) e o tamanho (`size`: `md` 96px ou `lg` 120px). A arte do Figma já vem embutida; `src` só serve para trocar por outra imagem.

- `md` (96px) vai nos cartões de nível (`TierCard`) e no Histórico (`HistorySummary`). `lg` (120px) vai no topo do Quiz (`LevelCard`).
- A arte é a do Figma: `icone-nivel-bronze`, `icone-nivel-prata` e `icone-nivel-ouro`. Prata e Ouro só existem em 96px no Figma; no `lg` elas são ampliadas.
- Só existem os três níveis do redesign. Ferro e Platina foram removidos.
- Todas as ilustrações do sistema estão no capítulo "Ilustrações" (`6-ilustracoes.md`).

**Acessibilidade:** imagem com texto alternativo ("Troféu Bronze, 1 estrela"). Mesmo assim, escreva o nível em texto ao lado (`LevelBadge` ou título).

**Figma:** Quiz, "icone-nivel-bronze" (443:15377, 443:15947), "icone-nivel-prata" (443:15956) e "icone-nivel-ouro" (443:15965).

**React:** `<Soma.Trophy tier="ouro" />` · `<Soma.Trophy tier="bronze" size="lg" />`

---
**Usar para:** Troféu ilustrado do nível no Quiz: uma pilha de pontos com uma estrela, dentro de um círculo.
**Nunca:** trocar por medalha ou por ilustração nova sem registro.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
