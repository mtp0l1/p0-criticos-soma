Lista dos níveis do quiz, de Ferro a Platina, com medalha e o que é preciso para chegar a cada um.

**Você fornece:** os níveis (`tier`) e a descrição de cada um.

- Medalha de `size-medal` em `surface-inverse`, nome em `label`, descrição em `caption` e `text-secondary`. Divisor `border-primary` entre itens.
- O app usa a mesma arte de medalha para todos os níveis: a diferença está só no nome. Quando a arte por nível existir, ela entra em `Medal`.
- Descrição curta e concreta (quantas respostas certas), sem texto corrido.

**Acessibilidade:** lista `ul`; cada medalha tem rótulo "Medalha Bronze".

**React:** `<Soma.LevelList levels={[{ tier: 'ferro', description: 'Comece com a medalha de ferro.' }]} />`
