# HistorySummary

Topo do Histórico do Quiz (Tela 4): o troféu do nível, quando subiu e os totais.

## O que você fornece

O nível (`tier`), o total (`total`), a última resposta (`last`) e, se houver, quando subiu de nível (`since`).

## Especificação

- Faixa azul-marinho com o troféu, a etiqueta e a data do nível; abaixo, dois cartões brancos com os totais.

## Nas telas da v2

Quiz: [Histórico](prototipo/#849-9313).

## Código

```
<Soma.HistorySummary tier="bronze" since="26/08/2026" total={7} last="28/08/2026" />
```

---
**Usar para:** Topo do Histórico do Quiz (Tela 4): o troféu do nível, quando subiu e os totais.
**Nunca:** misturar medalha e troféu.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
