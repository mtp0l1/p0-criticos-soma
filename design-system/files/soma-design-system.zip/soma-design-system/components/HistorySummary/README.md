Resumo do Histórico do Quiz: nível atual, total de respostas e a última.

**Você fornece:** o nível (`tier`), o total (`total`), a última resposta (`last`) e, se houver, quando subiu de nível (`since`). Com a arte exportada, passe `src`.

- Faixa `surface-secondary` com `Medal` `md`, `LevelBadge` e "Avançou de nível em 26/08/2026". Abaixo, dois blocos: "Total de respostas" e "Última resposta".
- Abre o `AnswerHistory` com a lista do mês.

**Figma:** Quiz, Tela 4 (443:15190).

**React:** `<Soma.HistorySummary tier="bronze" since="26/08/2026" total={7} last="28/08/2026" />`
