# HistorySummary

Topo do Histórico do Quiz (Tela 4): o troféu do nível, quando subiu e os totais.

## O que você fornece

O nível (`tier`), o total (`total`), a última resposta (`last`) e, se houver, quando subiu de nível (`since`).

## Especificação

- Faixa `surface-secondary` de raio `radius-large` com o `Trophy` de 96px, o `LevelBadge` e "Avançou de nível em 26/08/2026" (12px). Abaixo, dois blocos de 10px de espaço interno: "Total de respostas" e "Última resposta".
- Vem depois do cabeçalho "Histórico" e antes do `AnswerHistory`.

## Nas telas da v2

Quiz: [Histórico](prototipo/#849-9313).

## Código

```
<Soma.HistorySummary tier="bronze" since="26/08/2026" total={7} last="28/08/2026" />
```

---
**Usar para:** Topo do Histórico do Quiz (Tela 4): o troféu do nível, quando subiu e os totais.
**Nunca:** misturar medalha e troféu.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
