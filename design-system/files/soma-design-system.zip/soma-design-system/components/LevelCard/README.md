# LevelCard

Topo do Quiz (Telas 1 e 3): o troféu do nível, a etiqueta e quantas perguntas faltam para o próximo. Mostra Bronze, Prata ou Ouro.

## O que você fornece

O nível (`tier`) e quantas perguntas faltam (`remaining`). No Ouro, omita `remaining`.

## Especificação

- Cartão azul-marinho: troféu num disco pêssego à esquerda, etiqueta do nível e quantas perguntas faltam.
- Barra com o avanço até o próximo nível, calculada pela meta de perguntas dele.

## Acessibilidade

A frase de progresso é texto real; o troféu tem texto alternativo.

## Nas telas da v2

Quiz: [Pergunta do dia](prototipo/#849-8934) e [Já respondeu hoje](prototipo/#849-9175), no selo do reciclador.

## Código

```
<Soma.LevelCard tier="bronze" remaining={8} />
```

```
<Soma.LevelCard tier="prata" remaining={3} />
```

```
<Soma.LevelCard tier="ouro" />
```

---
**Usar para:** Topo do Quiz (Telas 1 e 3): o troféu do nível, a etiqueta e quantas perguntas faltam para o próximo.
**Nunca:** mostrar Ferro ou Platina: só Bronze, Prata e Ouro existem.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
