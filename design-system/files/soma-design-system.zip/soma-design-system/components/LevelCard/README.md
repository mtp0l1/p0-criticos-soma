Card de nível do redesign do quiz: medalha grande, nome do nível e quantas perguntas faltam para o próximo. Aparece no topo do Quiz e do Histórico.

**Você fornece:** o nível (`tier`) e quantas perguntas faltam (`remaining`). No Ouro, omita `remaining`. Com a arte exportada, passe `src`.

- `Medal` `lg` em cima, `LevelBadge` com o nome e, embaixo, "Faltam 3 perguntas para Prata". No Ouro: "Você chegou ao nível mais alto".
- Singular e plural: "Falta 1 pergunta para Prata".
- Não tem barra nem percentual: o redesign trocou a barra por uma frase. A progressão por semanas fica no `StreakProgress`.
- Substitui o `LevelCard` e o `LevelList` da versão antiga (cartões com Ferro e Platina), que foram removidos. A lista de níveis agora é `TierCard`.

**Acessibilidade:** a frase de progresso é texto real; a medalha é decorativa.

**Figma:** Quiz, Tela 1 (443:15190).

**React:** `<Soma.LevelCard tier="bronze" remaining={3} />`
