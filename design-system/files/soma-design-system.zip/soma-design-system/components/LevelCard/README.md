Card do nível atual do quiz: medalha, nome do nível, percentual, barra e quantas perguntas faltam.

**Você fornece:** o nível (`tier`), o percentual, quantas perguntas faltam e o destino de "Ver níveis".

- Card `surface-primary` com borda `border-primary`, raio `radius-large`, padding `space-mini`.
- Barra contínua de 6px: trilho `border-primary`, preenchimento `selected-indicator`. O percentual em texto acompanha a barra.
- Atualize percentual, barra e contador assim que o modal de acerto fechar, sem a pessoa sair da tela (hoje o app só atualiza ao voltar).
- Singular e plural: "Falta 1 pergunta", "Faltam 3 perguntas".

**Acessibilidade:** a barra é `progressbar` com `aria-valuenow`.

**Base técnica:** `Card` + Radix `Progress` + `Medal`.

**React:** `<Soma.LevelCard tier="ferro" percent={40} remaining={3} onSeeLevels={abrirNiveis} />`
