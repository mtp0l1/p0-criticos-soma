# LevelCard

Topo do Quiz (Telas 1 e 3): o troféu do nível, a etiqueta e quantas perguntas faltam para o próximo. Mostra Bronze, Prata ou Ouro.

## O que você fornece

O nível (`tier`) e quantas perguntas faltam (`remaining`). No Ouro, omita `remaining`.

## Especificação

- `Trophy` `lg` (120px) em cima, `LevelBadge` com o nome do nível e, embaixo, "Faltam 8 perguntas para Prata" (12px, `text-secondary`). No Ouro: "Você chegou ao nível mais alto".
- Singular e plural: "Falta 1 pergunta para Prata".
- Não tem barra nem percentual: o redesign trocou a barra por uma frase. A progressão por semanas fica no `StreakProgress`.
- Substitui o `LevelCard` e o `LevelList` da versão antiga (cartões com Ferro e Platina), que foram removidos. A lista de níveis agora é `TierCard`.

## Acessibilidade

A frase de progresso é texto real; o troféu tem texto alternativo.

## Nas telas da v2

Quiz: [Pergunta do dia](prototipo/#849-8934) e [Já respondeu hoje](prototipo/#849-9175), no selo do reciclador.

## Código

```
<Soma.LevelCard tier="bronze" remaining={8} />
```

```
<Soma.LevelCard tier="prata" remaining={3} />
```

```
<Soma.LevelCard tier="ouro" />
```

---
**Usar para:** Topo do Quiz (Telas 1 e 3): o troféu do nível, a etiqueta e quantas perguntas faltam para o próximo.
**Nunca:** mostrar Ferro ou Platina: só Bronze, Prata e Ouro existem.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
