# DonationAmountCard

Valor da doação: número grande, saldo logo abaixo e erro em espaço reservado. Vem com o NumericKeypad.

## O que você fornece

O saldo (`balance`), o valor (`value`, `null` quando vazio) e `onChange`. Com teclado na tela, passe `keypad` e coloque o `NumericKeypad` no pé, abaixo do botão "Doar".

## Especificação

- Pergunta em `body-small`, número em 48px e "pts" ao lado, na mesma linha de base.
- O saldo "Você tem 320 pontos" é uma pílula logo abaixo do número.
- O erro ("Digite um número maior que zero." ou saldo insuficiente) aparece abaixo do saldo, num espaço de 56px reservado: pergunta, saldo e botão não mudam de lugar entre os estados.
- `NumericKeypad`: 3 colunas, teclas de 52px, de 1 a 9, 0 e apagar. Aceita até 6 dígitos (`maxLength`).

## Acessibilidade

O número é um campo com rótulo visível; o erro é anunciado (`role="alert"`) e ligado ao campo. As teclas são botões, e "Apagar" tem nome. Com `keypad`, o teclado do aparelho não abre, e o teclado físico continua funcionando.

## Nas telas da v2

[Valor da doação](prototipo/#832-6750), [Campo vazio](prototipo/#832-6686), [Valor zero](prototipo/#832-6884) e [Valor maior que o saldo](prototipo/#832-6819).

## Código

```
<Soma.DonationAmountCard balance={320} value={valor} onChange={setValor} keypad />
<Soma.Button fullWidth disabled={!podeDoar}>Doar</Soma.Button>
<Soma.NumericKeypad value={valor} onChange={setValor} />
```

```
disabled={valor === null || !!Soma.donationError(valor, 1130)}
```

---
**Usar para:** a tela em que a pessoa digita quantos pontos quer doar.
**Nunca:** esconder o saldo: ele aparece no cartão junto do campo.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
