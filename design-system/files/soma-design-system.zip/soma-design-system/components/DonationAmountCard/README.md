# DonationAmountCard

Cartão "Quantos pontos deseja doar?" da tela de doação: saldo, campo de quantidade e mensagem de erro.

## O que você fornece

O saldo (`balance`), o valor digitado (`value`, `null` quando vazio) e `onChange`. O erro sai sozinho de `donationError(value, balance)`; passe `error` só para trocar o texto.

## Especificação

- Cartão `surface-card` com borda, raio `radius-xlarge`, padding `space-mini`, 16px entre título e campo. Título em `body-strong`, "Você tem **1.130 pontos**" em `caption` com o saldo em `text-link` (na versão anterior é laranja #DD8613, que não passa no contraste).
- Campo `TextField` "Quantidade de pontos", placeholder "Digite um número", teclado numérico. **Só números inteiros**: letras, vírgula, ponto, sinal e texto colado são descartados, e o número aparece com separador de milhar.
- Doação livre, sem mínimo nem máximo (decisão da Tati e do Marco). Erros: **vazio** não mostra erro e o "Doar" fica desabilitado; **zero** "Digite um número maior que zero."; **acima do saldo** "Você não tem saldo suficiente para doar essa quantidade.".
- O "Doar" fica **fora** do cartão, 32px abaixo, e segue o conteúdo (não prende no fim da tela). Habilite quando `donationError` voltar `undefined` e o campo não estiver vazio.
- Os pontos só saem do saldo quando o servidor confirma a doação.

## Acessibilidade

`section` "Quantidade a doar"; o erro é lido junto do campo (`aria-describedby`).

## Nas telas da v2

Doar pontos: [Campo vazio](prototipo/#832-6686), [Valor zero](prototipo/#832-6884), [Valor maior que o saldo](prototipo/#832-6819) e [Valor da doação](prototipo/#832-6750).

## Código

```
<Soma.DonationAmountCard balance={1130} value={valor} onChange={setValor} />
```

```
disabled={valor === null || !!Soma.donationError(valor, 1130)}
```

---
**Usar para:** Cartão "Quantos pontos deseja doar?" da tela de doação: saldo, campo de quantidade e mensagem de erro.
**Nunca:** esconder o saldo: ele aparece no cartão junto do campo.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
