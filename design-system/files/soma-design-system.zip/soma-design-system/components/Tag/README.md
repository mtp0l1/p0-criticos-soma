# Tag

Etiqueta de categoria (Plástico, Cartonado). Informa e não é tocável.

## O que você fornece

O texto e, se ajudar, um ícone.

## Especificação

- Pílula `radius-full` em `feedback-fill-caution` com `feedback-text-caution` (4,51:1), texto de 12px peso 500.
- Para estado de resgate use `StatusChip`; para filtro tocável use `ChoiceChips`.

## Base técnica

`Badge tone="caution"`.

## Código

```
<Soma.Tag icon="recycle">Plástico</Soma.Tag>
```

---
**Usar para:** Etiqueta de categoria (Plástico, Cartonado).
**Nunca:** ser tocável nem passar de uma palavra ou duas.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
