Etiqueta de categoria (Plástico, Cartonado). Informa e não é tocável.

**Você fornece:** o texto e, se ajudar, um ícone.

- Pílula `radius-full` em `feedback-fill-caution` com `feedback-text-caution` (4,51:1), texto de 12px peso 500.
- Para estado de resgate use `StatusChip`; para filtro tocável use `ChoiceChips`.

**Base técnica:** `Badge tone="caution"`.

**React:** `<Soma.Tag icon="recycle">Plástico</Soma.Tag>`
