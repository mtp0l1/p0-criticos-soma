Modal "Saber mais" de uma instituição: banner, nome, texto longo e contatos.

**Você fornece:** nome, descrição e, se houver, endereço, telefone e site. Opcional: `image` (banner de 160px de altura) e `trigger` (ou controle com `open`/`onOpenChange`).

- Cartão de 320px com raio `radius-large`, sem padding no topo: o banner (320 × 160) ocupa a largura toda, com um X de 32px (branco a 90%, borda) no canto superior direito. Sem `image`, um quadro cinza com o ícone `hand-heart`.
- Abaixo, padding de 20px e 16px entre blocos: nome em `screen-title`, descrição em `body-small` `text-secondary`, divisor de 1px e a lista de contatos com círculo de 24px `border-primary` (`pin`, `phone`, `globe`). O site vai em semibold e sublinhado; telefone e site são links (`tel:` e `https:`).
- Fecha pelo X, por Esc ou tocando na película. O foco volta para o "Saber mais" que abriu.
- O que a instituição não tiver (telefone, site) simplesmente não aparece.

**Acessibilidade:** `dialog` com o nome como título e a descrição como descrição; o X tem rótulo "Fechar" e área de toque de 44px.

**Figma:** Doar pontos, "Saber mais" (463:5027).

**React:** `<Soma.InstitutionDetailModal trigger={<Soma.Button hierarchy="quiet">Saber mais</Soma.Button>} name="Associação S. Francisco de Assis" description="…" address="Rua das Flores, 123 - São Paulo, SP" phone="(11) 98765-4321" site="www.saofranciscoanimais.org.br" />`