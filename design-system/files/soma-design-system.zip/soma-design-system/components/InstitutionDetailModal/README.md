# InstitutionDetailModal

Modal "Saber mais" de uma instituição: banner, nome, texto longo e contatos.

## O que você fornece

Nome, descrição e, se houver, endereço, telefone e site. Opcional: `image` (banner de 160px de altura) e `trigger` (ou controle com `open`/`onOpenChange`).

## Especificação

- Cartão de 320px com raio `radius-large`, sem padding no topo: o banner (320 × 160) ocupa a largura toda, com um X de 32px (branco a 90%, borda) no canto superior direito. Sem `image`, um quadro cinza com o ícone `hand-heart`.
- Abaixo, padding de 20px e 16px entre blocos: nome em `screen-title`, descrição em `body-small` `text-secondary`, divisor de 1px e a lista de contatos com círculo de 24px `border-primary` (`pin`, `phone`, `globe`). O site vai em semibold e sublinhado; telefone e site são links (`tel:` e `https:`).
- Fecha pelo X, por Esc ou tocando na película. O foco volta para o "Saber mais" que abriu.
- O que a instituição não tiver (telefone, site) simplesmente não aparece.

## Acessibilidade

`dialog` com o nome como título e a descrição como descrição; o X tem rótulo "Fechar" e área de toque de 44px.

## Nas telas da v2

Doar pontos: "Saber mais" ([Encontrar instituição](prototipo/#832-7246)).

## Código

```
<Soma.InstitutionDetailModal trigger={<Soma.Button hierarchy="quiet">Saber mais</Soma.Button>} name="Associação S. Francisco de Assis" description="…" address="Rua das Flores, 123 - São Paulo, SP" phone="(11) 98765-4321" site="www.saofranciscoanimais.org.br" />
```

---
**Usar para:** Modal "Saber mais" de uma instituição: banner, nome, texto longo e contatos.
**Nunca:** servir de tela de doação: ele abre pelo "Saber mais", a doação fica na tela de doar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
