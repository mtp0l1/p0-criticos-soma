# InstitutionDetailModal

Folha "Saber mais" de uma instituição: faixa com o coração, cidade, nome, texto com "Ler mais" e contatos.

## O que você fornece

Nome, descrição e, se houver, endereço, telefone e site. Opcional: `image` (imagem real da instituição), `city`, `onDonate` e `trigger` (ou controle com `open`/`onOpenChange`).

## Especificação

- Folha inferior com faixa pêssego de 132px (ou a imagem real) e "Fechar" no canto.
- Cidade em etiqueta (`city`), nome, texto em quatro linhas com "Ler mais" e os contatos num cartão.
- `onDonate` mostra "Doar para esta instituição", que leva à tela de valor.

## Acessibilidade

`dialog` com o nome como título e a descrição como descrição; o X tem rótulo "Fechar" e área de toque de 44px.

## Nas telas da v2

Doar pontos: "Saber mais" ([Encontrar instituição](prototipo/#832-7246)).

## Código

```
<Soma.InstitutionDetailModal trigger={<Soma.Button hierarchy="quiet">Saber mais</Soma.Button>} name="Associação S. Francisco de Assis" description="…" address="Rua das Flores, 123 - São Paulo, SP" phone="(11) 98765-4321" site="www.saofranciscoanimais.org.br" />
```

---
**Usar para:** Modal "Saber mais" de uma instituição: banner, nome, texto longo e contatos.
**Nunca:** trocar a faixa por foto gerada: sem imagem real da instituição, fica o coração.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
