Entrega anterior na lista de Meus agendamentos: onde foi, quando e a situação.

**Você fornece:** o espaço (`space`), a data (`date`, "31 de agosto") e a situação (`status`, "Entrega registrada às 09h").

- Card `surface-card` com borda, raio `radius-medium`, padding 12px. Primeira linha: espaço em `label` à esquerda e data em `caption` `text-secondary` à direita. Segunda linha: a situação em `caption`.
- Fica sob o rótulo "ENTREGAS ANTERIORES" (`SectionHeader size="eyebrow"`).
- O app **não acompanha** se a entrega aconteceu: a linha só aparece quando a equipe registrou a entrega. Não crie estado "perdida" ou "cancelada".
- Não use evento recorrente no calendário: cada entrega é um evento só (nota do Figma).

**Acessibilidade:** `article` com o espaço como título (`h3`).

**Figma:** Tela 7, Meus agendamentos (443:13091).

**React:** `<Soma.DeliveryHistoryRow space="Vila Verde" date="31 de agosto" status="Entrega registrada às 09h" />`