# DeliveryHistoryRow

Entrega anterior na lista de Meus agendamentos: onde foi, quando e a situação.

## O que você fornece

O espaço (`space`), a data (`date`, "31 de agosto") e a situação (`status`, "Entrega registrada às 09h").

## Especificação

- Card `surface-card` com borda, raio `radius-medium`, padding 12px. Primeira linha: espaço em `label` à esquerda e data em `caption` `text-secondary` à direita. Segunda linha: a situação em `caption`.
- Fica sob o rótulo "ENTREGAS ANTERIORES" (`SectionHeader size="eyebrow"`).
- O produto **não acompanha** se a entrega aconteceu: a linha só aparece quando a equipe registrou a entrega. Não crie estado "perdida" ou "cancelada".
- Não use evento recorrente no calendário: cada entrega é um evento só (nota do handoff anterior).

## Acessibilidade

`article` com o espaço como título (`h3`).

## Nas telas da v2

Ativação: [Meus agendamentos](prototipo/#842-9688).

## Código

```
<Soma.DeliveryHistoryRow space="Vila Verde" date="31 de agosto" status="Entrega registrada às 09h" />
```

---
**Usar para:** Entrega anterior na lista de Meus agendamentos: onde foi, quando e a situação.
**Nunca:** misturar entrega futura e passada.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
