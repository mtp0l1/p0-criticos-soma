# DeliveryHistoryRow

Entrega anterior na lista de Meus agendamentos: onde foi, quando e a situação.

## O que você fornece

O espaço (`space`), a data (`date`, "31 de agosto") e a situação (`status`, "Entrega registrada às 09h").

## Especificação

- Cartão branco: disco verde com `check`, o espaço e, na linha de baixo, a data e a situação.

## Acessibilidade

`article` com o espaço como título (`h3`).

## Nas telas da v2

Ativação: [Meus agendamentos](prototipo/#842-9688).

## Código

```
<Soma.DeliveryHistoryRow space="Vila Verde" date="31 de agosto" status="Entrega registrada às 09h" />
```

---
**Usar para:** Entrega anterior na lista de Meus agendamentos: onde foi, quando e a situação.
**Nunca:** misturar entrega futura e passada.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
