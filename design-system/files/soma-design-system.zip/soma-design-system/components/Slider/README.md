Escolha de um valor, ou de uma faixa, arrastando uma alça (shadcn Slider, sobre Radix).

**Você fornece:** `value` (uma lista: um número ou dois), `min`, `max`, `step` e o nome de cada alça.

- Trilho de 8px em `surface-track`, preenchimento `selected-indicator`, alça de 24px com borda `text-primary` e área tocável de 44px.
- Hover e pressionado mudam o fundo da alça; foco com o anel do sistema; desabilitado em cinza.
- Mostre sempre o valor em texto ao lado ("500 pontos"): arrastar é impreciso. Quando o valor exato importa, ofereça também um campo numérico.

**Acessibilidade:** cada alça é um `slider` com nome (`aria-label` ou `thumbLabels`); setas mudam um passo, Home e End vão aos extremos.

**React:** `<Soma.Slider value={[v]} onValueChange={([n]) => setV(n)} min={0} max={saldo} step={10} aria-label="Pontos para doar" />`
