Campo de senha com botão de mostrar e ocultar dentro do campo.

**Você fornece:** o mesmo que o `TextField` (rótulo, valor, `helper`, `error`); o `type` e a máscara são do componente.

- Mesmo campo de 48px do `TextField`; o botão `eye` / `eye-off` de 44px fica à direita, em `icon-brand-strong`. Texto de ajuda "Use 6 números." logo abaixo do campo "Senha".
- Passo 05 tem dois campos, "Senha*" e "Repita a senha*", a 24px um do outro. A confirmação precisa ser igual à senha; erro: "As senhas precisam ser iguais." (texto sugerido, o Figma não traz).
- **Diferença do Figma:** o Figma desenha uma seta `chevron-down` laranja dentro do campo, que parece ícone de lista. Aqui virou o botão de mostrar senha, que é o que a pessoa espera num campo de senha. Dúvida levada à Claudia e à Tatiana.

**Acessibilidade:** o botão diz "Mostrar senha" ou "Ocultar senha" e usa `aria-pressed`. `autoComplete="new-password"` para o gerenciador de senhas oferecer uma senha.

**Figma:** Cadastro, Tela 05 (443:9678).

**React:** `<Soma.PasswordField label="Senha" required helper="Use 6 números." inputMode="numeric" value={senha} onChange={setSenha} />`

---
**Usar para:** Campo de senha com botão de mostrar e ocultar dentro do campo.
**Nunca:** mostrar a senha por padrão nem aceitar menos que o texto de ajuda promete (6 caracteres).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
