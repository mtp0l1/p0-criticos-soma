# PasswordField

Campo de senha com botão de mostrar e ocultar dentro do campo.

## O que você fornece

O mesmo que o `TextField` (rótulo, valor, `helper`, `error`); o `type` e a máscara são do componente.

## Especificação

- Mesmo campo de 68px do `TextField`; o botão `eye` / `eye-off` de 44px fica à direita, em `icon-brand-strong`. Texto de ajuda "Pelo menos 8 caracteres, com letra e número." logo abaixo do campo "Senha". É a mesma regra no cadastro e na recuperação de senha.
- Passo 05 tem dois campos, "Senha_" e "Repita a senha_", a 24px um do outro. A confirmação precisa ser igual à senha; erro: "As senhas precisam ser iguais." (texto sugerido, a versão anterior não traz).
- **Diferença da versão anterior:** a versão anterior desenha uma seta `chevron-down` laranja dentro do campo, que parece ícone de lista. Aqui virou o botão de mostrar senha, que é o que a pessoa espera num campo de senha. Dúvida levada à Claudia e à Tatiana.

## Acessibilidade

O botão diz "Mostrar senha" ou "Ocultar senha" e usa `aria-pressed`. `autoComplete="new-password"` para o gerenciador de senhas oferecer uma senha.

## Nas telas da v2

Cadastro: [Senha](prototipo/#835-6551).

## Código

```
<Soma.PasswordField label="Senha" required helper="Pelo menos 8 caracteres, com letra e número." value={senha} onChange={setSenha} />
```

---
**Usar para:** Campo de senha com botão de mostrar e ocultar dentro do campo.
**Nunca:** mostrar a senha por padrão nem aceitar menos que o texto de ajuda promete (6 caracteres).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
