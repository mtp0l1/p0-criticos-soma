Números lado a lado (entregas, quilos, pontos) num bloco neutro.

**Você fornece:** de dois a quatro itens com valor já formatado, rótulo e, se quiser, ícone.

- Fundo `surface-secondary`, raio `radius-large`, divisores verticais `border-primary`. Valor em `stat-number`, rótulo em `caption` `text-secondary`, ícone pequeno em `icon-brand-strong`.
- Para um indicador com explicação, use `StatTile`.

**Acessibilidade:** lista de definição (`dl`): o leitor ouve rótulo e valor juntos.

**Figma:** resumo da Ativação (entregas, kg, pontos).

**React:** `<Soma.StatsRow items={[{ value: '3', label: 'entregas', icon: 'package' }]} />`

---
**Usar para:** Números lado a lado (entregas, quilos, pontos) num bloco neutro.
**Nunca:** passar de três números.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
