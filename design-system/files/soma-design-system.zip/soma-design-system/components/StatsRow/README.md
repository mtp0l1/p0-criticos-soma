# StatsRow

Números lado a lado (entregas, quilos, pontos) num bloco neutro.

## O que você fornece

De dois a quatro itens com valor já formatado, rótulo e, se quiser, ícone.

## Especificação

- Fundo `surface-secondary`, raio `radius-large`, divisores verticais `border-primary`. Valor em `stat-number`, rótulo em `caption` `text-secondary`, ícone pequeno em `icon-brand-strong`.
- Para um indicador com explicação, use `StatTile`.

## Acessibilidade

Lista de definição (`dl`): o leitor ouve rótulo e valor juntos.

## Nas telas da v2

Resumo da Ativação (entregas, kg, pontos).

## Código

```
<Soma.StatsRow items={[{ value: '3', label: 'entregas', icon: 'package' }]} />
```

---
**Usar para:** Números lado a lado (entregas, quilos, pontos) num bloco neutro.
**Nunca:** passar de três números.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
