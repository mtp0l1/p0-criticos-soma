# AnswerResult

Tela cheia com o resultado da pergunta do dia, no acerto (2A) ou no erro (2B). Substitui o modal de "resposta correta" da versão antiga.

## O que você fornece

Se acertou (`correct`), a resposta certa (`answer`) e a explicação (`explanation`). No acerto: `points` e `weeks`. Opcional: `message`, `art`, `onContinue` e `secondary` (`{ label, onClick | href }`).

## Especificação

- Topo em `primary` no acerto e em azul-marinho no erro, com a etiqueta do resultado e o mascote num círculo branco.
- Folha clara por baixo: resposta certa, "Por quê?" num cartão e, no acerto, as pílulas de sequência e pontos.
- "Continuar" e a ação secundária ficam no pé.

## Acessibilidade

`section` nomeada pelo título; o resultado vem em texto ("Você acertou!"), não só pela cor ou pela ilustração, que é decorativa.

## Nas telas da v2

Quiz: [Resposta certa](prototipo/#849-9097) e [Resposta errada](prototipo/#849-9426).

## Código

```
<Soma.AnswerResult correct answer="Dióxido de Carbono (CO₂)" explanation={texto} points={15} weeks={2} onContinue={fechar} secondary={{ label: 'Convidar amigos' }} />
```

---
**Usar para:** Tela cheia com o resultado da pergunta do dia, no acerto (2A) ou no erro (2B).
**Nunca:** mostrar medalha: o nível é troféu (`Trophy`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
