Tela cheia com o resultado da pergunta do dia, no acerto (2A) ou no erro (2B). Substitui o modal de "resposta correta" da versão antiga.

**Você fornece:** se acertou (`correct`), a resposta certa (`answer`) e a explicação (`explanation`). No acerto: `points` e `weeks`. Opcional: `message`, `art`, `onContinue` e `secondary` (`{ label, onClick | href }`).

- Faixa de cima: pílula "VOCÊ ACERTOU!" (verde) ou "NÃO FOI DESSA VEZ" (vermelha) e a ilustração do mascote da lata, de 200px: feliz no acerto, em dúvida no erro. A arte vem embutida (`mascote-lata-acerto` e `mascote-lata-erro`).
- Depois: "A resposta certa é" (no erro, "era"), a resposta em 18px, "Por quê?" com a explicação e, no acerto, "Pontos ganhos" com a frase "Volte amanhã para manter sua sequência!" e as duas pílulas: "2 semanas seguidas" (verde) e "+15 pontos" (creme com contorno laranja e estrela).
- Erro: "Continue aprendendo para subir de nível.", sem pontos e sem culpa.
- "Continuar" é `loud`, largura total. Embaixo, o link sublinhado: "Convidar amigos" no acerto, "Volte amanhã para a próxima pergunta" no erro.
- A tela ocupa o conteúdo inteiro (704px) e a barra inferior continua visível. Se o acerto completa um marco, a tela seguinte é `MilestoneResult`.
- As cores da pílula (#4CAF50 e #FF8A80 no Figma) reprovam contraste com texto branco; aqui usam os tokens `feedback-text-positive` e `destructive`.

**Acessibilidade:** `section` nomeada pelo título; o resultado vem em texto ("Você acertou!"), não só pela cor ou pela ilustração, que é decorativa.

**Figma:** Quiz, Telas 2A (443:15518) e 2B (443:15852).

**React:** `<Soma.AnswerResult correct answer="Dióxido de Carbono (CO₂)" explanation={texto} points={15} weeks={2} onContinue={fechar} secondary={{ label: 'Convidar amigos' }} />`

---
**Usar para:** Tela cheia com o resultado da pergunta do dia, no acerto (2A) ou no erro (2B).
**Nunca:** mostrar medalha: o nível é troféu (`Trophy`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
