Tela cheia com o resultado da pergunta do dia, no acerto ou no erro. Substitui o modal de "resposta correta" da versão antiga.

**Você fornece:** se acertou (`correct`), a resposta certa (`answer`) e a explicação (`explanation`). No acerto: `points` e `weeks`. Opcional: `message`, `art` (a ilustração do mascote), `onContinue` e `secondary` (`{ label, onClick | href }`).

- Cabeçalho com a pílula "VOCÊ ACERTOU!" (verde) ou "NÃO FOI DESSA VEZ" (neutra) e um círculo de 160px com a ilustração do mascote da lata. Sem `art`, mostra um check ou um ícone neutro.
- Depois: "A resposta certa é", a resposta, "Por quê?" com a explicação e, no acerto, "Pontos ganhos" com a frase "Volte amanhã…", as semanas seguidas e os pontos.
- Errou: explica e incentiva, sem culpa e sem mostrar pontos. A proteção da semana pode cobrir o dia.
- "Continuar" é `loud`, largura total. `secondary` aparece abaixo, em `quiet`, por exemplo "Ver histórico".
- Se o acerto completa um marco, a tela seguinte é `MilestoneResult`.

**Acessibilidade:** `section` nomeada pelo título; o resultado vem em texto ("Você acertou!"), não só pela cor ou pelo ícone.

**Figma:** Quiz, Telas 2A (acerto) e 2B (erro) (443:15190).

**React:** `<Soma.AnswerResult correct answer="Dióxido de Carbono (CO₂)" explanation={texto} points={15} weeks={2} art={lata} onContinue={fechar} />`
