Cabeçalho de tela com voltar, título e no máximo uma ação. Quatro arranjos, todos vistos no Figma.

**Você fornece:** o título em sentence case, o `onBack` quando a tela tem tela anterior e, se houver, uma ação (ajuda, compartilhar).

- `variant="center"` (padrão): seta `chevron-left` solta, título centralizado em `header-title`. Doar pontos, Cadastro, Ativação, telas anteriores.
- `variant="round"`: voltar `arrow-left` em círculo `surface-accent`, título curto centralizado em `label` e `text-secondary`. Quiz.
- `variant="start"`: título de tela raiz à esquerda em `screen-title`, botões em círculo. Ranking.
- `variant="eyebrow"`: seta `chevron-left` solta e título pequeno em maiúsculas (`eyebrow`, `text-secondary`), centralizado. QR do dia da entrega ("VILA VERDE").
- No `center` o título quebra em até três linhas ("Em qual espaço de recebimento você vai entregar?", Telas 27 e 30); nos outros arranjos ele é cortado com reticências.
- `variant="eyebrow"`: seta `chevron-left` solta e título pequeno em maiúsculas (`eyebrow`, `text-secondary`), centralizado. QR do dia da entrega ("VILA VERDE").
- No `center` o título quebra em até duas linhas ("Em qual espaço de recebimento você vai entregar?", Telas 27 e 30); nos outros arranjos ele é cortado com reticências.
- `divider` (padrão `true`): linha `border-primary` embaixo, como nas telas novas. Use `divider={false}` nas telas anteriores.
- Padding lateral `space-xsmall` (20px). Voltar e ação são `IconButton` de `size-touch` (44px) em `icon-brand-strong`, mesmo onde o Figma desenha círculos de 32 ou 36px: a área tocável não encolhe.
- Uma só saída por cabeçalho. O voltar leva à tela anterior de verdade (Ranking volta para Meu impacto).

**Acessibilidade:** o título é o `h1` da tela; os botões têm rótulo ("Voltar", "Ajuda").

**Figma:** Navbar (476:7339), Header de Doar (478:12929), cabeçalho do Quiz (477:20539) e do Ranking (478:10126).

**React:** `<Soma.Header title="Doar pontos" onBack={voltar} action={{ icon: 'help', label: 'Ajuda' }} />` · `<Soma.Header variant="start" title="Ranking" onBack={voltar} />`
