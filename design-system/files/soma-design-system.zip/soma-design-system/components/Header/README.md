# Header

Cabeçalho de tela com voltar, título e no máximo uma ação. Um só cabeçalho, com título centralizado.

## O que você fornece

O título em sentence case, o `onBack` quando a tela tem tela anterior e, se houver, uma ação (ajuda, compartilhar).

## Especificação

- `variant="center"` (padrão): seta `chevron-left` solta, escura (`text-primary`), título centralizado em `header-title`; a ação (ajuda) é que leva `icon-brand-strong`. Doar pontos, Cadastro, Ativação, telas anteriores.
- `variant="round"`: voltar `arrow-left` em círculo `surface-accent`, título curto centralizado em `label` e `text-secondary`. Quiz.
- Telas raiz de aba (Meu impacto, Reciclar, Recompensas, Ranking) usam este mesmo cabeçalho, sem voltar. `variant="start"` é obsoleto e renderiza como `center`.
- `variant="eyebrow"`: seta `chevron-left` escura e título pequeno em maiúsculas (`eyebrow`, `text-secondary`), centralizado. QR do dia da entrega ("VILA VERDE").
- No `center` o título quebra em até três linhas ("Em qual espaço de recebimento você vai entregar?", Telas 27 e 30); nos outros arranjos ele é cortado com reticências.
- `variant="eyebrow"`: seta `chevron-left` solta e título pequeno em maiúsculas (`eyebrow`, `text-secondary`), centralizado. QR do dia da entrega ("VILA VERDE").
- `divider` (padrão `true`): linha `border-primary` embaixo, como nas telas novas. Use `divider={false}` nas telas anteriores.
- Padding lateral `space-xsmall` (20px). Voltar e ação são discos brancos de `size-back` (44px) com `shadow-card`, e o título fica centralizado.
-

Uma só saída por cabeçalho. O voltar leva à tela anterior de verdade.
-

Altura mínima `size-header` (56px), token próprio: o campo de formulário tem 68px (`size-input`).

## Acessibilidade

O título é o `h1` da tela; os botões têm rótulo ("Voltar", "Ajuda").

## Nas telas da v2

Barra superior de Doar pontos ([Escolher instituição](prototipo/#832-6524)), do Quiz ([Pergunta do dia](prototipo/#849-8934)) e do Ranking ([Ranking · Amigos](prototipo/#859-9252)).

## Código

```
<Soma.Header title="Doar pontos" onBack={voltar} action={{ icon: 'help', label: 'Ajuda' }} />
```

```
<Soma.Header title="Meu impacto" action={{ icon: 'share', label: 'Compartilhar' }} />
```

---
**Usar para:** Cabeçalho de tela com voltar, título e no máximo uma ação.
**Nunca:** pôr mais de uma ação à direita, título com mais de uma linha, nem botão "Voltar" no corpo da tela, nem título à esquerda: telas raiz de aba usam o mesmo cabeçalho centralizado, sem voltar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
