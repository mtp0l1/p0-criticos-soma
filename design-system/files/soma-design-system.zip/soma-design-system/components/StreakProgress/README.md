Barra da sequência de dias com marcos de recompensa.

**Você fornece:** os dias seguidos (`days`) e os marcos (`milestones`, ex.: `[3, 7, 14]`; o maior é o fim da barra).

- Trilho de 8px em `surface-track`, preenchimento `selected-indicator`, marcos como pontos com contorno `surface-primary`. Números dos marcos embaixo em `caption`.
- Acima: chama em `icon-brand-strong` + "5 dias seguidos" e, à direita, "Próximo marco: 7 dias".

**Acessibilidade:** Radix Progress com nome "Progresso da sequência"; o texto ao lado diz o número.

**Figma:** progresso da sequência no Quiz (477:20539).

**React:** `<Soma.StreakProgress days={5} milestones={[3, 7, 14]} />`
