Barra da sequência em semanas, com os marcos que dão pontos extras.

**Você fornece:** as semanas seguidas (`weeks`) e, se houver, o próximo prêmio (`nextReward`: `{ points, inWeeks }`). Os marcos (`milestones`) já vêm em `[1, 5, 10, 20]`.

- Trilho de 8px em `surface-track` e preenchimento `selected-indicator`. Marcos proporcionais à barra: bolinha de 6px; o marco alcançado vira bolinha laranja de 10px com check e borda branca. Embaixo: "1 sem", "5 sem", "10 sem", "20 sem" em 10px 600.
- Acima: "Sequência: 2 semanas". Abaixo: "Próximo prêmio: 500 pontos em 3 semanas". Os prêmios dos marcos são 100, 500, 1.000 e 2.000 pontos.
- A sequência conta em **semanas**, não em dias. `hideLabel` esconde o título.
- Para o bloco completo da tela, use `StreakSection`.

**Acessibilidade:** `role="progressbar"` com nome "Progresso da sequência" e `aria-valuetext` ("2 semanas seguidas").

**Figma:** Quiz, Tela 1 "progresso-blocos" (443:15355).

**React:** `<Soma.StreakProgress weeks={2} nextReward={{ points: 500, inWeeks: 3 }} />`
