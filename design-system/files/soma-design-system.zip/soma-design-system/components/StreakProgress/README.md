Barra da sequência em semanas, com os marcos que dão pontos extras.

**Você fornece:** as semanas seguidas (`weeks`) e, se houver, o próximo prêmio (`nextReward`: `{ points, inWeeks }`). Os marcos (`milestones`) já vêm em `[1, 5, 10, 20]`.

- Trilho de 8px em `surface-track` e preenchimento `selected-indicator`. Marcos como pontos com os números "1 sem", "5 sem", "10 sem", "20 sem" embaixo; o marco alcançado fica laranja com check.
- Acima: "Sequência: 2 semanas". Abaixo: "Próximo prêmio: 500 pontos em 3 semanas". Os prêmios dos marcos são 100, 500, 1.000 e 2.000 pontos.
- A sequência conta em **semanas**, não em dias. Com `hideLabel`, esconde os textos (uso dentro do `MilestoneResult`).

**Acessibilidade:** Radix Progress com nome "Progresso da sequência"; o texto ao lado diz o número.

**Figma:** Quiz, Telas 1, 6 e 7 (443:15190).

**React:** `<Soma.StreakProgress weeks={2} nextReward={{ points: 500, inWeeks: 3 }} />`
