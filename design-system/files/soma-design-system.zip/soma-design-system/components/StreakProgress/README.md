# StreakProgress

Barra da sequência em semanas, com os marcos que dão pontos extras.

## O que você fornece

As semanas seguidas (`weeks`) e, se houver, o próximo prêmio (`nextReward`: `{ points, inWeeks }`). Os marcos (`milestones`) já vêm em `[1, 5, 10, 20]`.

## Especificação

- "Sequência: N semanas" com a chama, barra até o próximo marco e, embaixo, "Agora: N semanas" e o marco.
- Com `nextReward`: "Faltam N semanas para ganhar X pontos."

## Acessibilidade

`role="progressbar"` com nome "Progresso da sequência" e `aria-valuetext` ("2 semanas seguidas").

## Nas telas da v2

Quiz: [Pergunta do dia](prototipo/#849-8934), no "progresso-blocos".

## Código

```
<Soma.StreakProgress weeks={2} nextReward={{ points: 500, inWeeks: 3 }} />
```

---
**Usar para:** Barra da sequência em semanas, com os marcos que dão pontos extras.
**Nunca:** mostrar marco sem os pontos extras que ele dá.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
