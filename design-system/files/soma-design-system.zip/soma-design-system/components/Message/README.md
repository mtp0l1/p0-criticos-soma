Mensagem em linha que fica na tela, em quatro tons: informativa, positiva, de atenção e de erro.

**Você fornece:** o tom, o texto, um título opcional e uma ação opcional.

- Adição intencional, inspirada no Message do Andes (hierarquia quiet): o app só tinha o toast vermelho para tudo, e a regra do toast proíbe reusá-lo fora de erro.
- Fundo e ícone pelo tom: `feedback-fill-informative`/`-positive`/`-caution`/`-negative` com o texto do mesmo papel; corpo em `text-primary` ou na cor do tom.
- Raio `radius-medium`, padding `space-micro` por `space-mini`. Ação como `Button` `transparent`.
- Use para saldo zero ("Você ainda não tem pontos para doar"), regra explicada ("Como é calculado o ranking") e validação de formulário.

**Acessibilidade:** erro usa `role="alert"`; os outros, `role="status"`. O tom vem com ícone, nunca só cor.

**Base técnica:** shadcn `Alert` (`Alert`, `AlertTitle`, `AlertDescription`, `alertVariants`) com `tone`.

**React:** `<Soma.Message tone="caution" action={{ label: 'Ver locais de entrega' }}>Você ainda não tem pontos para doar.</Soma.Message>`

---
**Usar para:** Mensagem em linha que fica na tela, em quatro tons: informativa, positiva, de atenção e de erro.
**Nunca:** usar para aviso passageiro (use `Toast`) nem sem ícone ou texto.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
