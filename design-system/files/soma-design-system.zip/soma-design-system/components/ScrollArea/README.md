Área com rolagem própria e barra visível (shadcn ScrollArea, sobre Radix).

**Você fornece:** a altura (ou largura) e o conteúdo; um `aria-label` se a área for uma região importante.

- Barra fina com polegar em `border-strong`; aparece igual em todos os aparelhos.
- Use para texto longo dentro de um bloco (regulamento em modal) ou lista dentro de card. A tela em si rola normalmente, sem ScrollArea.

**Acessibilidade:** a área recebe foco pelo teclado (anel do sistema) e rola com as setas.

**React:** `<Soma.ScrollArea className="h-[200px] rounded-md border border-border" aria-label="Regulamento">…</Soma.ScrollArea>`

---
**Usar para:** Área com rolagem própria e barra visível (shadcn ScrollArea, sobre Radix).
**Nunca:** criar rolagem aninhada dentro da rolagem da tela.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
