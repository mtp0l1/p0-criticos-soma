Chip em pílula com o estado de um resgate: Concluído, Aguardando retirada ou Expirado.

**Você fornece:** o status; o texto padrão já vem do componente.

- `done`: `feedback-fill-positive` com `feedback-text-positive` e check. `pending`: `feedback-fill-caution` com `feedback-text-caution` e relógio. `expired`: `feedback-fill-negative` com `feedback-text-negative` e ×.
- Sempre ícone e palavra. Check só para sucesso real; espera usa relógio.
- Texto de 12px peso 500, altura mínima 24px, `radius-full`. O chip não é tocável.

**Base técnica:** `Badge` com `tone` positive, caution ou negative.

**React:** `<Soma.StatusChip status="pending" />`
