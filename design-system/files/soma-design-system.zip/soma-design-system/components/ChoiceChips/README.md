Chips de escolha única: valores de doação, categorias de recompensa e materiais.

**Você fornece:** as opções (com ícone, se fizer sentido), o valor escolhido e o rótulo do grupo.

- `variant="outline"` (padrão): pílula `radius-full` de `size-touch`, borda `interactive-border-quiet`. Escolhido: `interactive-fill-loud` com `text-on-loud`. Para valores e categorias do catálogo.
- `variant="soft"`: `surface-secondary` sem borda, `body-small`, ícone em `icon-brand-strong`; escolhido ganha `surface-accent` e borda `border-highlight`. Para os materiais da aba Reciclar.
- `scroll`: uma linha rolável que sangra até a borda da tela, em vez de quebrar.
- Desabilitado: `interactive-fill-disabled` com `interactive-text-disabled`. Desabilite valores acima do saldo e mostre o saldo acima.
- O escolhido nunca vira texto branco sobre laranja (2,05:1).

**Acessibilidade:** `role="radiogroup"`; um ponto de tabulação, setas movem a escolha.

**Figma:** chips de categoria em Recompensas (477:22160), "Material chip" na aba Reciclar (478:14984).

**React:** `<Soma.ChoiceChips label="Categoria" scroll value={v} onChange={setV} options={[{ value: 'comida', label: 'Alimentação', icon: 'utensils' }]} />`
