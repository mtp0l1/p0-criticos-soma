# ChoiceChips

Chips de escolha única: valores de doação, categorias de recompensa e materiais.

## O que você fornece

As opções (com ícone, se fizer sentido), o valor escolhido e o rótulo do grupo.

## Especificação

- `variant="outline"` (padrão): pílula `radius-full` de `size-touch`, borda `interactive-border-quiet`. Escolhido: `interactive-fill-loud` com `text-on-loud`. Para valores e categorias do catálogo.
- `variant="soft"`: `surface-secondary` sem borda, `body-small`, ícone em `icon-brand-strong`; escolhido ganha `surface-accent` e borda `border-highlight`. Para os materiais da aba Reciclar.
- `scroll`: uma linha rolável que sangra até a borda da tela, em vez de quebrar.
- Desabilitado: `interactive-fill-disabled` com `interactive-text-disabled`. Desabilite valores acima do saldo e mostre o saldo acima.
- O escolhido nunca vira texto branco sobre laranja (2,05:1).

## Acessibilidade

`role="radiogroup"`; um ponto de tabulação, setas movem a escolha.

## Nas telas da v2

Chips de categoria em Recompensas ([Catálogo com meta](prototipo/#854-9534)) e chips de material na aba Reciclar ([Aba Reciclar (nova)](prototipo/#829-7018)).

## Código

```
<Soma.ChoiceChips label="Categoria" scroll value={v} onChange={setV} options={[{ value: 'comida', label: 'Alimentação', icon: 'utensils' }]} />
```

---
**Usar para:** Chips de escolha única: valores de doação, categorias de recompensa e materiais.
**Nunca:** usar para navegação entre telas nem para marcar vários itens quando a escolha é única.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
