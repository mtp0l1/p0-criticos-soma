Abas com sublinhado para trocar o recorte de uma mesma tela, como o período do ranking.

**Você fornece:** os itens (`id`, `label`), o valor atual e o rótulo do grupo.

- Duas a três abas de mesma largura. Ativa em `label` e `text-primary` com sublinhado de 3px em `selected-indicator`; inativa em `text-secondary`.
- O texto e o sublinhado ficam centralizados na aba. O app hoje desalinha os dois: corrija.
- Use para filtrar o mesmo conteúdo ("Este mês", "Últimos 12 meses"). Para trocar de seção dentro de um fluxo, use `SegmentedControl`.
- Aba pressionada em `interactive-fill-quiet-active`; aba desabilitada em `interactive-text-disabled`, sem hover.

**Acessibilidade:** `role="tablist"` com `aria-selected`; o grupo tem `label` ("Período do ranking").

**Base técnica:** Radix Tabs (`TabsRoot`, `TabsList variant="underline"`, `TabsTrigger`, `TabsContent`). Setas trocam de aba e Enter ativa (`activationMode="manual"`). Passe o conteúdo como `children` para cada aba apontar para um painel real.

**React:** `<Soma.Tabs label="Período do ranking" value={p} onChange={setP} items={[{id:'mes',label:'Este mês'},{id:'ano',label:'Últimos 12 meses'}]} />`
