Nota "Sua meta" na tela Entrega registrada: caixa tracejada que liga o que a pessoa acabou de ganhar com a recompensa que quer.

**Você fornece:** o texto (`children`). Opcional: `title` (padrão "Sua meta").

- Borda tracejada de 1px `border-highlight`, fundo `surface-accent` (no Figma é salmão, #FFF0EA), raio `radius-large`, padding 16px. Rótulo em `eyebrow` maiúsculo `text-link`; texto em `body-small` medium.
- Aparece só para quem tem meta. Sem meta, a tela segue direto para o lembrete.

**Acessibilidade:** `aside` com o título como nome.

**Figma:** Tela 12, Goal-Banner (443:13637).

**React:** `<Soma.GoalNote>Você já tem 144 de 800 pontos. Faltam cerca de 33 kg para os Fones de ouvido Bluetooth.</Soma.GoalNote>`