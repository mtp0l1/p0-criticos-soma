# GoalNote

Nota "Sua meta" na tela Entrega registrada: caixa tracejada que liga o que a pessoa acabou de ganhar com a recompensa que quer.

## O que você fornece

O texto (`children`). Opcional: `title` (padrão "Sua meta").

## Especificação

- Borda tracejada de 1px `border-highlight`, fundo `surface-accent` (na versão anterior é salmão, #FFF0EA), raio `radius-large`, padding 16px. Rótulo em `eyebrow` maiúsculo `text-link`; texto em `body-small` medium.
- Aparece só para quem tem meta. Sem meta, a tela segue direto para o lembrete.

## Acessibilidade

`aside` com o título como nome.

## Nas telas da v2

Ativação: [Entrega registrada](prototipo/#842-10230), no aviso da meta.

## Código

```
<Soma.GoalNote>Você já tem 144 de 800 pontos. Faltam cerca de 33 kg para os Fones de ouvido Bluetooth.</Soma.GoalNote>
```

---
**Usar para:** Nota "Sua meta" na tela Entrega registrada: caixa tracejada que liga o que a pessoa acabou de ganhar com a recompensa que quer.
**Nunca:** usar fora da tela Entrega registrada.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
