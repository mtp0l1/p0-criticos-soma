# Tile

Tile de atalho do Início: disco com o ícone em cima, rótulo embaixo, em grade de duas colunas (`TileGrid`), em quatro tons.

## O que você fornece

O ícone, um rótulo de até duas linhas, o destino e, opcionalmente, o tom (`tone`). Agrupe os tiles sob um SectionHeader.

## Especificação

- Cartão de 128px de altura, raio `radius-2xl` (28px), padding `space-mini` e o conteúdo nas pontas: o disco de 44px com o ícone em cima e o rótulo `label` embaixo, em até duas linhas. Entre os dois tiles, `space-mini`.
- `tone="light"` (padrão): fundo `surface-primary` com `shadow-card`; disco `surface-tint-peach`. `primary`: fundo `primary` (laranja da marca) para a ação que gera pontos ("Buscar material"). `dark`: fundo `surface-inverse`, texto `text-inverse` e disco translúcido ("Recompensas"). `peach`: fundo `surface-tint-peach` e disco branco ("Doar pontos").
- Agrupe por intenção ("Reciclar e ganhar pontos", "Resultado das minhas ações", "Usar pontos") e deixe a ação que gera pontos acima da dobra. Um tile laranja por grupo, no máximo.
- O tile todo é tocável.

## Estados

Hover e toque escurecem um passo o fundo do tom (o laranja segue os estados do botão), foco com o anel `ring`. O tom `dark` não muda no hover. Com `href`, vira link.

## Acessibilidade

Cada tile é um botão com o rótulo como nome.

## Nas telas da v2

Início: [Início · depois](prototipo/#829-6915). O token `size-tile` passou de 88px para 80px.

## Código

```
<Soma.TileGrid><Soma.Tile icon="search" label="Buscar material" /></Soma.TileGrid>
```

---
**Usar para:** Tile de atalho do Início: disco com o ícone em cima, rótulo embaixo, em grade de duas colunas (`TileGrid`).
**Nunca:** usar para dado (use `StatTile`) nem sem rótulo de texto.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
