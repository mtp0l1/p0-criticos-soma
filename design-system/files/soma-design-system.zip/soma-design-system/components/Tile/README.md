Tile de atalho da Home: ícone em cima, rótulo embaixo, em grade de duas colunas (`TileGrid`).

**Você fornece:** o ícone, um rótulo de até duas linhas e o destino. Agrupe os tiles sob um `SectionHeader`.

- Fundo `surface-secondary`, raio `radius-large`, **80px de altura** (`size-tile`), padding 16 × 8, gap de 4px entre ícone e rótulo, e o conteúdo **centralizado na vertical**: rótulo de uma linha fica no meio do tile, de duas linhas ocupa a altura toda. Ícone `icon-brand`, rótulo `label` em `text-primary`. Entre os dois tiles, `space-mini` (16px).
- Agrupe por intenção ("Reciclar e ganhar pontos", "Resultado das minhas ações", "Usar pontos") e deixe a ação que gera pontos acima da dobra.
- Sem sombra. O tile todo é tocável.

**Acessibilidade:** cada tile é um botão com o rótulo como nome.

**Estados:** hover e toque em `surface-secondary-hover`, foco com anel `ring`. Com `href`, vira link.

**Figma:** Início, Home DEPOIS (443:12071). O token `size-tile` passou de 88px para 80px.

**React:** `<Soma.TileGrid><Soma.Tile icon="search" label="Buscar material" /></Soma.TileGrid>`
