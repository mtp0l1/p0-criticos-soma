Tile de atalho da Home: ícone em cima, rótulo embaixo, em grade de duas colunas (`TileGrid`).

**Você fornece:** o ícone, um rótulo de até duas linhas e o destino. Agrupe os tiles sob um `SectionHeader`.

- Fundo `surface-secondary`, raio `radius-large`, padding `space-mini`, gap `space-mini`, altura mínima `size-tile`. Ícone `icon-brand`, rótulo `label` em `text-primary`.
- Agrupe por intenção ("Resultado das minhas ações", "Reciclar e ganhar pontos", "Usar pontos") e deixe a ação que gera pontos acima da dobra.
- Sem sombra. O tile todo é tocável.

**Acessibilidade:** cada tile é um botão com o rótulo como nome.

**Estados:** hover e toque em `surface-secondary-hover`, foco com anel `ring`. Com `href`, vira link.

**React:** `<Soma.TileGrid><Soma.Tile icon="search" label="Buscar material" /></Soma.TileGrid>`
