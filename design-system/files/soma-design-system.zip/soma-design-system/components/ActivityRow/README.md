Linha de atividade recente no Início: o que aconteceu e quando, com uma ação opcional.

**Você fornece:** o título (`title`), o detalhe (`detail`) e, se houver, o ícone (`icon`) e a ação (`action`: `{ label, onClick | href }`, como "Ver recibo").

- Quadro redondo `surface-secondary` com o ícone, título em `label`, detalhe em `caption` e a ação como botão `transparent` à direita.
- Use na lista "Atividade recente", no máximo três linhas, e um link "Ver tudo".

**Acessibilidade:** o rótulo da ação precisa dizer de qual atividade é, quando houver mais de uma linha igual.

**Figma:** Início, Tela 17 (438:1973).

**React:** `<Soma.ActivityRow title="Entrega registrada" detail="3,2 kg de PET · +64 pontos" action={{ label: 'Ver recibo', href: '/entregas/42' }} />`
