Linha de atividade recente no Início: o que aconteceu e quando, com uma ação opcional.

**Você fornece:** o título (`title`), o detalhe (`detail`) e, se houver, o ícone (`icon`) e a ação (`action`: `{ label, onClick | href }`, como "Ver recibo").

- Círculo de 32px em verde claro com o ícone de 16px, título em `label`, detalhe em `caption` semibold e a ação como link em `text-link` bold à direita (área de toque de 44px).
- Use na lista "Atividade recente", sob `SectionHeader size="eyebrow"`. O Figma não tem "Ver tudo" nessa lista.

**Acessibilidade:** o rótulo da ação precisa dizer de qual atividade é, quando houver mais de uma linha igual.

**Figma:** Início, Tela 17 (438:1973 e 443:14233).

**React:** `<Soma.ActivityRow title="Entrega registrada" detail="3,2 kg de PET · +64 pontos" action={{ label: 'Ver recibo', href: '/entregas/42' }} />`
