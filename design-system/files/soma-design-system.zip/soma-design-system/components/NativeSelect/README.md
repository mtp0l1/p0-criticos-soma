Lista suspensa que abre o seletor do próprio aparelho (shadcn NativeSelect).

**Você fornece:** as `<option>` e um rótulo.

- Mesmo desenho do `Input`, com seta em `icon-brand-strong`. Hover, foco, erro (`aria-invalid`) e desabilitado iguais aos do campo.
- No celular é a melhor escolha para listas simples (estado, mês): o seletor nativo é conhecido e acessível. `Select` fica para quando a lista precisa do visual do app; `Combobox` para listas longas com busca.
- Primeira opção desabilitada serve de placeholder ("Selecione").

**Acessibilidade:** `select` nativo: funciona com teclado, leitor de tela e zoom sem código extra.

**React:** `<Soma.NativeSelect id="uf" defaultValue=""><option value="" disabled>Selecione</option><option value="PR">Paraná</option></Soma.NativeSelect>`

---
**Usar para:** Lista suspensa que abre o seletor do próprio aparelho (shadcn NativeSelect).
**Nunca:** usar quando o menu precisa de ícone ou estilo próprio (use `Select`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
