Seu código de convite, com botão de copiar.

**Você fornece:** o código (`code`) e `onCopy`.

- Card com borda `border-primary`, "Seu código" em `caption` e o código em `label` com espaçamento largo. "Copiar" (`quiet`, `compact`) vira "Copiado" por 2 segundos.
- O texto é "Convidar amigos" (não "Convidar pessoas"). Mostre-o junto de `ContactRow` para convidar por contato.

**Acessibilidade:** o anúncio de cópia vai por `aria-live="polite"`.

**Figma:** Convidar amigos (438:1973).

**React:** `<Soma.InviteCodeCard code="REC7X4KP" onCopy={copiar} />`

---
**Usar para:** Seu código de convite, com botão de copiar.
**Nunca:** esconder o botão de copiar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
