# InviteCodeCard

Seu código de convite, com botão de copiar.

## O que você fornece

O código (`code`) e `onCopy`.

## Especificação

- Cartão azul-marinho com "Seu código", o botão "Copiar" e o código em 28px.

## Acessibilidade

O anúncio de cópia vai por `aria-live="polite"`.

## Nas telas da v2

Convidar amigos: [Convidar amigos](prototipo/#859-9669) e [Compartilhar convite](prototipo/#890-10512).

## Código

```
<Soma.InviteCodeCard code="REC7X4KP" onCopy={copiar} />
```

---
**Usar para:** Seu código de convite, com botão de copiar.
**Nunca:** esconder o botão de copiar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
