# PositionCard

Card "Sua posição" no ranking, com o percentual de participantes que a pessoa superou.

## O que você fornece

O percentual (`percent`, de 0 a 100) ou `null` quando ainda não há entrega no período.

## Especificação

- Cartão azul-marinho com "Seu desempenho", o percentual em 48px e a frase. Sem percentual, mostra o convite para a primeira entrega.

## Nas telas da v2

Ranking, aba Geral ([Ranking · Geral](prototipo/#859-9557)).

## Código

```
<Soma.PositionCard percent={80} />
```

```
<Soma.PositionCard percent={null} />
```

---
**Usar para:** Card "Sua posição" no ranking, com o percentual de participantes que a pessoa superou.
**Nunca:** comparar a pessoa a um indivíduo; só ao percentual de participantes.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
