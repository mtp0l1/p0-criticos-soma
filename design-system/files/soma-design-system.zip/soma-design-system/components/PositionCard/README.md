Card "Sua posição" no ranking, com a posição e a comparação com quem entrega no mesmo espaço.

**Você fornece:** a posição (ou `null` quando ainda não há entrega no período) e o percentual.

- Card `surface-primary` sem borda sobre `background-secondary`. "Sua posição" em `eyebrow`, posição em `page-title`, frase em `caption` e `text-secondary`.
- Texto da comparação: "Você reciclou mais que {X}% dos participantes que entregam no mesmo espaço de recebimento."
- Sem posição: "Sem posição ainda" e "Faça sua primeira entrega para entrar no ranking do seu espaço de recebimento." Nunca "Sua posição: Nenhuma".
- O ranking é individual (por CPF): fale em "participante", nunca em "casa".

**Base técnica:** `Card variant="flat"`.

**React:** `<Soma.PositionCard position={34} percent={62} />`
