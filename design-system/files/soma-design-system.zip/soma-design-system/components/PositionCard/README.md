Card "Sua posição" no ranking, com o percentual de participantes que a pessoa superou.

**Você fornece:** o percentual (`percent`, de 0 a 100) ou `null` quando ainda não há entrega no período.

- Card `surface-primary` com borda, ícone de tendência em círculo `surface-accent` e a frase em `label`: "Você reciclou mais que 80% dos participantes do seu espaço de recebimento."
- Sem entrega: "Faça sua primeira entrega para entrar no ranking do seu espaço de recebimento." Nunca "Sua posição: Nenhuma".
- O ranking é individual (por CPF): fale em "participantes", nunca em "casas".
- A prop `position` saiu: o redesign mostra só o percentual.

**Figma:** Ranking, aba Geral (438:1973).

**React:** `<Soma.PositionCard percent={80} />` · `<Soma.PositionCard percent={null} />`
