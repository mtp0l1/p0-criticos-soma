# Command

Lista com campo de busca e navegação por teclado (shadcn Command, sobre cmdk). É a base do `Combobox`.

## O que você fornece

`CommandInput`, `CommandList` e os itens, em grupos se fizer sentido; `CommandEmpty` para quando nada bate.

## Especificação

- Busca com lupa em `icon-brand-strong` e divisor embaixo. Itens de 44px em `body-small`; em destaque `accent`; desabilitado em `interactive-text-disabled`.
- Título de grupo em 12px e peso 600, `text-secondary`. `CommandSeparator` divide grupos.
- A lista rola a partir de 264px de altura.

## Acessibilidade

Campo com `role="combobox"` e lista `listbox`; digitar filtra, setas movem, Enter escolhe. Dê `aria-label` ao campo e `label` ao Command.

## Código

```
<Soma.Command label="Buscar"><Soma.CommandInput placeholder="O que você procura?" aria-label="O que você procura?" /><Soma.CommandList><Soma.CommandEmpty>Nada encontrado</Soma.CommandEmpty><Soma.CommandGroup heading="Atalhos"><Soma.CommandItem onSelect={ir}>Agendar entrega</Soma.CommandItem></Soma.CommandGroup></Soma.CommandList></Soma.Command>
```

---
**Usar para:** Lista com campo de busca e navegação por teclado (shadcn Command, sobre cmdk).
**Nunca:** usar sozinho como tela; é a base do `Combobox`.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
