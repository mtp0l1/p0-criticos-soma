Lista com campo de busca e navegação por teclado (shadcn Command, sobre cmdk). É a base do `Combobox`.

**Você fornece:** `CommandInput`, `CommandList` e os itens, em grupos se fizer sentido; `CommandEmpty` para quando nada bate.

- Busca com lupa em `icon-brand-strong` e divisor embaixo. Itens de 44px em `body-small`; em destaque `accent`; desabilitado em `interactive-text-disabled`.
- Título de grupo em 12px e peso 600, `text-secondary`. `CommandSeparator` divide grupos.
- A lista rola a partir de 264px de altura.

**Acessibilidade:** campo com `role="combobox"` e lista `listbox`; digitar filtra, setas movem, Enter escolhe. Dê `aria-label` ao campo e `label` ao Command.

**React:** `<Soma.Command label="Buscar"><Soma.CommandInput placeholder="O que você procura?" aria-label="O que você procura?" /><Soma.CommandList><Soma.CommandEmpty>Nada encontrado</Soma.CommandEmpty><Soma.CommandGroup heading="Atalhos"><Soma.CommandItem onSelect={ir}>Agendar entrega</Soma.CommandItem></Soma.CommandGroup></Soma.CommandList></Soma.Command>`
