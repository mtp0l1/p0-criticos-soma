Lista de perguntas que abrem e fecham, sobre Radix Accordion (shadcn Accordion). Para a Ajuda e para regras longas.

**Você fornece:** os itens (pergunta e resposta) e se abre um (`type="single"`) ou vários (`type="multiple"`).

- Pergunta em `label`, seta em `icon-brand-strong` que gira ao abrir, divisor `border`. Resposta em `body` e `muted-foreground`, com `space-mini` embaixo.
- Altura mínima `size-touch` por pergunta. Hover leva a pergunta para `text-link`.
- Use quando a pessoa procura uma resposta entre várias. Para navegar a uma tela, use `ListRow`.
- Animação de altura curta, desligada com movimento reduzido.

**Acessibilidade:** setas, Home e End entre perguntas; `aria-expanded` e `aria-controls` vêm do Radix.

**React:** `<Soma.Accordion type="single" collapsible><Soma.AccordionItem value="a"><Soma.AccordionTrigger>Pergunta</Soma.AccordionTrigger><Soma.AccordionContent>Resposta</Soma.AccordionContent></Soma.AccordionItem></Soma.Accordion>`
