Lista de perguntas que abrem e fecham, sobre Radix Accordion (shadcn Accordion). Para a Ajuda e para regras longas.

**Você fornece:** os itens (pergunta e resposta) e se abre um (`type="single"`) ou vários (`type="multiple"`).

- Pergunta em `label`, seta em `icon-brand-strong` que gira ao abrir, divisor `border`. Resposta em `body` e `muted-foreground`, com `space-mini` embaixo.
- Altura mínima `size-touch` por pergunta. Hover leva a pergunta para `text-link`.
- Use quando a pessoa procura uma resposta entre várias. Para navegar a uma tela, use `ListRow`.
- Animação de altura curta, desligada com movimento reduzido.
- Pressionado em `interactive-fill-quiet-active`; item desabilitado (`disabled`) fica em `interactive-text-disabled` e não abre.

**Acessibilidade:** setas, Home e End entre perguntas; `aria-expanded` e `aria-controls` vêm do Radix.

**React:** `<Soma.Accordion type="single" collapsible><Soma.AccordionItem value="a"><Soma.AccordionTrigger>Pergunta</Soma.AccordionTrigger><Soma.AccordionContent>Resposta</Soma.AccordionContent></Soma.AccordionItem></Soma.Accordion>`

---
**Usar para:** Lista de perguntas que abrem e fecham, sobre Radix Accordion (shadcn Accordion).
**Nunca:** abrir tudo por padrão nem esconder regra que a pessoa precisa aceitar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
