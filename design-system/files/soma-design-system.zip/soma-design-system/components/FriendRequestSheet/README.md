Pedido de amizade recebido: bottom sheet com "Agora não" e "Aceitar".

**Você fornece:** o nome de quem convidou (`name`) e as ações `onAccept` e `onDecline`. Controle com `open` e `onOpenChange`, ou deixe abrir sozinho (`defaultOpen`) ao entrar no Ranking.

- Bottom sheet (`Sheet`, `side="bottom"`) sobre película: alça no topo, ícone `user-plus` em círculo de 56px `surface-accent`, título "Policarpo quer adicionar você como amigo no ranking." em 16px bold, alinhado à esquerda.
- Dois botões lado a lado, de larguras iguais: "Agora não" (`quiet`) e "Aceitar" (`loud`). Os dois fecham a folha.
- Substitui o `FriendRequestBanner` das versões 6 e anterior: no Figma não é faixa no topo, é folha.
- Pendente no handoff: o que acontece em "Agora não" e se o pedido expira.

**Acessibilidade:** é um diálogo (Radix): foco preso, Esc fecha, foco volta ao gatilho. O título dá o nome.

**Figma:** Ranking, Tela 13 "Pedido recebido" (443:18895).

**React:** `<Soma.FriendRequestSheet name="Policarpo" defaultOpen onAccept={aceitar} onDecline={recusar} />`
