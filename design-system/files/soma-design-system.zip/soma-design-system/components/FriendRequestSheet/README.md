# FriendRequestSheet

Pedido de amizade recebido: bottom sheet com "Agora não" e "Aceitar".

## O que você fornece

O nome de quem convidou (`name`) e as ações `onAccept` e `onDecline`. Controle com `open` e `onOpenChange`, ou deixe abrir sozinho (`defaultOpen`) ao entrar no Ranking.

## Especificação

- Bottom sheet (`Sheet`, `side="bottom"`) sobre película: alça no topo, ícone `user-plus` em círculo de 56px `surface-accent`, título "Policarpo quer adicionar você como amigo no ranking." em 16px bold, alinhado à esquerda.
- Dois botões lado a lado, de larguras iguais: "Agora não" (`quiet`) e "Aceitar" (`loud`). Os dois fecham a folha.
- Substitui o `FriendRequestBanner` das versões 6 e anterior: no handoff anterior não é faixa no topo, é folha.
- Pendente no handoff: o que acontece em "Agora não" e se o pedido expira.

## Acessibilidade

É um diálogo (Radix): foco preso, Esc fecha, foco volta ao gatilho. O título dá o nome.

## Nas telas da v2

Ranking: [Pedido recebido](prototipo/#859-10036).

## Código

```
<Soma.FriendRequestSheet name="Policarpo" defaultOpen onAccept={aceitar} onDecline={recusar} />
```

---
**Usar para:** Pedido de amizade recebido: bottom sheet com "Agora não" e "Aceitar".
**Nunca:** pôr outra ação além de "Agora não" e "Aceitar".
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
