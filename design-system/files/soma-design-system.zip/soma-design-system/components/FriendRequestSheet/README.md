# FriendRequestSheet

Pedido de amizade recebido: bottom sheet com "Agora não" e "Aceitar".

## O que você fornece

O nome de quem convidou (`name`) e as ações `onAccept` e `onDecline`. Controle com `open` e `onOpenChange`, ou deixe abrir sozinho (`defaultOpen`) ao entrar no Ranking.

## Especificação

- Folha com a inicial de quem pediu num círculo, a frase centralizada e "Agora não" e "Aceitar" lado a lado.

## Acessibilidade

É um diálogo: foco preso, Esc fecha, foco volta ao gatilho. O título dá o nome.

## Nas telas da v2

Ranking: [Pedido recebido](prototipo/#859-10036).

## Código

```
<Soma.FriendRequestSheet name="Policarpo" defaultOpen onAccept={aceitar} onDecline={recusar} />
```

---
**Usar para:** Pedido de amizade recebido: bottom sheet com "Agora não" e "Aceitar".
**Nunca:** pôr outra ação além de "Agora não" e "Aceitar".
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
