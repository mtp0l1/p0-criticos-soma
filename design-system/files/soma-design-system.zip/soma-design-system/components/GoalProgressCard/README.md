Progresso da recompensa escolhida como meta: pontos atuais, o custo e quantos quilos faltam.

**Você fornece:** os pontos atuais (`points`), o custo (`goal`) e, se houver, os quilos que faltam (`missingKg`).

- Card `surface-card` com borda, raio `radius-large`, padding 16px. Eyebrow "PROGRESSO DA META", barra de 8px (`Progress`), e embaixo "80 / 800 pontos" em `caption` à esquerda e "Faltam 36 kg de recicláveis" em `label` `text-link` à direita.
- O texto de quilos é só uma estimativa: nunca prometa uma data.
- Para o card laranja do catálogo use `GoalCard`; este é o da escolha no cadastro.

**Acessibilidade:** a barra é lida com o texto "Progresso da meta" e o valor em porcentagem; os números aparecem em texto.

**Figma:** Telas 25 e 26 (443:12728 e 443:12811).

**React:** `<Soma.GoalProgressCard points={80} goal={800} missingKg={36} />`

---
**Usar para:** Progresso da recompensa escolhida como meta: pontos atuais, o custo e quantos quilos faltam.
**Nunca:** esconder quantos quilos faltam.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
