# GoalProgressCard

Progresso da recompensa escolhida como meta: pontos atuais, o custo e quantos quilos faltam.

## O que você fornece

Os pontos atuais (`points`), o custo (`goal`) e, se houver, os quilos que faltam (`missingKg`).

## Especificação

- Cartão branco: "Progresso da meta", pontos em 32px sobre a meta, a barra e os quilos que faltam. `material` nomeia a estimativa ("PET").

## Acessibilidade

A barra é lida com o texto "Progresso da meta" e o valor em porcentagem; os números aparecem em texto.

## Nas telas da v2

Ativação: [Escolha a recompensa](prototipo/#842-9303) e [Escolha (progresso zero)](prototipo/#842-9387).

## Código

```
<Soma.GoalProgressCard points={80} goal={800} missingKg={36} />
```

---
**Usar para:** Progresso da recompensa escolhida como meta: pontos atuais, o custo e quantos quilos faltam.
**Nunca:** esconder quantos quilos faltam.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
