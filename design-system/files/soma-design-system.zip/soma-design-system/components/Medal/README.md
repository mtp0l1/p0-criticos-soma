Medalha do nível no quiz, em três tamanhos, com uma, duas ou três estrelas.

**Você fornece:** o nível (`tier`: `bronze`, `prata` ou `ouro`) e o tamanho (`size`: `sm` 56px, `md` 96px, `lg` 124px). Com a arte do Figma exportada, passe `src`.

- As estrelas marcam o nível: uma no Bronze, duas na Prata, três no Ouro, apoiadas no aro da medalha.
- Sem `src`, mostra uma medalha de ícone na cor do nível (`award-bronze`, `award-silver`, `award-gold`). É um substituto; a arte final do redesign entra pelo `src`.
- Só existem os três níveis do redesign. Ferro e Platina foram removidos.

**Acessibilidade:** `role="img"` com o nome "Medalha Bronze"; o nível também aparece em texto no `LevelBadge` ou no título ao lado.

**Figma:** "icone-nivel-bronze" (443:15758), "icone-nivel-ouro" (443:15965) e o card Prata (443:15954), na seção Quiz.

**React:** `<Soma.Medal tier="ouro" size="lg" src={ouro} />`
