# BalanceCard

Card com o saldo de pontos e uma legenda de apoio; leva ao extrato. Tem quatro tons: hero (o do Início), light, card (o do Início com meta) e dark.

## O que você fornece

O saldo (`points`), a legenda (`hint`) e o destino do toque. Opcional: `tone` (`hero`, `light` ou `dark`) e `action` (`{ label, onClick | href }`).

## Especificação

- `hero`: azul-marinho, raio grande, saldo em 48px na cor primária e a seta num disco claro.
- `card`: branco com sombra, "Seu saldo atual" e o link da ação ("Ver meta") no canto.
- `light`: creme, com a seta. `dark`: azul-marinho compacto com botão.

## Acessibilidade

No hero e no claro, o card inteiro é um botão (ou link com `href`) e o nome lido inclui saldo e legenda. No escuro, o toque é só do `action`; o saldo é texto.

## Nas telas da v2

[Início](prototipo/#829-6915).

## Código

```
<Soma.BalanceCard points={10} onPress={abrirExtrato} />
```

```
<Soma.BalanceCard tone="dark" points={144} action={{ label: 'Ver meta', href: '/recompensas/meta' }} />
```

---
**Usar para:** Card com o saldo de pontos e uma legenda de apoio; leva ao extrato.
**Nunca:** mostrar saldo sem a ação que leva ao extrato.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
