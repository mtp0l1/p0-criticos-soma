Card creme com o saldo de pontos e uma legenda de apoio; leva ao extrato.

**Você fornece:** o saldo (`points`), a legenda (`hint`) e o destino do toque.

- Fundo `surface-accent`, raio `radius-large`, padding `space-mini`. Número em `balance-number`, "pontos" em `body`, tudo em `text-primary`. Legenda em `caption` e `text-secondary`.
- Saldo zero sempre mostra um caminho: sem `hint`, o componente escreve "Faça sua primeira entrega e comece a pontuar". Nunca "Você não tem pontos a expirar" com saldo zero.
- Número com separador de milhar (707, 9.057).

**Estados:** com saldo · saldo zero · carregando (use `Skeleton variant="card"`).

**Acessibilidade:** o card inteiro é um botão; o nome lido inclui saldo e legenda.

**Estados:** hover e toque em `surface-accent-hover`, foco com anel `ring`. Com `href`, vira link.

**React:** `<Soma.BalanceCard points={707} hint="Veja seus pontos e quando expiram" onPress={abrirExtrato} />`
