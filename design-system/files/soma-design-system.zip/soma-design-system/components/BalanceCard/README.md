Card com o saldo de pontos e uma legenda de apoio; leva ao extrato. Tem versão clara e escura.

**Você fornece:** o saldo (`points`), a legenda (`hint`) e o destino do toque. Opcional: `tone` e `action` (`{ label, onClick | href }`).

- `tone="light"` (padrão): fundo `surface-accent`, raio `radius-large`, **altura mínima de 104px**, conteúdo no topo e seta centralizada à direita. "Saldo atual" em `caption`, o número em 32px **regular** e "pontos" em `subtitle` (16px medium), tudo em `text-primary`. A legenda, quando existe, em `text-secondary`. Para a Home sem meta e a tela de pontos.
- `tone="dark"`: fundo `surface-inverse` com "SEU SALDO ATUAL" em `icon-brand` e número de 24px bold em `text-inverse`; leva `action` (botão `loud` compacto, como "Ver meta"). Para a Home com meta ativa (Tela 17, 443:14233).
- Saldo zero sempre mostra um caminho: sem `hint`, escreve "Faça sua primeira entrega e comece a pontuar". Nunca "Você não tem pontos a expirar" com saldo zero.
- Número com separador de milhar (707, 9.057). Com saldo 1, "ponto" no singular.

**Acessibilidade:** no claro, o card inteiro é um botão (ou link com `href`) e o nome lido inclui saldo e legenda. No escuro, o toque é só do `action`; o saldo é texto.

**Figma:** Início, Home DEPOIS (443:12071): "Saldo atual · 10 pontos", sem legenda. O Figma tem uma ilustração decorativa e um botão ocultos no card; não entram.

**React:** `<Soma.BalanceCard points={10} onPress={abrirExtrato} />` · `<Soma.BalanceCard tone="dark" points={144} action={{ label: 'Ver meta', href: '/recompensas/meta' }} />`

---
**Usar para:** Card com o saldo de pontos e uma legenda de apoio; leva ao extrato.
**Nunca:** mostrar saldo sem a ação que leva ao extrato.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
