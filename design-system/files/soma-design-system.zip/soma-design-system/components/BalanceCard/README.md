Card com o saldo de pontos e uma legenda de apoio; leva ao extrato. Tem versão clara e escura.

**Você fornece:** o saldo (`points`), a legenda (`hint`) e o destino do toque. Opcional: `tone` e `action` (`{ label, onClick | href }`).

- `tone="light"` (padrão): fundo `surface-accent`, raio `radius-large`, número em `balance-number`, tudo em `text-primary`, legenda em `text-secondary`. Para a Home sem meta e a tela de pontos.
- `tone="dark"`: fundo `surface-inverse` com "SEU SALDO ATUAL" em `icon-brand` e número em `text-inverse`; leva `action` (botão `loud`, como "Ver meta"). Para a Home com meta ativa.
- Saldo zero sempre mostra um caminho: sem `hint`, escreve "Faça sua primeira entrega e comece a pontuar". Nunca "Você não tem pontos a expirar" com saldo zero.
- Número com separador de milhar (707, 9.057).

**Acessibilidade:** no claro, o card inteiro é um botão (ou link com `href`) e o nome lido inclui saldo e legenda. No escuro, o toque é só do `action`; o saldo é texto.

**Figma:** Início, Tela 17 (saldo escuro com "Ver meta") e Início sem meta (438:1973).

**React:** `<Soma.BalanceCard points={707} hint="Veja seus pontos e quando expiram" onPress={abrirExtrato} />` · `<Soma.BalanceCard tone="dark" points={144} action={{ label: 'Ver meta', href: '/recompensas/meta' }} />`
