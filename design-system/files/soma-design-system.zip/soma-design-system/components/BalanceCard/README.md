# BalanceCard

Card com o saldo de pontos e uma legenda de apoio; leva ao extrato. Tem três tons: hero (azul-marinho, o do Início), claro e escuro.

## O que você fornece

O saldo (`points`), a legenda (`hint`) e o destino do toque. Opcional: `tone` (`hero`, `light` ou `dark`) e `action` (`{ label, onClick | href }`).

## Especificação

- `tone="hero"` (padrão): fundo `surface-inverse`, raio `radius-3xlarge` (32px), sombra `shadow-dark`, altura mínima de 150px e duas formas circulares translúcidas ao fundo. "Saldo atual" em `body-small` e, no canto superior direito, um disco branco de 32px com a seta. O número em `balance-number` (48px bold) na cor `primary` (laranja) e "pontos" em `subtitle` `text-inverse`. Para o Início com saldo.
- `tone="light"`: fundo `surface-accent`, raio `radius-large`, altura mínima de 104px, conteúdo no topo e seta centralizada à direita. "Saldo atual" em `caption`, o número em 48px regular e "pontos" em `subtitle`, tudo em `text-primary`. A legenda, quando existe, em `text-secondary`. Para telas de apoio, como o extrato.
- `tone="dark"`: fundo `surface-inverse` com "SEU SALDO ATUAL" em `icon-brand` e número de 28px bold em `text-inverse`; leva `action` (botão loud compacto, como "Ver meta"). Para o Início com meta ativa (Início pós-entrega).
- Saldo zero sempre mostra um caminho: sem hint, escreve "Faça sua primeira entrega e comece a pontuar". Nunca "Você não tem pontos a expirar" com saldo zero.
- Número com separador de milhar (707, 9.057). Com saldo 1, "ponto" no singular.

## Acessibilidade

No hero e no claro, o card inteiro é um botão (ou link com `href`) e o nome lido inclui saldo e legenda. No escuro, o toque é só do `action`; o saldo é texto.

## Nas telas da v2

Início: [Home com saldo](prototipo/#832-7334) e [Início · Responda ao Quiz](prototipo/#829-6713) (`hero`). Com meta ativa, o [Início pós-entrega](prototipo/#842-10848) (`dark`).

## Código

```
<Soma.BalanceCard points={10} onPress={abrirExtrato} />
```

```
<Soma.BalanceCard tone="dark" points={144} action={{ label: 'Ver meta', href: '/recompensas/meta' }} />
```

---
**Usar para:** Card com o saldo de pontos e uma legenda de apoio; leva ao extrato.
**Nunca:** mostrar saldo sem a ação que leva ao extrato.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
