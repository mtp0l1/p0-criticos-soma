# Table

Tabela de dados simples, como o extrato de pontos.

## O que você fornece

Cabeçalho, linhas e, se houver, rodapé e legenda.

## Especificação

- Cabeçalho em `caption` 600 sobre `surface-secondary`; células em `body-small`; divisor `border-primary` entre linhas; borda e raio `radius-large` em volta.
- Números alinhados à direita. Hover de linha em `interactive-fill-quiet-hover`; linha selecionada (`data-state="selected"`) em `surface-accent`.
- No celular, até três colunas. Mais do que isso vira lista (`RedemptionItem`, `ListRow`). A tabela rola na horizontal dentro da própria moldura.

## Acessibilidade

`th` com `scope="col"`; `TableCaption` nomeia a tabela; a moldura recebe foco para rolar com o teclado.

## Código

```
<Soma.Table aria-label="Extrato de pontos"><Soma.TableHeader><Soma.TableRow><Soma.TableHead>Data</Soma.TableHead></Soma.TableRow></Soma.TableHeader><Soma.TableBody>…</Soma.TableBody></Soma.Table>
```

---
**Usar para:** Tabela de dados simples, como o extrato de pontos.
**Nunca:** usar para lista de itens tocáveis (use `ListRow`).
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
