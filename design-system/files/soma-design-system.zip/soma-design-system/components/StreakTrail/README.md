# StreakTrail

Os sete dias da semana na trilha do Quiz, com o estado de cada um.

## O que você fornece

Sete dias (`days`), cada um com a inicial (`label`) e o estado (`state`): `done`, `protected`, `today` ou `future`. Use `today: true` em um dia já respondido para dar a ele o anel de hoje.

## Especificação

- Círculos de 32px: respondido em `primary` com `check`; protegido em azul com escudo; hoje sem resposta com anel de destaque; dia futuro em cinza.
- A letra do dia de hoje fica em negrito.

## Acessibilidade

`ol` "Sua semana no quiz"; cada dia diz o estado em texto escondido ("respondido", "protegido", "hoje, ainda sem resposta").

## Nas telas da v2

"Sua trilha", Quiz: [Pergunta do dia](prototipo/#849-8934) e [Já respondeu hoje](prototipo/#849-9175).

## Código

```
<Soma.StreakTrail days={[{ label: 'S', state: 'done' }, { label: 'T', state: 'protected' }, { label: 'S', state: 'today' }]} />
```

---
**Usar para:** Os sete dias da semana na trilha do Quiz, com o estado de cada um.
**Nunca:** mostrar mais de sete dias.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
