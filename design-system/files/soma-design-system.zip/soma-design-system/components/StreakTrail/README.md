# StreakTrail

Os sete dias da semana na trilha do Quiz, com o estado de cada um.

## O que você fornece

Sete dias (`days`), cada um com a inicial (`label`) e o estado (`state`): `done`, `protected`, `today` ou `future`. Use `today: true` em um dia já respondido para dar a ele o anel de hoje.

## Especificação

- Círculos de 36px. Feito: check verde em `feedback-fill-positive`. Protegido: escudo em `surface-info`. Hoje sem resposta e dia futuro: a inicial do dia em 12px 700 sobre `surface-track`.
- Hoje leva anel de 3px em `border-highlight`, também quando já foi respondido (Tela 3: check com anel).
- Embaixo de cada círculo vai a inicial em 12px. Os sete dias se espalham na largura (296px).
- O estado `missed` (× vermelho) existe no componente, mas não aparece em nenhuma tela da versão anterior.

## Acessibilidade

`ol` "Sua semana no quiz"; cada dia diz o estado em texto escondido ("respondido", "protegido", "hoje, ainda sem resposta").

## Nas telas da v2

"Sua trilha", Quiz: [Pergunta do dia](prototipo/#849-8934) e [Já respondeu hoje](prototipo/#849-9175).

## Código

```
<Soma.StreakTrail days={[{ label: 'S', state: 'done' }, { label: 'T', state: 'protected' }, { label: 'S', state: 'today' }]} />
```

---
**Usar para:** Os sete dias da semana na trilha do Quiz, com o estado de cada um.
**Nunca:** mostrar mais de sete dias.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
