"Sua trilha": os sete dias da semana no Quiz, com o estado de cada um.

**Você fornece:** sete dias (`days`), cada um com a inicial (`label`) e o estado (`state`): `done`, `protected`, `today`, `missed` ou `future`. Use `today: true` em um dia já respondido para dar a ele o anel de hoje.

- Feito: check em `feedback-fill-positive`. Protegido: escudo em `surface-info`. Perdido: × em `feedback-fill-negative`. Hoje sem resposta e dia futuro: a inicial do dia no círculo.
- Hoje leva anel de 3px em `border-highlight`, também quando já foi respondido (Tela 3: check com anel).
- Abaixo de cada círculo vai a inicial em `caption`; a de hoje em 600.

**Acessibilidade:** `ol` com nome "Sua semana no quiz"; cada dia diz o estado em texto escondido ("respondido", "protegido", "hoje, ainda sem resposta").

**Figma:** "Sua trilha" no Quiz, Telas 1 e 3 (443:15190).

**React:** `<Soma.StreakTrail days={[{ label: 'S', state: 'done' }, { label: 'T', state: 'protected' }, { label: 'Q', state: 'today' }]} />`
