Os sete dias da semana na trilha do Quiz, com o estado de cada um.

**Você fornece:** sete dias (`days`), cada um com a inicial (`label`) e o estado (`state`): `done`, `protected`, `today` ou `future`. Use `today: true` em um dia já respondido para dar a ele o anel de hoje.

- Círculos de 36px. Feito: check verde em `feedback-fill-positive`. Protegido: escudo em `surface-info`. Hoje sem resposta e dia futuro: a inicial do dia em 12px 700 sobre `surface-track`.
- Hoje leva anel de 3px em `border-highlight`, também quando já foi respondido (Tela 3: check com anel).
- Embaixo de cada círculo vai a inicial em 12px. Os sete dias se espalham na largura (296px).
- O estado `missed` (× vermelho) existe no componente, mas não aparece em nenhuma tela do Figma.

**Acessibilidade:** `ol` "Sua semana no quiz"; cada dia diz o estado em texto escondido ("respondido", "protegido", "hoje, ainda sem resposta").

**Figma:** "Sua trilha", Quiz, Telas 1 e 3 (443:15355, 443:15595).

**React:** `<Soma.StreakTrail days={[{ label: 'S', state: 'done' }, { label: 'T', state: 'protected' }, { label: 'S', state: 'today' }]} />`

---
**Usar para:** Os sete dias da semana na trilha do Quiz, com o estado de cada um.
**Nunca:** mostrar mais de sete dias.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
