Trilha da semana do quiz: um círculo por dia com o estado da sequência.

**Você fornece:** os sete dias, cada um com rótulo ("Seg") e estado.

- Círculos de 36px. `done`: `feedback-fill-positive` com check. `protected`: `surface-info` com escudo em `icon-info`. `today`: anel de 3px `border-highlight` sobre `surface-track`. `missed`: `feedback-fill-negative` com ×. `future`: `surface-track`.
- Rótulo do dia em `caption`; o de hoje em 600 e `text-primary`.
- Estado nunca só em cor: cada um tem ícone ou anel, e o leitor de tela ouve o nome do estado.

**Acessibilidade:** lista ordenada "Sua semana no quiz"; cada dia é lido como "Qua: protegido".

**Figma:** trilha semanal no Quiz (477:20539).

**React:** `<Soma.StreakTrail days={[{ label: 'Seg', state: 'done' }, …]} />`
