Card da primeira entrega no Ranking, para quem ainda não reciclou no período.

**Você fornece:** nada, se usar a copy do Figma. Opcional: `title`, `description`, `actionLabel` e `onAction`.

- Card `surface-accent` com borda `border-highlight`, raio `radius-large`. Título "Sua jornada começa na 1ª entrega." em `label` bold, apoio "Faça a primeira e entre no ranking do seu espaço de recebimento." em `caption`, e o botão "Agendar primeira entrega" (`loud`, `compact`, largura total).
- Fica **abaixo** da lista de amigos e do pódio, não no lugar deles. Liga o Ranking ao fluxo de Ativação.
- Pendente no handoff: o que o Geral mostra para quem nunca entregou. `PositionCard percent={null}` é a extrapolação do sistema.

**Figma:** Ranking, Tela 4 "0 kg reciclados no período" (443:19294).

**React:** `<Soma.RankingStarterCard onAction={agendarPrimeiraEntrega} />`

---
**Usar para:** Card da primeira entrega no Ranking, para quem ainda não reciclou no período.
**Nunca:** aparecer para quem já entregou no período.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
