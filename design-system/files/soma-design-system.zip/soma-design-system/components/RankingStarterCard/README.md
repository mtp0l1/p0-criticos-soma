# RankingStarterCard

Card da primeira entrega no Ranking, para quem ainda não reciclou no período.

## O que você fornece

Nada, se usar a copy da versão anterior. Opcional: `title`, `description`, `actionLabel` e `onAction`.

## Especificação

- Cartão pêssego com o calendário num disco branco, título, descrição e o botão de agendar.

## Nas telas da v2

Ranking: [Ranking do novato](prototipo/#859-10444), "0 kg reciclados no período".

## Código

```
<Soma.RankingStarterCard onAction={agendarPrimeiraEntrega} />
```

---
**Usar para:** Card da primeira entrega no Ranking, para quem ainda não reciclou no período.
**Nunca:** aparecer para quem já entregou no período.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
