Card de espera no dia da entrega: lembra o endereço e o horário do espaço antes de a pessoa abrir o QR.

**Você fornece:** o endereço com a distância (`address`) e o horário do espaço (`hours`, "Vila Verde recebe até 18h"). Opcional: `title` (padrão "Hoje é o dia da sua entrega!").

- Card `surface-card` com borda, raio `radius-xlarge` (24px), padding 32px, tudo centralizado. Círculo de 64px `surface-secondary` com relógio, título em `screen-title` e as duas linhas em `body-small` `text-secondary`.
- Abaixo do card, fora dele: "Como chegar" (`quiet`, largura total, com `pin`) e, no fim da tela, o botão "Cheguei ao espaço" (`loud`), que abre o QR (`QrCheckinCard`).
- O card não tem botão. Quem leva ao QR é o botão do fim da tela.

**Acessibilidade:** `section` com o nome "Entrega de hoje"; o título é um `h2`.

**Figma:** Tela 31, dia da entrega (443:13491).

**React:** `<Soma.DeliveryDayCard address="Rua das Flores, 120 · 800 m" hours="Vila Verde recebe até 18h" />`