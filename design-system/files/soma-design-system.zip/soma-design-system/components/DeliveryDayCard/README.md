# DeliveryDayCard

Card de espera no dia da entrega: lembra o endereço e o horário do espaço antes de a pessoa abrir o QR.

## O que você fornece

O endereço com a distância (`address`) e o horário do espaço (`hours`, "Vila Verde recebe até 18h"). Opcional: `title` (padrão "Hoje é o dia da sua entrega!").

## Especificação

- `SpaceMap` de 156px, título em `screen-title` alinhado à esquerda e um cartão branco com endereço e horário, cada um com ícone.
- Abaixo, fora do componente: "Cheguei ao espaço" (`loud`, com `flag`), que abre o QR (`QrCheckinCard`), e "Como chegar" (`quiet`, com `navigation`).

## Acessibilidade

`section` com o nome "Entrega de hoje"; o título é um `h2`.

## Nas telas da v2

Ativação: [Dia da entrega](prototipo/#842-10084).

## Código

```
<Soma.DeliveryDayCard address="Rua das Flores, 120 · 800 m" hours="Vila Verde recebe até 18h" />
```

---
**Usar para:** Card de espera no dia da entrega: lembra o endereço e o horário do espaço antes de a pessoa abrir o QR.
**Nunca:** trocar o lembrete de endereço e horário pelo próprio QR (ele vive no `QrCheckinCard`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
