Pontos de progresso do cadastro: um ponto por passo, o atual em destaque.

**Você fornece:** o passo atual (`current`, começando em 1) e o total.

- Pontos de 8px (`space-nano`), raio cheio, `space-nano` entre eles. Atual: `selected-indicator` (#FFA125). Feitos: `interactive-fill-loud`. Pendentes: `indicator-inactive` (#ACBDD2).
- Fica abaixo do botão "Continuar", centralizado, como no Figma.
- Só para fluxo linear de etapas. Para progresso de meta ou nível, use `Progress`.

**Acessibilidade:** os pontos são decorativos; o leitor de tela ouve "Passo 1 de 7".

**Figma:** "Switcher" no Cadastro (476:7338).

**React:** `<Soma.StepDots current={1} total={7} />`
