# StepDots

Progresso do cadastro: um segmento por passo, o atual mais largo, com o texto "Passo X de N".

## O que você fornece

O passo atual (`current`, começando em 1) e o total.

## Especificação

- Segmentos de 6px de altura e 20px de largura (28px o atual), raio cheio, 6px entre eles. Passos feitos e atual: `selected-indicator`; os próximos: `surface-track`. Abaixo, o texto Passo X de N.
- Fica abaixo do botão "Continuar", a 40px dele, centralizado, como no handoff anterior. Já vem dentro do `SignupStep`.
- Só para fluxo linear de etapas. Para progresso de meta ou nível, use `Progress`.

## Acessibilidade

Os segmentos são decorativos; o leitor de tela ouve "Passo 1 de 7".

## Nas telas da v2

Indicador de passos do Cadastro, de [Nome e data de nascimento](prototipo/#835-6472) a [Código de convite (vazio)](prototipo/#835-6657).

## Código

```
<Soma.StepDots current={1} total={7} />
```

---
**Usar para:** Progresso do cadastro: um segmento por passo, o atual mais largo, com o texto "Passo X de N".
**Nunca:** destacar mais de um segmento como atual: só o passo atual é mais largo.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
