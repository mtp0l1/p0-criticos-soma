Pontos de progresso do cadastro: um ponto por passo, só o atual em destaque.

**Você fornece:** o passo atual (`current`, começando em 1) e o total.

- Pontos de 8px (`space-nano`), raio cheio, `space-nano` entre eles. Atual: `selected-indicator` (#FFA125). Todos os outros, feitos ou não: `indicator-inactive` (#ACBDD2). O Figma não pinta os passos já feitos.
- Fica abaixo do botão "Continuar", a 40px dele, centralizado, como no Figma. Já vem dentro do `SignupStep`.
- Só para fluxo linear de etapas. Para progresso de meta ou nível, use `Progress`.

**Acessibilidade:** os pontos são decorativos; o leitor de tela ouve "Passo 1 de 7".

**Figma:** "Switcher" no Cadastro (476:7338 e 443:9597).

**React:** `<Soma.StepDots current={1} total={7} />`
