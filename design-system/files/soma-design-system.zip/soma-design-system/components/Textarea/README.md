Campo de texto de várias linhas (shadcn Textarea). Para "Enviar sugestão" e mensagens ao SAC.

**Você fornece:** o rótulo, o valor e, se houver, o limite de caracteres.

- Mesma borda, raio, foco e erro do `Input`; quatro linhas por padrão, redimensiona na vertical.
- Mostre o limite abaixo em `caption` ("Até 500 caracteres") e o contador quando faltar pouco.

**React:** `<Soma.Label htmlFor="sug">Sua sugestão</Soma.Label><Soma.Textarea id="sug" value={t} onChange={(e) => setT(e.target.value)} />`
