# Textarea

Campo de texto de várias linhas. Para "Enviar sugestão" e mensagens ao SAC.

## O que você fornece

O rótulo, o valor e, se houver, o limite de caracteres.

## Especificação

- Mesma borda, raio, foco e erro do `Input`; quatro linhas por padrão, redimensiona na vertical.
- Mostre o limite abaixo em `caption` ("Até 500 caracteres") e o contador quando faltar pouco.

## Código

```
<Soma.Label htmlFor="sug">Sua sugestão</Soma.Label><Soma.Textarea id="sug" value={t} onChange={(e) => setT(e.target.value)} />
```

---
**Usar para:** Campo de texto de várias linhas.
**Nunca:** usar para resposta curta (use `Input`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
