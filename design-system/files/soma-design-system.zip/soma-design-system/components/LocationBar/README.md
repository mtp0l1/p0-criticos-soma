Barra do topo que mostra o espaço de recebimento onde a pessoa entrega e abre a troca de local.

**Você fornece:** o nome do local (ou nada, quando a pessoa ainda não escolheu) e o que acontece ao tocar.

- **Uma linha**, centralizada: pino de 16px em `icon-brand`, "Entregando em Casa so+ma Batel" em `caption` (12px) e `text-primary`, seta para baixo de 12px em `icon-brand-strong`. Espaço de 6px entre os três. Altura visual de 16px.
- A área de toque tem 44px (`hitArea`), maior que o desenho: não mude o espaçamento da tela para acomodá-la.
- Sem local, a barra vira chamada: "Adicione seu local de entrega" em `text-link`. Nunca mostre "Sem preferência de espaço" como se fosse um lugar.
- A seta para baixo indica troca de local. Ela não é voltar: não ponha outra seta de voltar ao lado.
- Na Home, use `sticky` para a barra ficar visível ao rolar (ganha divisor embaixo).

**Acessibilidade:** a barra é um único botão; o texto lido é "Entregando em Casa so+ma Batel".

**Estados:** hover e toque em `interactive-fill-quiet-*`, foco com anel `ring`.

**Figma:** Início, Home DEPOIS (443:12071). Antes eram duas linhas ("Entregando em" em cima do nome).

**React:** `<Soma.LocationBar location={local} sticky onPress={abrirLocais} />`
