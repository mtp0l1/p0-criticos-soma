# LocationBar

Barra do topo que mostra o espaço de recebimento onde a pessoa entrega e abre a troca de local.

## O que você fornece

O nome do local (ou nada, quando a pessoa ainda não escolheu) e o que acontece ao tocar.

## Especificação

- **Uma linha**, centralizada: pino de 16px em `icon-brand`, "Entregando em Casa so+ma Batel" em `caption` (12px) e `text-primary`, seta para baixo de 12px em `icon-brand-strong`. Espaço de 6px entre os três. Altura visual de 16px.
- A área de toque tem 44px (`hitArea`), maior que o desenho: não mude o espaçamento da tela para acomodá-la.
- Sem local, a barra vira chamada: "Adicione seu local de entrega" em `text-link`. Nunca mostre "Sem preferência de espaço" como se fosse um lugar.
- A seta para baixo indica troca de local. Ela não é voltar: não ponha outra seta de voltar ao lado.
- Na Home, use `sticky` para a barra ficar visível ao rolar (ganha divisor embaixo).

## Estados

Hover e toque em `interactive-fill-quiet-*`, foco com anel `ring`.

## Acessibilidade

A barra é um único botão; o texto lido é "Entregando em Casa so+ma Batel".

## Nas telas da v2

Início: [Início · depois](prototipo/#829-6915). Antes eram duas linhas ("Entregando em" em cima do nome).

## Código

```
<Soma.LocationBar location={local} sticky onPress={abrirLocais} />
```

---
**Usar para:** Barra do topo que mostra o espaço de recebimento onde a pessoa entrega e abre a troca de local.
**Nunca:** esconder a troca de local; sem espaço escolhido vira chamada, não some.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
