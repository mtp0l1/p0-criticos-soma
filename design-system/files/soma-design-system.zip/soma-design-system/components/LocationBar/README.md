Barra do topo que mostra o espaço de recebimento onde a pessoa entrega e abre a troca de local.

**Você fornece:** o nome do local (ou nada, quando a pessoa ainda não escolheu) e o que acontece ao tocar.

- Pino em `icon-brand`, legenda "Entregando em" em `caption` e `text-secondary`, local em `label` e `text-primary`, seta para baixo em `icon-brand-strong`.
- Sem local, a barra vira chamada: "Adicione seu local de entrega" em `text-link`. Nunca mostre "Sem preferência de espaço" como se fosse um lugar.
- A seta para baixo indica troca de local. Ela não é voltar: não ponha outra seta de voltar ao lado.
- Na Home, use `sticky` para a barra ficar visível ao rolar.

**Acessibilidade:** a barra é um único botão; o texto lido é "Entregando em Curitiba - Mercado Municipal".

**Estados:** hover e toque em `interactive-fill-quiet-*`, foco com anel `ring`.

**React:** `<Soma.LocationBar location={local} sticky onPress={abrirLocais} />`
