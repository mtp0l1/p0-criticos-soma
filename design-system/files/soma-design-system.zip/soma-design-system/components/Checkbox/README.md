Caixa de seleção, sobre Radix Checkbox (shadcn Checkbox). Para aceite de regulamento e preferências independentes.

**Você fornece:** o texto ao lado (num `label` que envolve o checkbox ou com `htmlFor`) e o estado.

- Caixa de 20px, raio `radius-xsmall`, borda `input`. Marcada: `surface-inverse` com check `text-inverse`. O laranja não é usado aqui porque não passa de 3:1 contra o branco.
- A linha toda (texto e caixa) é tocável, com altura mínima `size-touch`.
- Desabilitado: fundo `interactive-fill-disabled` e borda `border`; o texto vai para `interactive-text-disabled` e diz o motivo.
- Escolha única usa `RadioList`; liga/desliga com efeito imediato usa `Switch`.

**Acessibilidade:** `role="checkbox"` com `aria-checked`, espaço alterna, suporta `indeterminate`.

**React:** `<label><Soma.Checkbox checked={aceite} onCheckedChange={setAceite} />Li e aceito o regulamento</label>`
