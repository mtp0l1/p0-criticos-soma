# Checkbox

Caixa de seleção. Para aceite de regulamento e preferências independentes.

## O que você fornece

O texto ao lado (num `label` que envolve o checkbox ou com `htmlFor`) e o estado.

## Especificação

- Caixa de 26px, raio `radius-xsmall` (8px), borda input de 2px. Marcada: laranja (`primary`) com a marca de check em azul-marinho; a marca também mostra o estado, não só a cor.
- A linha toda (texto e caixa) é tocável, com altura mínima `size-touch`.
- Desabilitado: fundo `interactive-fill-disabled` e borda `border`; o texto vai para `interactive-text-disabled` e diz o motivo.
- Escolha única usa `RadioList`; liga/desliga com efeito imediato usa `Switch`.
- A área tocável da caixa é de 44px mesmo fora de uma linha. Estado `indeterminate` (traço) para "alguns marcados". Erro: `aria-invalid` pinta a borda de `feedback-text-negative`.

## Acessibilidade

`role="checkbox"` com `aria-checked`, espaço alterna, suporta `indeterminate`.

## Código

```
<label><Soma.Checkbox checked={aceite} onCheckedChange={setAceite} />Li e aceito o regulamento</label>
```

---
**Usar para:** Caixa de seleção.
**Nunca:** usar para escolha única (use `RadioList`) nem sem rótulo ao lado.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
