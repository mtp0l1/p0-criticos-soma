Contêiner de conteúdo (shadcn Card) com cabeçalho, título, descrição, conteúdo e rodapé, em quatro variantes.

**Você fornece:** o conteúdo e a variante.

- `variant`: `outline` (borda `border` sobre fundo branco, padrão), `flat` (sem borda, sobre `background-secondary`), `accent` (creme), `inverse` (navy, texto `text-inverse`).
- Raio `radius-large`, padding e gap `space-mini`/`space-micro`. `padding="none"` para conteúdo que vai até a borda.
- Sem sombra: o app é plano. Card inteiro tocável vira botão ou link; não ponha botões dentro de um card tocável.
- `CardTitle` em `body-strong`, `CardDescription` em `caption` e `muted-foreground`.
- `CardAction` põe uma ação no canto do cabeçalho (use `CardHeader className="grid-cols-[1fr_auto]"`).

**React:** `<Soma.Card variant="flat"><Soma.CardHeader><Soma.CardTitle>…</Soma.CardTitle></Soma.CardHeader><Soma.CardContent>…</Soma.CardContent></Soma.Card>`

---
**Usar para:** Contêiner de conteúdo (shadcn Card) com cabeçalho, título, descrição, conteúdo e rodapé, em quatro variantes.
**Nunca:** aninhar card dentro de card nem mudar o raio por `className`.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
