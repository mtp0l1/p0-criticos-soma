Um nível na tela "Campeão da Reciclagem" (Tela 5): troféu, nome, etiqueta de dificuldade e quantas perguntas pede. Cada nível tem fundo e contorno próprios.

**Você fornece:** o nível (`tier`). Opcional: `current` e `questions`.

- Bronze (Iniciante, 5 perguntas): fundo `surface-accent`, contorno `border-highlight`. Prata (Intermediário, 15): fundo `surface-secondary`, contorno `border`. Ouro (Avançado, 50): fundo `tier-gold-surface`, contorno `tier-gold-border`. As metas estão em `TIER_GOAL`.
- Troféu de 96px, nome em 17px 800, `LevelBadge` `level` e "Responda 15 perguntas" em 12px. Raio `radius-large`, espaço interno de 16px.
- No Figma o cartão do nível atual não muda de aparência. `current` só marca `aria-current` para leitores de tela.
- É um `li`: use dentro de uma lista (`ul`) com `aria-label`. Depois dos três, o `ProtectionNotice` `card` e o botão "Começar".

**Acessibilidade:** o nível atual leva `aria-current="true"`.

**Figma:** Quiz, Telas 5 e 6 (443:15921, 443:16021).

**React:** `<ul className="grid gap-nano"><Soma.TierCard tier="bronze" current /><Soma.TierCard tier="prata" /><Soma.TierCard tier="ouro" /></ul>`
