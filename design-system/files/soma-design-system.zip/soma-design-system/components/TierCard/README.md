Linha da lista de níveis do quiz (Bronze, Prata, Ouro), com a medalha, o nome, a classificação e quantas perguntas pede cada um.

**Você fornece:** o nível (`tier`); `current` para marcar onde a pessoa está e `questions` se quiser mostrar a meta. Com a arte exportada, passe `src`.

- Metas: Bronze (Iniciante) 5 perguntas, Prata (Intermediário) 15, Ouro (Avançado) 50. Estão em `TIER_GOAL`.
- Mostra a `Medal`, o nome do nível, o `LevelBadge` (`kind="level"`) e "Responda 15 perguntas". O nível atual ganha a borda `border-highlight`.
- É um `li`: use dentro de uma lista (`ul`) com `aria-label`.

**Acessibilidade:** o nível atual leva `aria-current="true"`, então o estado não depende só da borda.

**Figma:** Quiz, Tela 5 "Campeão da Reciclagem" (443:15190).

**React:** `<ul className="grid gap-xmini"><Soma.TierCard tier="bronze" current /><Soma.TierCard tier="prata" /><Soma.TierCard tier="ouro" /></ul>`
