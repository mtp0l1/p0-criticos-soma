# TierCard

Um nível na tela "Campeão da Reciclagem": troféu, nome, etiqueta de dificuldade e quantas perguntas pede. O nível atual ganha destaque.

## O que você fornece

O nível (`tier`). Opcional: `current` e `questions`.

## Especificação

- Nível atual (`current`): fundo `surface-accent`, borda de destaque e etiqueta em `primary`.
- Os outros: cartão branco com sombra e etiqueta neutra.

## Acessibilidade

O nível atual leva `aria-current="true"`.

## Nas telas da v2

Quiz: [Primeira vez no Quiz](prototipo/#849-9497) e [Como funciona a proteção](prototipo/#849-9594).

## Código

```
<ul className="grid gap-nano"><Soma.TierCard tier="bronze" current /><Soma.TierCard tier="prata" /><Soma.TierCard tier="ouro" /></ul>
```

---
**Usar para:** Um nível na tela "Campeão da Reciclagem" (Tela 5): troféu, nome, etiqueta de dificuldade e quantas perguntas pede.
**Nunca:** mostrar nível sem troféu e sem a etiqueta de dificuldade.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
