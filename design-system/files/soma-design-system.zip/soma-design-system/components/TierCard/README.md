# TierCard

Um nível na tela "Campeão da Reciclagem" (Tela 5): troféu, nome, etiqueta de dificuldade e quantas perguntas pede. Cada nível tem fundo e contorno próprios.

## O que você fornece

O nível (`tier`). Opcional: `current` e `questions`.

## Especificação

- Bronze (Iniciante, 5 perguntas): fundo `surface-accent`, contorno `border-highlight`. Prata (Intermediário, 15): fundo `surface-secondary`, contorno `border`. Ouro (Avançado, 50): fundo `tier-gold-surface`, contorno `tier-gold-border`. As metas estão em `TIER_GOAL`.
- Troféu de 96px, nome em 18px 800, `LevelBadge` `level` e "Responda 15 perguntas" em 12px. Raio `radius-large`, espaço interno de 16px.
- No versão anterior o cartão do nível atual não muda de aparência. `current` só marca `aria-current` para leitores de tela.
- É um `li`: use dentro de uma lista (`ul`) com `aria-label`. Depois dos três, o `ProtectionNotice` `card` e o botão "Começar".

## Acessibilidade

O nível atual leva `aria-current="true"`.

## Nas telas da v2

Quiz: [Primeira vez no Quiz](prototipo/#849-9497) e [Como funciona a proteção](prototipo/#849-9594).

## Código

```
<ul className="grid gap-nano"><Soma.TierCard tier="bronze" current /><Soma.TierCard tier="prata" /><Soma.TierCard tier="ouro" /></ul>
```

---
**Usar para:** Um nível na tela "Campeão da Reciclagem" (Tela 5): troféu, nome, etiqueta de dificuldade e quantas perguntas pede.
**Nunca:** mostrar nível sem troféu e sem a etiqueta de dificuldade.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
