Linha do catálogo de recompensas: título, pontos e seta. Tocável inteira, abre o detalhe.

**Você fornece:** o título (`title`) e os pontos (`points`). Opcional: `tags` (etiquetas curtas como "2× vidro"), `current` (prêmio da meta atual), `image`/`icon`, `href` ou `onClick`.

- Card `surface-primary` com borda `border-primary` e `radius-large`, padding `space-micro`. Título em `label`; abaixo, "800 pontos" em `caption` bold `text-link` e as etiquetas na mesma linha. Seta à direita.
- **Sem miniatura** por padrão (o Figma não usa). `icon` e `image` existem para outras listas.
- `current`: borda `border-highlight` e etiqueta "Sua meta atual" (caution), na mesma linha dos pontos.
- Prêmios acima do saldo aparecem iguais aos outros. O "falta X pontos" fica só no `GoalCard` e no detalhe, não na linha.

**Acessibilidade:** a linha inteira é um link ou botão; o título é o nome acessível e os pontos entram na leitura.

**Figma:** Recompensas, Telas 1, 5, 9 e 23 (438:1973).

**React:** `<Soma.RewardRow title="Kit 5 canetas Fine Pen" points={800} current href="/recompensas/kit-canetas" />`
