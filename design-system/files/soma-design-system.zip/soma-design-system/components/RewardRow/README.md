# RewardRow

Linha do catálogo de recompensas: título, pontos, quanto falta e seta. Tocável inteira, abre o detalhe.

## O que você fornece

O título (`title`) e os pontos (`points`). Opcional: `balance` (o saldo da pessoa), `tags` (etiquetas curtas como "2× vidro"), `current` (prêmio da meta atual), `image`/`icon`, `href` ou `onClick`.

## Especificação

- Card `surface-primary` com borda `border-primary` e `radius-large`, padding `space-micro`. Título em `label`; abaixo, "800 pontos" em `caption` bold `text-link` e as etiquetas na mesma linha. Seta à direita.
- **Sem miniatura** por padrão (a versão anterior não usa). `icon` e `image` existem para outras listas.
- `current`: borda `border-highlight` e etiqueta "Sua meta atual" (caution), na mesma linha dos pontos.
- Com `balance`, a linha diz o que falta, ao lado dos pontos: "Faltam 130 pontos" em texto secundário ou, quando o saldo alcança, "Você já pode trocar" em `feedback-text-positive`. Sem `balance`, mostra só os pontos.

## Acessibilidade

A linha inteira é um link ou botão; o título é o nome acessível e os pontos entram na leitura.

## Nas telas da v2

Recompensas: [Catálogo com meta](prototipo/#854-9534), [Meta atingida](prototipo/#854-9923), [Escolha a próxima meta](prototipo/#854-10106) e [Categoria](prototipo/#854-9429).

## Código

```
<Soma.RewardRow title="Kit 5 canetas Fine Pen" points={800} balance={320} current href="/recompensas/kit-canetas" />
```

---
**Usar para:** Linha do catálogo de recompensas: título, pontos, quanto falta e seta.
**Nunca:** ter área tocável menor que a linha inteira.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
