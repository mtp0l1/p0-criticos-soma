Linha do catálogo de recompensas. Tocável inteira, abre o detalhe.

**Você fornece:** título, parceiro, pontos, imagem ou ícone e, se houver, etiquetas e quanto falta.

- Card `surface-primary` com borda `border-primary`, raio `radius-large`, padding `space-micro`. `Thumb` quadrado à esquerda, seta `chevron-right` à direita.
- Etiquetas em `Badge`: campanha `positive` ("2× vidro"), meta `caution` ("Sua meta atual").
- Pontos em `caption` 600 `text-link`. Com saldo menor que o custo: "· faltam 1.106", sem bloquear o toque.
- No Figma a linha tem sombra; o sistema é plano, então a separação vem da borda.

**Acessibilidade:** um único elemento tocável (`a` com `href`, senão `button`) que lê título, parceiro e pontos.

**Figma:** linhas do catálogo em Recompensas (477:22160).

**React:** `<Soma.RewardRow title="Almoço executivo" partner="Restaurante Bom Prato" points={600} icon="utensils" onClick={abrir} />`
