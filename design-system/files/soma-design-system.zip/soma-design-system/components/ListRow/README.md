Linha de lista em dois formatos: `help` (creme, com título, legenda e seta) e `menu` (ícone, rótulo e divisor).

**Você fornece:** o título, a legenda quando houver, o ícone no Menu e o destino.

- `help`: fundo `surface-accent`, raio `radius-medium`, título `label`, legenda `caption` em `text-secondary`, seta `icon-brand-strong`. Empilhe com gap `space-nano`.
- `menu`: fundo `surface-primary`, ícone `icon-primary`, rótulo `label`, divisor `border-primary`, sem raio.
- A legenda diz o que a pessoa encontra ao entrar, sem repetir o título.
- Não misture os dois formatos na mesma lista. Altura mínima `size-touch`.

**Estados:** `help` em `surface-accent-hover`, `menu` em `interactive-fill-quiet-*`; foco com anel `ring`. Com `href`, vira link. Classes: `listRowVariants`.

**React:** `<Soma.ListRow title="Pontos" description="Dúvidas ou informações sobre pontos." />` · `<Soma.ListRow variant="menu" icon="card" title="Meu cartão" />`

---
**Usar para:** Linha de lista em dois formatos: `help` (creme, com título, legenda e seta) e `menu` (ícone, rótulo e divisor).
**Nunca:** misturar os formatos `help` e `menu` na mesma lista.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
