# Toaster

Provedor de avisos passageiros, com fila, tempo e gesto de dispensar.

## O que você fornece

Um `<Toaster />` na raiz do produto e chamadas a `notify(mensagem, { kind })`.

## Especificação

- O aviso usa o visual do `Toast` do Campana: `error` (padrão, 6s), `success` e `info` (4s). Dois avisos visíveis por vez; os outros esperam na fila.
- Aparece embaixo, acima da barra inferior (`offset` de 96px). Pode ser arrastado para dispensar e tem o X.
- Só para o que pode sumir sem prejuízo. O que precisa ficar na tela vai em `Message`; decisão vai em `AlertDialog`.

## Acessibilidade

A região "Avisos" é anunciada sem tirar o foco; erro usa `role="alert"`, os demais `role="status"`.

## Base técnica

Sonner com `unstyled`; `notify` chama `toast.custom` e renderiza o `Toast`. `duration` e `dismissible` são opções.

## Código

```
<Soma.Toaster />
```

```
Soma.notify('Entrega agendada para seg, 07 set', { kind: 'success' })
```

---
**Usar para:** Provedor de avisos passageiros, com fila, tempo e gesto de dispensar.
**Nunca:** montar mais de um provedor por produto.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
