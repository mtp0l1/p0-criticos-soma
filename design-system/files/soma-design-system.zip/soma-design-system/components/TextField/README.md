Campo de formulário com rótulo acima, texto de ajuda e mensagem de erro.

**Você fornece:** o rótulo, o valor, a ajuda e, quando houver, o erro dizendo o que fazer.

- Rótulo em `label` e `text-primary`; obrigatório leva " *". Campo de `size-input`, borda `border-strong`, raio `radius-medium`.
- Ajuda em `caption` e `text-secondary`. Erro em `feedback-text-negative`, com ícone e borda na mesma cor: "Digite um CPF válido para continuar".
- Use `inputMode` certo (CPF e valor: `numeric`; e-mail: `email`) e máscara de CPF.
- Valide antes de avançar: o botão do passo fica desabilitado até o campo ser válido. Valor de doação nunca acima do saldo.
- Escreva "e-mail" com hífen, no rótulo e no título.

**Acessibilidade:** `label` ligado ao `input`; ajuda e erro em `aria-describedby`; erro com `aria-invalid`.

**Base técnica:** padrão Form do shadcn: `Label` + `Input` + descrição + mensagem, com `id`, `aria-describedby` e `aria-invalid` ligados automaticamente.

**React:** `<Soma.TextField label="CPF" value={cpf} onChange={setCpf} inputMode="numeric" error={erro} required />`
