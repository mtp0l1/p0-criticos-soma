Campo de formulário com rótulo acima, texto de ajuda e mensagem de erro.

**Você fornece:** o rótulo, o valor, a ajuda e, quando houver, o erro dizendo o que fazer.

- Rótulo em `body-small` regular e `text-primary`; obrigatório leva "*" colado ao texto ("Celular*"). Campo de **48px** (`size-input`, a mesma altura do botão), borda `border-strong`, raio `radius-medium`. Rótulo e campo ficam a 8px.
- Ajuda em `caption` e `text-secondary`. Erro em `feedback-text-negative`, com ícone e borda na mesma cor: "Digite um CPF válido para continuar".
- `mask="cpf"`, `"phone"` ou `"cep"` põe o teclado numérico, o placeholder do Figma (000.000.000-00, (00) 00000-0000, 00000-000) e formata enquanto a pessoa digita; `onChange` recebe o texto já formatado. As funções `maskCpf`, `maskPhone` e `maskCep` também saem do pacote. Outros dados: `inputMode` certo (valor: `numeric`; e-mail: `email`).
- `trailing` põe um elemento dentro do campo, à direita (o botão de `PasswordField`).
- Valide antes de avançar: o botão do passo fica desabilitado até o campo ser válido. Valor de doação nunca acima do saldo.
- Escreva "e-mail" com hífen, no rótulo e no título.

**Acessibilidade:** `label` ligado ao `input`; ajuda e erro em `aria-describedby`; erro com `aria-invalid`.

**Base técnica:** padrão Form do shadcn: `Label` + `Input` + descrição + mensagem, com `id`, `aria-describedby` e `aria-invalid` ligados automaticamente.

**Figma:** Cadastro (443:9597 a 443:9786) e Doar pontos (463:4536). Os dois usam campo de 48px; o Figma de Doar tem rótulo de 12px e raio de 12px, o de Cadastro rótulo de 14px e raio de 8px: o sistema fica com 14px e 12px.

**React:** `<Soma.TextField label="CPF" mask="cpf" value={cpf} onChange={setCpf} error={erro} required />`

---
**Usar para:** Campo de formulário com rótulo acima, texto de ajuda e mensagem de erro.
**Nunca:** trocar rótulo por placeholder nem apagar o que a pessoa digitou ao mostrar erro.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
