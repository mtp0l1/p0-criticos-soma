# TextField

Campo de formulário com rótulo flutuante dentro do campo, texto de ajuda e mensagem de erro.

## O que você fornece

O rótulo, o valor, a ajuda e, quando houver, o erro dizendo o que fazer.

## Especificação

- Rótulo em `body-small` regular e `text-primary`; obrigatório leva "_" colado ao texto ("Celular_"). Campo de **68px** (`size-input`), com o rótulo flutuante dentro do campo, borda border, raio `radius-large`, `shadow-card`. O rótulo fica dentro do campo, a 12px do topo.
- Ajuda em `caption` e `text-secondary`. Erro em `feedback-text-negative`, com ícone e borda na mesma cor: "Digite um CPF válido para continuar".
- `mask="cpf"`, `"phone"` ou `"cep"` põe o teclado numérico, o placeholder do handoff anterior (000.000.000-00, (00) 00000-0000, 00000-000) e formata enquanto a pessoa digita; `onChange` recebe o texto já formatado. As funções `maskCpf`, `maskPhone` e `maskCep` também saem do pacote. Outros dados: `inputMode` certo (valor: `numeric`; e-mail: `email`).
- `trailing` põe um elemento dentro do campo, à direita (o botão de `PasswordField`).
- Valide antes de avançar: o botão do passo fica desabilitado até o campo ser válido. Valor de doação nunca acima do saldo.
- Escreva "e-mail" com hífen, no rótulo e no título.

## Acessibilidade

`label` ligado ao `input`; ajuda e erro em `aria-describedby`; erro com `aria-invalid`.

## Nas telas da v2

Cadastro, de [Nome e data de nascimento](prototipo/#835-6472) a [Código de convite (vazio)](prototipo/#835-6657), e Doar pontos ([Valor da doação](prototipo/#832-6750)). Campo de 68px com rótulo flutuante; a lista completa de estados está em [Campo vazio](prototipo/#832-6686), [Valor maior que o saldo](prototipo/#832-6819) e [Valor zero](prototipo/#832-6884).

## Base técnica

Padrão Form do shadcn: `Label` + `Input` + descrição + mensagem, com `id`, `aria-describedby` e `aria-invalid` ligados automaticamente.

## Código

```
<Soma.TextField label="CPF" mask="cpf" value={cpf} onChange={setCpf} error={erro} required />
```

---
**Usar para:** Campo de formulário com rótulo flutuante dentro do campo, texto de ajuda e mensagem de erro.
**Nunca:** trocar rótulo por placeholder nem apagar o que a pessoa digitou ao mostrar erro.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
