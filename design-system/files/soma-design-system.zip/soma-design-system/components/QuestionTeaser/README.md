Card "Pergunta do dia" no Início, que chama para o Quiz. Substitui o banner "Ganhe suas medalhas / Responda ao Quiz".

**Você fornece:** o texto (`question`), o apoio (`hint`) e o destino (`href` ou `onPress`).

- Card `surface-primary` com borda `border-highlight`, ícone de pergunta em `icon-brand-strong`, título em `label` e apoio em `caption`.
- Um só toque leva ao Quiz. Com `href`, vira link.
- Texto sugerido: "Isopor é reciclável?" com "Responda para somar pontos e trocar por recompensas." Não mostre o nível nem as medalhas na Home.

**Acessibilidade:** o card inteiro é um link ou botão com o título como nome; foco com o anel do sistema.

**Figma:** Início, "Pergunta do dia" (438:1973).

**React:** `<Soma.QuestionTeaser question="Isopor é reciclável?" hint="Responda para somar pontos e trocar por recompensas." href="/quiz" />`
