Card "Pergunta do dia" no Início, que chama para o Quiz. Substitui o banner "Ganhe suas medalhas / Responda ao Quiz".

**Você fornece:** o texto (`question`), o apoio (`hint`) e o destino (`href` ou `onPress`). Coloque um `SectionHeader` "Pergunta do dia" acima.

- Card `surface-primary` com borda de **1px** `border-highlight`, raio `radius-large`, padding 16. Ícone de pergunta em `icon-brand`, título em `label` (14px) e apoio em `caption`.
- Um só toque leva ao Quiz. Com `href`, vira link.
- Texto sugerido: "Isopor é reciclável?" com "Responda para somar pontos e trocar por recompensas." Não mostre o nível nem os troféus na Home.

**Acessibilidade:** o card inteiro é um link ou botão com o título como nome; foco com o anel do sistema.

**Figma:** Início, Home DEPOIS (443:12071): título de bloco "Pergunta do dia" + card. Pendente no handoff: onde fica a trilha completa do Quiz depois do Início.

**React:** `<Soma.SectionHeader title="Pergunta do dia" />` + `<Soma.QuestionTeaser question="Isopor é reciclável?" href="/quiz" />`
