# QuestionTeaser

Banner "Pergunta do dia" no Início, que chama para o Quiz: etiqueta, a pergunta e um disco com a seta.

## O que você fornece

O texto (`question`), o apoio (`hint`) e o destino (`href` ou `onPress`).

## Especificação

- Cartão `surface-tint-peach`, raio `radius-2xl` (28px), padding `space-small` (24px). No topo, a etiqueta "Pergunta do dia" em pílula branca (`eyebrow`, ícone `sparkles`). Abaixo, a pergunta em `screen-title` e o apoio em `body-small` `text-secondary`; à direita, um disco de 48px em `surface-inverse` com a seta.
- Um só toque leva ao Quiz. Com `href`, vira link.
- Texto sugerido: "Isopor é reciclável?" com "Responda para somar pontos e trocar por recompensas." Não mostre o nível nem os troféus no Início.

## Acessibilidade

O card inteiro é um link ou botão com o título como nome; foco com o anel do sistema.

## Nas telas da v2

Início: [Início · depois](prototipo/#829-6915), com o título de bloco "Pergunta do dia" e o card. Pendente: onde fica a trilha completa do Quiz depois do Início.

## Código

```
<Soma.SectionHeader title="Pergunta do dia" />
```

```
<Soma.QuestionTeaser question="Isopor é reciclável?" href="/quiz" />
```

---
**Usar para:** Banner "Pergunta do dia" no Início, que chama para o Quiz.
**Nunca:** mostrar a resposta no Início.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
