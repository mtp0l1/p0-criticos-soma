# SpaceDetail

Detalhe de um espaço de recebimento: nome, endereço, horário e "Como chegar".

## O que você fornece

O nome (`name`), o endereço com horário (`address`) e `onDirections`.

## Especificação

- Card `surface-accent`, raio `radius-medium`, padding 12px, com nome em `label`, endereço e horário em `caption` e o botão "Como chegar" (`quiet`, largura total, com `pin`) que abre o mapa.
- Aparece depois da lista de `SpaceCard`, para o espaço escolhido, na Tela 27 (agendamento). Na lista de espaços continua o `SpaceCard`.

## Acessibilidade

O botão diz o nome do espaço ("Como chegar a Vila Verde").

## Nas telas da v2

Reciclar, detalhe do espaço ([Aba Reciclar (nova)](prototipo/#829-7018)) e [Espaço de recebimento](prototipo/#842-9952).

## Código

```
<Soma.SpaceDetail name="Vila Verde" address="Rua das Flores, 120 · Seg a sáb, 8h às 18h" onDirections={abrirMapa} />
```

---
**Usar para:** Detalhe de um espaço de recebimento: nome, endereço, horário e "Como chegar".
**Nunca:** aparecer antes de um espaço ser escolhido.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
