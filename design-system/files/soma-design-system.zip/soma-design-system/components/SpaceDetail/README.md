# SpaceDetail

Painel com o detalhe de um espaço: nome, endereço, horário e "Como chegar". O agendamento da v2 não usa mais este painel: o detalhe está no próprio `SpaceCard` e o mapa no `SpaceMapSheet`.

## O que você fornece

O nome (`name`), o endereço com horário (`address`) e `onDirections`.

## Especificação

- Card `surface-accent`, raio `radius-medium`, padding 12px, com nome em `label`, endereço e horário em `caption` e o botão "Como chegar" (`quiet`, largura total, com `pin`).
- Mantido por compatibilidade. Em tela nova, prefira `SpaceCard` com `SpaceMapSheet`.

## Acessibilidade

O botão diz o nome do espaço ("Como chegar a Vila Verde").

## Nas telas da v2

Nenhuma tela da v2 usa este painel hoje.

## Código

```
<Soma.SpaceDetail name="Vila Verde" address="Rua das Flores, 120 · Seg a sáb, 8h às 18h" onDirections={abrirMapa} />
```

---
**Usar para:** Detalhe de um espaço de recebimento: nome, endereço, horário e "Como chegar".
**Nunca:** usar no agendamento: ali o "Como chegar" fica dentro de cada `SpaceCard`.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
