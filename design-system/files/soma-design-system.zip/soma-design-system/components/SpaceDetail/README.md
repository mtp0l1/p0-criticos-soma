Detalhe de um espaço de recebimento: nome, endereço, horário e "Como chegar".

**Você fornece:** o nome (`name`), o endereço com horário (`address`) e `onDirections`.

- Card `surface-accent`, raio `radius-medium`, padding 12px, com nome em `label`, endereço e horário em `caption` e o botão "Como chegar" (`quiet`, largura total, com `pin`) que abre o mapa.
- Aparece depois da lista de `SpaceCard`, para o espaço escolhido, na Tela 27 (agendamento). Na lista de espaços continua o `SpaceCard`.

**Acessibilidade:** o botão diz o nome do espaço ("Como chegar a Vila Verde").

**Figma:** Reciclar, detalhe do espaço (438:1973) e Tela 27 (443:12890).

**React:** `<Soma.SpaceDetail name="Vila Verde" address="Rua das Flores, 120 · Seg a sáb, 8h às 18h" onDirections={abrirMapa} />`
