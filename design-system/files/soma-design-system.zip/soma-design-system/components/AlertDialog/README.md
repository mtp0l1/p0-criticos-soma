Confirmação que exige resposta antes de seguir, sobre Radix AlertDialog (shadcn AlertDialog). Para sair, apagar ou desfazer algo.

**Você fornece:** a pergunta (título), a consequência (descrição), a ação e a saída.

- Título em `body-strong` como pergunta ("Sair da sua conta?"); descrição diz o que acontece.
- Ação em `AlertDialogAction` (`hierarchy="destructive"` quando apaga ou sai) e saída em `AlertDialogCancel` (`quiet`), empilhadas em largura total, ação em cima.
- Rótulos dizem a ação ("Sair", "Continuar no app"), nunca "Sim" e "Não".
- Sem X e sem fechar ao tocar fora: a pessoa escolhe uma das duas.
- Texto longo rola dentro do diálogo; entrada e saída animadas.

**Acessibilidade:** `role="alertdialog"`, foco vai para o Cancelar, Esc cancela, foco volta ao gatilho.

**React:** `<Soma.AlertDialog><Soma.AlertDialogTrigger asChild>…</Soma.AlertDialogTrigger><Soma.AlertDialogContent>…</Soma.AlertDialogContent></Soma.AlertDialog>`

---
**Usar para:** Confirmação que exige resposta antes de seguir, sobre Radix AlertDialog (shadcn AlertDialog).
**Nunca:** usar para informação sem decisão (use `Modal` ou `Message`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
