Cartão do QR de atendimento: a pessoa mostra o QR no espaço para a equipe registrar a entrega. Substitui o cartão de membro da versão antiga.

**Você fornece:** o QR (`qr`, uma imagem ou elemento) e o nome (`name`). Opcional: `title`, `description` e `steps`.

- Título "Chegou? Mostre este QR no atendimento" em `screen-title`, o texto de apoio, o QR em quadro branco com borda e o nome em maiúsculas.
- Embaixo, três passos curtos: "Mostre o QR", "A equipe pesa seus recicláveis" e "Seus pontos aparecem aqui".
- Fundo de tela em `background-secondary` para o QR ter contraste. O QR não é uma imagem decorativa: dê `alt` com o nome da pessoa.

**Acessibilidade:** o QR leva `alt` "QR de atendimento de Anna Souza"; os passos são uma lista ordenada.

**Figma:** Entrega, Tela 11 (438:1973).

**React:** `<Soma.QrCheckinCard qr={<img src={qrUrl} alt="QR de atendimento de Anna Souza" />} name="Anna Souza" />`
