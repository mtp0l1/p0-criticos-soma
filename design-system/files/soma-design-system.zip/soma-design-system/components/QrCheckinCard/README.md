Cartão do QR de atendimento: a pessoa mostra o QR no espaço para a equipe registrar a entrega. Substitui o cartão de membro da versão antiga.

**Você fornece:** o QR (`qr`, uma imagem ou elemento) e o nome (`name`). Opcional: `title`, `description` e `steps`.

- Cartão com padding de 24px. Título "Chegou? Mostre este QR no atendimento" em `screen-title`, o texto de apoio, o QR em quadro de **200px** (`size-qr`) com borda, raio `radius-large` e padding de 16px, e o nome em maiúsculas em `body-strong`.
- O cabeçalho da tela usa `Header variant="eyebrow"` com o nome do espaço ("VILA VERDE"). Lembre a pessoa de aumentar o brilho da tela (nota do Figma).
- Embaixo, três passos curtos: "Mostre o QR", "A equipe pesa seus recicláveis" e "Seus pontos aparecem aqui".
- Fundo de tela em `background-secondary` para o QR ter contraste. O QR não é uma imagem decorativa: dê `alt` com o nome da pessoa.

**Acessibilidade:** o QR leva `alt` "QR de atendimento de Anna Souza"; os passos são uma lista ordenada.

**Figma:** Entrega, Tela 11 (438:1973 e 443:13567).

**React:** `<Soma.QrCheckinCard qr={<img src={qrUrl} alt="QR de atendimento de Anna Souza" />} name="Anna Souza" />`

---
**Usar para:** Cartão do QR de atendimento: a pessoa mostra o QR no espaço para a equipe registrar a entrega.
**Nunca:** usar para outro código que não seja o QR de atendimento; o cartão de membro da versão antiga saiu.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
