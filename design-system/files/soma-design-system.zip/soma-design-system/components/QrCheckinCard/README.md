# QrCheckinCard

Cartão do QR de atendimento: a pessoa mostra o QR no espaço para a equipe registrar a entrega. Substitui o cartão de membro da versão antiga.

## O que você fornece

O QR (`qr`, uma imagem ou elemento) e o nome (`name`). Opcional: `title`, `description` e `steps`.

## Especificação

- Título e instrução; QR numa moldura branca sobre azul-marinho, com o nome; os três passos num cartão com números em círculo.

## Acessibilidade

O QR leva `alt` "QR de atendimento de Anna Souza"; os passos são uma lista ordenada.

## Nas telas da v2

Entrega: [QR no atendimento](prototipo/#842-10156).

## Código

```
<Soma.QrCheckinCard qr={<img src={qrUrl} alt="QR de atendimento de Anna Souza" />} name="Anna Souza" />
```

---
**Usar para:** Cartão do QR de atendimento: a pessoa mostra o QR no espaço para a equipe registrar a entrega.
**Nunca:** usar para outro código que não seja o QR de atendimento; o cartão de membro da versão antiga saiu.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
