Botões relacionados colados lado a lado, com uma borda só entre eles (shadcn ButtonGroup).

**Você fornece:** os botões (de preferência `quiet`) e um `aria-label` para o grupo.

- Os cantos internos perdem o raio e as bordas se sobrepõem; o botão em foco sobe para o anel aparecer inteiro.
- `orientation="vertical"` empilha. Use para ações do mesmo assunto (diminuir, quantidade, aumentar), nunca para juntar o `loud` da tela com outra ação.
- Escolha entre opções é `ToggleGroup`, `SegmentedControl` ou `ChoiceChips`, não ButtonGroup.

**Acessibilidade:** `role="group"` com nome; cada botão continua com 44px e seu próprio rótulo.

**Base técnica:** `div` com `buttonGroupVariants` (CVA); sem Radix, porque não há estado.

**React:** `<Soma.ButtonGroup aria-label="Quantidade"><Soma.IconButton hierarchy="quiet" icon="minus" label="Diminuir" />…</Soma.ButtonGroup>`
