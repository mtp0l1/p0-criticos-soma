Estado que toma o lugar do campo de doação quando a pessoa não pode doar ainda.

**Você fornece:** título, descrição e, para pontos insuficientes, `progress={{ points: 150, goal: 500 }}`. Opcional: `art`.

- Cartão `surface-card` com borda, raio `radius-xlarge`, padding de 32px em cima e embaixo e 16px dos lados, tudo centralizado. Arte de 80px (padrão: `doar-saldo-insuficiente`, reciclagem em círculo cinza), título em `subtitle` semibold e descrição em `body-small` `text-secondary`.
- **Saldo zero:** "Você ainda não tem pontos". A saída é "Fazer minha primeira entrega".
- **Pontos insuficientes:** "Pontos insuficientes", com a barra de 8px e "150 / 500 pontos" à direita. A saída é "Fazer uma entrega". O número vem do `goal` da instituição.
- O botão fica **fora** do cartão, na tela, a 24px dele.

**Acessibilidade:** `section` com o título como nome; a barra é `progressbar` com o texto "Pontos para doar a esta instituição".

**Figma:** Doar pontos, saldo zero (463:4412) e pontos insuficientes (463:4246).

**React:** `<Soma.DonationStateCard title="Pontos insuficientes" description="Faltam 350 pontos para doar para esta instituição." progress={{ points: 150, goal: 500 }} />`