# DonationStateCard

Estado que toma o lugar do valor da doação quando a pessoa ainda não pode doar.

## O que você fornece

`title`, `description` e, para pontos insuficientes, `progress` (pontos que tem e mínimo da instituição).

## Especificação

- Sem cartão: o conteúdo fica centralizado sobre o fundo da tela.
- Saldo zero: círculo pêssego de 112px com o ícone `refresh`.
- Pontos insuficientes: anel de 136px com o saldo no centro ("320 de 500 pontos"). O texto diz quanto falta.

## Acessibilidade

O anel é um `progressbar` com o texto "320 de 500 pontos".

## Nas telas da v2

Doar pontos: [Saldo zero](prototipo/#832-6626) e [Saldo insuficiente](prototipo/#832-6460).

## Código

```
<Soma.DonationStateCard title="Pontos insuficientes" description="Faltam 180 pontos para doar para esta instituição." progress={{ points: 320, goal: 500 }} />
```

---
**Usar para:** Estado que toma o lugar do campo de doação quando a pessoa não pode doar ainda.
**Nunca:** aparecer junto do campo de doação.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
