Título de bloco dentro da tela, com um link opcional à direita.

**Você fornece:** o título e, se quiser, `action` com rótulo e `onClick`. Para categorias do catálogo: `size="small"` e `icon`. Para rótulos de bloco em maiúsculas: `size="eyebrow"`.

- `default`: título em `subtitle` (16px medium). **Sem link, a altura é a do texto (24px)**, como no Início; com link, o botão `transparent` ("Ver mapa", "Ver mais") dá a altura mínima de 44px.
- `size="small"` + `icon`: ícone de 16px, título em `label` bold e link em `caption` bold `text-link` ("Ver todas (12)"). Usado nas categorias do catálogo (Alimentação e gastronomia, Casa, Educação).
- `size="eyebrow"`: `eyebrow` (12px bold, maiúsculas, espaçamento de letras) em `text-primary`, 24px de altura, **sem link**. "PRÓXIMAS ENTREGAS", "ESCOLHA O ESPAÇO", "ATIVIDADE RECENTE".
- Entre o título e o conteúdo, `space-nano` (8px); entre blocos, `space-small` (24px).
- Use um por bloco. O link leva à versão completa do mesmo conteúdo.

**Acessibilidade:** o título é um `h2`. Se vários links dizem "Ver todas", acrescente a categoria ao nome acessível.

**React:** `<Soma.SectionHeader title="Espaços de recebimento perto de você" action={{ label: 'Ver mapa', onClick: abrirMapa }} />` · `<Soma.SectionHeader size="small" icon="utensils" title="Alimentação e gastronomia" action={{ label: 'Ver todas (12)' }} />`

---
**Usar para:** Título de bloco dentro da tela, com um link opcional à direita.
**Nunca:** usar como título de tela (use `Header`) nem com mais de um link à direita.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
