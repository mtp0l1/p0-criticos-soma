Título de bloco dentro da tela, com um link opcional à direita.

**Você fornece:** o título e, se quiser, `action` com rótulo e `onClick`. Para categorias do catálogo: `size="small"` e `icon`.

- `default`: título em `subtitle`; o link é um botão `transparent` ("Ver mapa", "Ver mais"). Altura mínima de 44px.
- `size="small"` + `icon`: ícone de 16px, título em `label` bold e link em `caption` bold `text-link` ("Ver todas (12)"). Usado nas categorias do catálogo (Alimentação e gastronomia, Casa, Educação).
- Use um por bloco. O link leva à versão completa do mesmo conteúdo.

**Acessibilidade:** o título é um `h2`. Se vários links dizem "Ver todas", acrescente a categoria ao nome acessível.

**React:** `<Soma.SectionHeader title="Espaços de recebimento perto de você" action={{ label: 'Ver mapa', onClick: abrirMapa }} />` · `<Soma.SectionHeader size="small" icon="utensils" title="Alimentação e gastronomia" action={{ label: 'Ver todas (12)' }} />`
