Título de bloco dentro da tela, com um link opcional à direita.

**Você fornece:** o título e, se houver, o rótulo e o destino do link.

- `version="atual"` (padrão): `subtitle` (Lexend Medium 16/24, o "Subtitle/X-Small" do Figma). Ex.: "Sua próxima entrega", "O que posso reciclar".
- `version="anterior"`: `section-title` (18/24, 600), da Home em produção ("Ganhe suas medalhas").
- Link como `Button` `transparent` em `text-link` ("Ver mais", "Ver mapa").
- Espaço `space-nano` entre o título e o conteúdo do bloco, `space-small` (24px) entre blocos.
- Títulos dizem o que o bloco faz, sem dois-pontos.

**Acessibilidade:** o título é `h2`.

**React:** `<Soma.SectionHeader title="Espaços de recebimento perto de você" action={{ label: 'Ver mapa', onClick: abrir }} />`
