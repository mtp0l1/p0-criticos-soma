Título de bloco dentro da tela, com um link opcional à direita.

**Você fornece:** o título e, se houver, o rótulo e o destino do link.

- Estilo `subtitle` (Lexend Medium 16/24). Ex.: "Sua próxima entrega", "O que posso reciclar", "Atividade recente".
- Link como `Button` `transparent` em `text-link` ("Ver mais", "Ver mapa").
- Espaço `space-nano` entre o título e o conteúdo, `space-small` (24px) entre blocos.
- Títulos dizem o que o bloco faz, sem dois-pontos. O título de 18/24 da Home antiga (`section-title`) não é usado nas telas novas.

**Acessibilidade:** o título é `h2`.

**React:** `<Soma.SectionHeader title="Espaços de recebimento perto de você" action={{ label: 'Ver mapa', onClick: abrir }} />`
