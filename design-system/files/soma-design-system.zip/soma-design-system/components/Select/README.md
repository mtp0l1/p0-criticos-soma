Lista suspensa de escolha única, sobre Radix Select (shadcn Select). Para estado, cidade e listas longas no cadastro.

**Você fornece:** o rótulo, o placeholder e os itens.

- Gatilho igual ao `Input` (56px, borda `input`) com seta `icon-brand-strong`. Lista em `popover` com borda, `shadow-high` e itens de 44px; o marcado leva check e negrito, o destacado ganha `accent`.
- Até 5 opções curtas, prefira `RadioList` ou `ChoiceChips`: ficam visíveis sem tocar.
- Item indisponível vai desabilitado e diz por quê ("Rio de Janeiro (em breve)").
- Aberto, o gatilho fica com a borda `border-highlight`. A lista anima na entrada e na saída. Em lista simples no celular, prefira `NativeSelect`; em lista longa, `Combobox`.

**Acessibilidade:** setas, digitação para buscar, Enter seleciona, Esc fecha; ligue o rótulo com `aria-labelledby` ou `aria-label` no gatilho.

**React:** `<Soma.Select value={uf} onValueChange={setUf}><Soma.SelectTrigger aria-label="Estado"><Soma.SelectValue placeholder="Selecione o estado" /></Soma.SelectTrigger><Soma.SelectContent><Soma.SelectItem value="pr">Paraná</Soma.SelectItem></Soma.SelectContent></Soma.Select>`
