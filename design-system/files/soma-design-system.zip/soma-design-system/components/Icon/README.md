Ícones de linha do Lucide, o mesmo set das telas novas no Figma, com nomes So+ma. Quatro tamanhos, sete papéis de cor. Inclui o `IconButton`.

**Você fornece:** o nome (`name`), o tamanho (`size`), o papel da cor (`tone`) e, quando o ícone carrega sentido sozinho, um `label`.

- Traço de 2px, como no Figma. `size`: `small` 16px (chip, linha de status, botão compacto), `medium` 24px (padrão), `large` 32px, `xlarge` 56px (estado vazio, tela de resultado).
- `tone`: `brand` ao lado de rótulo, `brand-strong` sozinho, `primary` no Menu e na barra inferior, `secondary` inativo, `positive`, `negative` e `info` em status.
- Os ícones "SVG fornecido" do Figma são Lucide: **Reciclar** = `recycle`, **Meu impacto** = `chart` (chart-column), **Pino** = `pin` (map-pin), **Recompensas** ("Icon") = `gift`. Não há desenho próprio para exportar.
- O nome que está na camada do Figma também funciona (`help-circle`, `map-pin`, `clock-3`, `fork-knife`, `bottle-wine`, `x`…): veja `ICON_ALIASES`.
- `heart` agora é o coração do Lucide (categoria Saúde). A mão com coração da doação é `hand-heart`.
- Pacote: `lucide-react@0.544.0` (é a primeira versão com `bottle-wine`).

| Grupo | Nomes |
|---|---|
| Navegação | `home` `recycle` `gift` `chart` `menu` `bag-check` `chevron-left/right/down/up` `arrow-left` `arrow-up` `arrow-left-right` `navigation` |
| Ações | `help` `info` `search` `close` `check` `plus` `minus` `trash` `share` `copy` `link` `user-plus` `contacts` `logout` `settings` |
| Conta e contato | `user` `users` `card` `lock` `bell` `mail` `mail-open` `phone` `message` `message-circle` `headphones` `globe` |
| Entrega e tempo | `pin` `crosshair` `calendar` `calendar-check` `clock` `history` `qr-code` `store` `camera` |
| Gamificação | `star` `medal` `award` `trophy` `flame` `shield` `shield-check` `target` `sparkles` `trending-up` `lightbulb` |
| Recompensas | `coin` `ticket` `cart` `shopping-bag` `utensils` `book` `heart` `hand-heart` `leaf` `sport` |
| Materiais e impacto | `bottle` `wine` `package` `doc` `drop` `bolt` `scale` `tree` |
| Estado | `alert` `circle-check` `circle-x` `ban` |

| Camada no Figma | Nome no sistema |
|---|---|
| home / house | `home` |
| Reciclar — SVG fornecido | `recycle` |
| Icon (Recompensas, presente) | `gift` |
| Meu impacto — SVG fornecido | `chart` |
| Pino — SVG fornecido / map-pin | `pin` |
| help-circle · x · clock-3 · droplet · file-text · zap · share-2 | `help` · `close` · `clock` · `drop` · `doc` · `bolt` · `share` |
| fork-knife · shopping-cart · bottle-wine · check-circle | `utensils` · `cart` · `bottle` · `circle-check` |
| Shopping, Ecommerce/Qr code | `qr-code` |
| Social,Medias,Rewards/Medal | `medal` |
| soccer-ball | `sport` (bola do Lucide; o Lucide não tem bola de futebol) |
| envelope-open-heart | `mail-open` |

**Acessibilidade:** sem `label` o ícone é `aria-hidden`. Ícone sozinho que comunica estado precisa de 3:1: use `brand-strong`, não `brand`.

**React:** `<Soma.Icon name="recycle" tone="brand-strong" />` · `<Soma.Icon name="map-pin" />` (apelido) · `<Soma.IconButton icon="help" label="Ajuda" />`

---
**Usar para:** Ícones de linha do Lucide, o mesmo set das telas novas no Figma, com nomes So+ma.
**Nunca:** importar ícone de fora do set Lucide do sistema.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
