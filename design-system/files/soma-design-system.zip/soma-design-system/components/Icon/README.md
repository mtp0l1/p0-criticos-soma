Ícones de linha: o set Lucide (SVG, o mesmo das telas novas no Figma, com nomes do Campana) e um set vetorial de 151 ícones extras (SVG em `assets/icons`). Quatro tamanhos, sete papéis de cor. Inclui o `IconButton`.

**Você fornece:** o nome (`name`), o tamanho (`size`), o papel da cor (`tone`) e, quando o ícone carrega sentido sozinho, um `label`. Para um caso fora da escala, `size` aceita um número em px e `color` aceita uma cor CSS (`var(--token)`); prefira `size` e `tone` por papel.

- Traço de 2px, como no Figma. `size`: `small` 16px (chip, linha de status, botão compacto), `medium` 24px (padrão), `large` 32px, `xlarge` 56px (estado vazio, tela de resultado).
- `tone`: `brand` ao lado de rótulo, `brand-strong` sozinho, `primary` no Menu e na barra inferior, `secondary` inativo, `positive`, `negative` e `info` em status.
- Os ícones "SVG fornecido" do Figma são Lucide: **Reciclar** = `recycle`, **Meu impacto** = `chart` (chart-column), **Pino** = `pin` (map-pin), **Recompensas** ("Icon") = `gift`. Não há desenho próprio para exportar.
- O nome que está na camada do Figma também funciona (`help-circle`, `map-pin`, `clock-3`, `fork-knife`, `bottle-wine`, `x`…): veja `ICON_ALIASES`.
- `heart` agora é o coração do Lucide (categoria Saúde). A mão com coração da doação é `hand-heart`.
- Pacote: `lucide-react@0.544.0` (é a primeira versão com `bottle-wine`).

| Grupo | Nomes |
|---|---|
| Navegação | `home` `recycle` `gift` `chart` `menu` `bag-check` `chevron-left/right/down/up` `arrow-left` `arrow-up` `arrow-left-right` `navigation` |
| Ações | `help` `info` `search` `close` `check` `plus` `minus` `trash` `share` `copy` `link` `user-plus` `contacts` `logout` `settings` |
| Conta e contato | `user` `users` `card` `lock` `bell` `mail` `mail-open` `phone` `message` `message-circle` `headphones` `globe` |
| Entrega e tempo | `pin` `crosshair` `calendar` `calendar-check` `clock` `history` `qr-code` `store` `camera` |
| Gamificação | `star` `medal` `award` `trophy` `flame` `shield` `shield-check` `target` `sparkles` `trending-up` `lightbulb` |
| Recompensas | `coin` `ticket` `cart` `shopping-bag` `utensils` `book` `heart` `hand-heart` `leaf` `sport` |
| Materiais e impacto | `bottle` `wine` `package` `doc` `drop` `bolt` `scale` `tree` |
| Estado | `alert` `circle-check` `circle-x` `ban` |

| Camada no Figma | Nome no sistema |
|---|---|
| home / house | `home` |
| Reciclar — SVG fornecido | `recycle` |
| Icon (Recompensas, presente) | `gift` |
| Meu impacto — SVG fornecido | `chart` |
| Pino — SVG fornecido / map-pin | `pin` |
| help-circle · x · clock-3 · droplet · file-text · zap · share-2 | `help` · `close` · `clock` · `drop` · `doc` · `bolt` · `share` |
| fork-knife · shopping-cart · bottle-wine · check-circle | `utensils` · `cart` · `bottle` · `circle-check` |
| Shopping, Ecommerce/Qr code | `qr-code` |
| Social,Medias,Rewards/Medal | `medal` |
| soccer-ball | `sport` (bola do Lucide; o Lucide não tem bola de futebol) |
| envelope-open-heart | `mail-open` |

**Set vetorial (SVG).** 151 ícones extras em 10 grupos, vetorizados de sprite sheets por `extrair_icones.py` e listados em `assets/icons/manifest.json`. Cada um é um `<svg viewBox="0 0 24 24">` inline com `currentColor`, então `size`, `tone` e `color` funcionam como no Lucide, em qualquer escala.
- `name` procura primeiro o Lucide, depois o set vetorial. Nomes que existem nos dois (`VECTOR_SHADOWED`: building, camera, droplet, gift, globe, headphones, house, link, lock, qr-code, scale, search, shield, shield-check, shopping-bag, shopping-cart, target, trophy, wine) ficam com o Lucide; para o vetorial passe `source="vector"`.
- Traço: **todos os 151 têm exatamente 2 unidades na grade de 24**, a mesma do Lucide (`strokeWidth={2}`), com ponta redonda; não existe ícone de traço mais fino. Os sprite sheets de origem tinham 209 desenhos: 58 foram descartados (detalhe demais para 2px, listados em `discarded` no `manifest.json`) e 16 foram simplificados à mão-de-regra (campo `mode: "simplificado"`: some hachura e nó complexo, fica a forma). O ícone é um contorno preenchido, não uma linha: a prop `strokeWidth` não existe nele e o peso cresce proporcionalmente nas outras escalas. Prefira 24px ou mais.
- **Carregamento sob demanda.** Os paths não entram no bundle inicial (`bundle.js` ficou ~0,8 MB em vez de ~1,3 MB). Cada grupo é um arquivo ESM em `icons-chunks/<grupo>.js`, ao lado do `bundle.js`, baixado na primeira vez que um ícone dele é renderizado; até chegar, o `<svg>` ocupa o espaço certo, vazio. Para evitar o piscar numa rota que já sabe o que vai usar: `Soma.loadVectorIcons('natureza-clima-e-impacto')`, `Soma.loadVectorIcons(['atom', 'flask'])` (nomes de ícone também valem) ou sem argumento para baixar tudo. Se o app servir o bundle em outra pasta, leve `icons-chunks/` junto. Grupos: `VECTOR_ICON_GROUPS`; grupo de cada ícone: `VECTOR_ICON_GROUP[name]`.
- Mudança: `VECTOR_ICON_PATHS` deixou de existir (os paths agora são lazy); use `isVectorIcon(name)` e `VECTOR_ICON_NAMES`.
- Ícones densos (alvo, moto, bússola, janela, quebra-cabeça) perdem detalhe interno em `small` (16px): prefira `medium` ou maior. Em `xlarge` o contorno mostra a irregularidade leve do desenho original (o traço é de mão, não de régua).
- Para adicionar ícones: rode `extrair_icones.py` de novo (ele regrava os SVGs, o `manifest.json`, o `icons.ts` e `vector/<grupo>.ts`) e refaça o build. Nenhum outro arquivo muda.
- Sem `label` o ícone é decorativo (`aria-hidden`), igual ao Lucide.

**React:** `<Soma.Icon name="paperclip" />` · `<Soma.Icon name="car" size="large" tone="brand-strong" />` · `<Soma.Icon name="trophy" source="vector" />` · `<Soma.Icon name="bike" size={40} color="var(--ds-color-fg-default)" />`

**Acessibilidade:** sem `label` o ícone é `aria-hidden`. Ícone sozinho que comunica estado precisa de 3:1: use `brand-strong`, não `brand`.

**React:** `<Soma.Icon name="recycle" tone="brand-strong" />` · `<Soma.Icon name="map-pin" />` (apelido) · `<Soma.IconButton icon="help" label="Ajuda" />`

---
**Usar para:** Ícones de linha do sistema: Lucide e o set vetorial (SVG), com tamanho e cor por papel.
**Nunca:** importar ícone de fora dos dois sets do sistema (Lucide e assets/icons) ou usar PNG/máscara para ícone de linha.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
