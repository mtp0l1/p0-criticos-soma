# DeliverySummaryCard

Resumo do agendamento: quando, onde e a que horas a pessoa entrega. É o mesmo card na confirmação, em Meus agendamentos e depois de salvar no calendário.

## O que você fornece

A data por extenso (`date`, "Segunda, 7 de setembro"), o nome do espaço (`space`), o endereço com a distância (`address`), o horário (`time`, "09h") e `onDirections`. Opcionais: `openHours` ("8h às 18h") e `notice` ("1 hora antes").

## Especificação

- Cartão em formato de ingresso: dia e mês num bloco pêssego, "Quando" com o dia da semana e o horário numa pílula escura.
- Abaixo da linha tracejada, uma linha por informação, cada uma com ícone: espaço (com "Como chegar" à direita), "Horário de recebimento" e "Aviso".
- Se a data não vier no formato "Dia da semana, N de mês", ela aparece por extenso, sem o bloco.

## Acessibilidade

`section` com o nome "Resumo da entrega"; "Como chegar" diz o espaço ao leitor de tela e tem área de toque de 44px.

## Nas telas da v2

Ativação: [Entrega marcada](prototipo/#842-9599), [Entrega marcada · calendário ok](prototipo/#842-9771), [Erro ao adicionar ao calendário](prototipo/#842-9867) e [Meus agendamentos](prototipo/#842-9688).

## Código

```
<Soma.DeliverySummaryCard date="Segunda, 7 de setembro" space="Vila Verde" address="Rua das Flores, 120 · 800 m" time="09h" openHours="8h às 18h" onDirections={abrirMapa} />
```

---
**Usar para:** Resumo do agendamento: quando, onde e a que horas a pessoa entrega.
**Nunca:** mudar de forma entre confirmação, agendamentos e calendário: é o mesmo card.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
