Resumo do agendamento: quando, onde e a que horas a pessoa entrega. É o mesmo card na confirmação, em Meus agendamentos e depois de salvar no calendário.

**Você fornece:** a data já escrita (`date`, "Segunda, 7 de setembro"), o nome do espaço (`space`), o endereço com a distância (`address`), o horário (`time`, "09h") e `onDirections` para o link "Como chegar". Opcional: `notice` ("1 hora antes").

- Card `surface-card` com borda `border-primary`, raio `radius-large`, padding 16px. Linhas "Quando", "Onde" e "Horário": o rótulo à esquerda em `caption` bold `text-secondary`, o valor à direita em `label`, alinhado à direita. Divisor de 1px depois de "Quando".
- "Onde" tem o nome do espaço, o endereço em `caption` e o link "Como chegar" com `pin` em `text-link`.
- `notice` acrescenta a linha "Aviso" depois de um segundo divisor. Só aparece depois que a pessoa salva no calendário (Tela 28).
- Em Meus agendamentos o card vem sob "PRÓXIMAS ENTREGAS", com o botão "Adicionar ao calendário" (`quiet`) logo abaixo.

**Acessibilidade:** `section` com o nome "Resumo da entrega"; "Como chegar" diz o espaço ao leitor de tela e tem área de toque de 44px.

**Figma:** Telas 6 (443:13010), 28 (443:13198), 29 (443:13289) e 7 (443:13091).

**React:** `<Soma.DeliverySummaryCard date="Segunda, 7 de setembro" space="Vila Verde" address="Rua das Flores, 120 · 800 m" time="09h" onDirections={abrirMapa} />`