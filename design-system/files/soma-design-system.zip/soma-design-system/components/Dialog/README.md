As primitivas do Radix Dialog no estilo So+ma (shadcn Dialog), para montar um diálogo fora do padrão do `Modal`.

**Você fornece:** a composição: `Dialog` › `DialogTrigger` › `DialogContent` › `DialogHeader` (`DialogTitle`, `DialogDescription`) › conteúdo › `DialogFooter`.

- Use `Modal` sempre que couber (título, texto ou escolha e uma ação). Use as primitivas quando precisar de mais de uma ação ou de conteúdo próprio.
- Contêiner `popover`, raio `radius-large`, largura até 340px, sobre `overlay`. X de 44px no canto (`showClose={false}` para esconder).
- `DialogFooter` empilha ações em largura total, a principal em cima.
- Conteúdo maior que a tela rola dentro do diálogo (altura máxima de 100% menos 48px). Entrada e saída animadas.

**Acessibilidade:** foco preso no diálogo, Esc e toque fora fecham, foco volta ao gatilho, título e descrição ligados por `aria-labelledby`/`aria-describedby`.

**React:** `<Soma.Dialog><Soma.DialogTrigger asChild><Soma.Button>Abrir</Soma.Button></Soma.DialogTrigger><Soma.DialogContent>…</Soma.DialogContent></Soma.Dialog>`

---
**Usar para:** As primitivas do Radix Dialog no estilo So+ma (shadcn Dialog), para montar um diálogo fora do padrão do `Modal`.
**Nunca:** usar quando o `Modal` serve; é só para diálogo fora do padrão.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
