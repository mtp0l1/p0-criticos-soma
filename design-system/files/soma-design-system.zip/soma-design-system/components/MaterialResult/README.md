Resultado da busca de material: foto, nome, se é aceito no local, se é reciclável e a categoria.

**Você fornece:** o nome, a foto, `accepted`, `recyclable` e a categoria.

- Foto em `Thumb` quadrado. Nome em `label`. Linhas de status com ícone de 16px: sim em `feedback-text-positive` com check, não em `feedback-text-negative` com ×. Categoria em `Tag`.
- Mostre só resultados do termo buscado e ordene pelo nome mais próximo. "Leite" não deve trazer "Plástico duro" no topo.
- Acima da lista, "Foram encontrados N resultados para "termo"" em `caption`.

**React:** `<Soma.MaterialResult name="Cartonado" accepted recyclable category="Cartonado" />`

---
**Usar para:** Resultado da busca de material: foto, nome, se é aceito no local, se é reciclável e a categoria.
**Nunca:** omitir se o material é aceito no local ou se é reciclável.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
