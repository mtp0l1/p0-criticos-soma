# ImpactTiles

Três números do impacto da entrega: quilos, pontos ganhos e água economizada. Aparece na tela "Entrega registrada".

## O que você fornece

Os itens (`items`: valor e legenda, com `highlight` no que merece destaque), o título (`title`) e `onShare` para mostrar o botão "Compartilhar".

## Especificação

- Cartão azul-marinho com o título, "Compartilhar" no canto e até três números na cor primária.

## Acessibilidade

Cada bloco é lido como "3,2 kg, PET reciclado"; o destaque é só visual, o texto não depende dele.

## Nas telas da v2

Ativação: [Entrega registrada](prototipo/#842-10230). "Compartilhar" abre o `ShareImpactModal` ([Compartilhar impacto](prototipo/#842-10693)).

## Código

```
<Soma.ImpactTiles title="Seu impacto nesta entrega" items={[{ value: '3,2 kg', label: 'PET reciclado' }, { value: '+64', label: 'pontos ganhos', highlight: true }, { value: '12 L', label: 'de água economizada' }]} onShare={compartilhar} />
```

---
**Usar para:** Três números do impacto da entrega: quilos, pontos ganhos e água economizada.
**Nunca:** passar de três números.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
