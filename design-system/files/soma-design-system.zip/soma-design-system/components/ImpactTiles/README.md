Três números do impacto da entrega: quilos, pontos ganhos e água economizada. Aparece na tela "Entrega registrada".

**Você fornece:** os itens (`items`: valor e legenda, com `highlight` no que merece destaque), o título (`title`) e `onShare` para mostrar o botão "Compartilhar".

- Cada bloco é um card com valor em `balance-number` e legenda em `caption`. O destacado leva borda `border-highlight` e valor em `text-link`.
- O botão Compartilhar fica ao lado do título.
- Os três blocos formam uma grade de três colunas; se o texto não couber, quebra a legenda e nunca corta o número.

**Acessibilidade:** cada bloco é lido como "3,2 kg, PET reciclado"; o destaque é só visual, o texto não depende dele.

**Figma:** "Entrega registrada", Tela 12 (438:1973).

**React:** `<Soma.ImpactTiles title="Seu impacto nesta entrega" items={[{ value: '3,2 kg', label: 'PET reciclado' }, { value: '+64', label: 'pontos ganhos', highlight: true }, { value: '12 L', label: 'de água economizada' }]} onShare={compartilhar} />`
