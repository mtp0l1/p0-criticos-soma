Estado do Quiz depois de responder (Tela 3): "Tarefa cumprida!" e o tempo até a próxima pergunta.

**Você fornece:** nada é obrigatório; `title`, o texto (`children`) e `countdown` ("14h 15m") são opcionais.

- Card `surface-primary` com borda `border` e raio `radius-large`: check verde num círculo de 48px, título em 16px 700, o texto "Você já respondeu hoje! Volte amanhã para continuar." em 13px e a pílula "Próxima pergunta em 14h 15m" em `surface-secondary`.
- Fica no lugar do `QuestionCard`, abaixo do `StreakSection` (com hoje já feito, com anel).

**Acessibilidade:** o card é `role="status"`, então a mudança é anunciada sem tirar o foco; o check é decorativo.

**Figma:** Quiz, Tela 3 (443:15595).

**React:** `<Soma.DailyDone countdown="14h 15m" />`
