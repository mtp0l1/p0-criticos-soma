Estado do Quiz depois de responder: "Tarefa cumprida!" e a contagem até a próxima pergunta.

**Você fornece:** nada é obrigatório; `title`, o texto (`children`) e `countdown` ("Nova pergunta em 14h 20min") são opcionais.

- Card com check em `feedback-fill-positive`, título "Tarefa cumprida!" e o texto de apoio. A contagem vai numa pílula com relógio em `surface-secondary`.
- Fica no lugar do `QuestionCard`. Mostra a `StreakTrail` com hoje já feito.

**Acessibilidade:** o card é `role="status"`, então a mudança é anunciada sem tirar o foco; o check é decorativo.

**Figma:** Quiz, Tela 3 (443:15190).

**React:** `<Soma.DailyDone countdown="Nova pergunta em 14h 20min" />`
