# DailyDone

Estado do Quiz depois de responder (Tela 3): "Tarefa cumprida!" e o tempo até a próxima pergunta.

## O que você fornece

Nada é obrigatório; `title`, o texto (`children`) e `countdown` ("14h 15m") são opcionais.

## Especificação

- Card `surface-primary` com borda `border` e raio `radius-large`: check verde num círculo de 48px, título em 16px 700, o texto "Você já respondeu hoje! Volte amanhã para continuar." em 13px e a pílula "Próxima pergunta em 14h 15m" em `surface-secondary`.
- Fica no lugar do `QuestionCard`, abaixo do `StreakSection` (com hoje já feito, com anel).

## Acessibilidade

O card é `role="status"`, então a mudança é anunciada sem tirar o foco; o check é decorativo.

## Nas telas da v2

Quiz: [Já respondeu hoje](prototipo/#849-9175).

## Código

```
<Soma.DailyDone countdown="14h 15m" />
```

---
**Usar para:** Estado do Quiz depois de responder (Tela 3): "Tarefa cumprida!" e o tempo até a próxima pergunta.
**Nunca:** tirar o contador de tempo até a próxima pergunta.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
