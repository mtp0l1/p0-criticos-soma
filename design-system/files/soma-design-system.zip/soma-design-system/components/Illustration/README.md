Mostra uma das ilustrações do sistema pelo nome, no tamanho do Figma ou em outro.

**Você fornece:** o nome (`name`). Opcional: `size` (lado maior em px), `alt` (vazio por padrão, porque a ilustração é decorativa) e `className`.

- Nomes: `trofeu-bronze-96`, `trofeu-bronze-120`, `trofeu-prata-96`, `trofeu-ouro-96`, `conquista-bronze-148`, `mascote-lata-acerto`, `mascote-lata-erro`, `convite-pontos`, `ranking-vazio`, `doar-sucesso` e `doar-saldo-insuficiente`. O objeto `ILLUSTRATIONS` traz título, tamanho original, nó do Figma e onde cada uma é usada.
- As imagens estão embutidas no bundle (data URI). Os arquivos PNG ficam em `assets/illustrations/`, junto com `confete-entrega`, `instituicao-logo` e `instituicao-banner`, que não são embutidos.
- `Trophy`, `AnswerResult` e `MilestoneResult` já usam as ilustrações certas sozinhos. Use `Illustration` para o resto: `EmptyState` (`artFrame={false}`), `ResultScreen` e a tela de convite.
- Catálogo completo, com nós do Figma e regras de uso: `6-ilustracoes.md` e a página "Ilustrações" do site.

**Acessibilidade:** deixe `alt` vazio quando a tela já diz o que a ilustração mostra; descreva só se ela carregar informação.

**React:** `<Soma.Illustration name="mascote-lata-acerto" />` · `<Soma.Illustration name="ranking-vazio" size={240} />`
