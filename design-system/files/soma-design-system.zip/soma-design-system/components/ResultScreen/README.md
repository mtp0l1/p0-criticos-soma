Tela de resultado ou pedido: sucesso, erro ou permissão (contatos, notificação). Fecha um fluxo.

**Você fornece:** o tom, o título, a descrição, as ações e, ao fim de um fluxo, `onHome`. Opcional: `ringSize`, `actionsPlacement`.

- Ícone em círculo a `space-large` (40px) do cabeçalho. `ringSize`: `lg` 96px (padrão), `md` 88px (permissão de contatos), `sm` 72px ("Pedido enviado!"). `positive`: check verde. `negative`: ×. `neutral`: ícone livre (ex.: `contacts`).
- Título em `page-title`, descrição em `body` `text-secondary`, centralizados.
- `actionsPlacement="bottom"` (padrão) prende as ações no fim da tela; `"inline"` deixa as ações logo abaixo do texto, com o conteúdo no topo (Telas 12, 14 e 16).
- Ações: `loud` em cima; `secondaryAction` é `quiet` ou, com `hierarchy: 'transparent'`, um link em texto ("Agora não", "Voltar ao ranking"). Fim de fluxo sempre tem "Ir para o início" (`transparent`).
- `art` substitui o ícone (selo do nível, ilustração). `children` entra entre o texto e as ações (resumo, `RedeemCode`).

**Acessibilidade:** `section` com o título como nome; o título é o `h1`.

**Figma:** Ranking, Tela 12 "Pedido enviado" (443:18827), Tela 14 "Permissão de contatos" (581:2919) e Tela 16 "Permissão negada" (600:2931); sucessos de Doar, Recompensas e Ativação.

**React:** `<Soma.ResultScreen ringSize="sm" actionsPlacement="inline" title="Pedido enviado!" description="Quando Ana aceitar, vocês aparecem no ranking um do outro." primaryAction={{ label: 'Voltar ao ranking' }} />`
