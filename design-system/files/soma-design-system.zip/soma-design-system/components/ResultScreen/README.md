# ResultScreen

Tela de resultado ou pedido: sucesso, erro ou permissão (contatos, notificação). Fecha um fluxo.

## O que você fornece

O tom, o título, a descrição, as ações e, ao fim de um fluxo, `onHome`. Opcional: `ringSize`, `actionsPlacement`, `iconShape`, `titleSize`, `ringOutline`, `extraLink`.

## Especificação

- Ícone em círculo a `space-large` (40px) do cabeçalho. `ringSize`: `lg` 96px (padrão), `md` 88px (permissão de contatos), `sm` 72px ("Pedido enviado!"), `xs` 48px ("Doação realizada!", com o ícone `medium`). `positive`: check verde. `negative`: ×. `neutral`: ícone livre (ex.: `contacts`).
- `iconShape="square"`: caixa de 56px com raio `radius-large` e ícone de 32px, para confirmações menores (Sua primeira entrega está marcada). `ringOutline`: contorno de 3px `border-highlight` no círculo (Cadastro concluído, `tone="neutral"` com `check`).
- Título em `page-title` (24px); `titleSize="screen"` usa `screen-title` (20px). Descrição em `body` `text-secondary`, centralizados.
- `actionsPlacement="bottom"` (padrão) prende as ações no fim da tela; `"inline"` deixa as ações logo abaixo do texto, com o conteúdo no topo (Telas 12, 14 e 16).
- `primaryAction.done`: o botão fica cinza, com check e sem toque ("Adicionado ao calendário"). `extraLink` põe um segundo link em texto ao lado de "Ir para o início" ("Ver meus agendamentos").
- Ações: `loud` em cima; `secondaryAction` é `quiet` ou, com `hierarchy: 'transparent'`, um link em texto ("Agora não", "Voltar ao ranking"). Fim de fluxo sempre tem "Ir para o início" (`transparent`).
- `art` substitui o ícone (selo do nível, ilustração). `children` entra entre o texto e as ações (resumo, `RedeemCode`).

## Acessibilidade

`section` com o título como nome; o título é o `h1`.

## Nas telas da v2

Ranking: [Pedido enviado](prototipo/#859-9967), [Permissão de contatos](prototipo/#859-10915) e [Permissão negada](prototipo/#859-11110). Doar pontos: [Doação realizada](prototipo/#832-6949) (círculo `xs` neutro com check, ilustração `doar-sucesso` e "Ir para o início"; sem cabeçalho nem voltar, a saída é o botão ou a barra inferior). Ativação: [Cadastro concluído](prototipo/#842-9233), [Entrega marcada](prototipo/#842-9599), [Entrega marcada · calendário ok](prototipo/#842-9771) e [Erro ao adicionar ao calendário](prototipo/#842-9867) (erro do calendário).

## Código

```
<Soma.ResultScreen ringSize="sm" actionsPlacement="inline" title="Pedido enviado!" description="Quando Ana aceitar, vocês aparecem no ranking um do outro." primaryAction={{ label: 'Voltar ao ranking' }} />
```

---
**Usar para:** Tela de resultado ou pedido: sucesso, erro ou permissão (contatos, notificação).
**Nunca:** deixar o fluxo sem uma ação principal clara.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
