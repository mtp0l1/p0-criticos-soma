Tela de resultado ou pedido: sucesso, erro ou permissão (contatos, notificação). Fecha um fluxo.

**Você fornece:** o tom, o título, a descrição, as ações e, ao fim de um fluxo, `onHome`.

- Ícone em círculo de 96px a `space-large` (40px) do cabeçalho, como pede a página de espaçamento do Figma. `positive`: check verde. `negative`: ×. `neutral`: ícone livre (ex.: `contacts`).
- Título em `page-title`, descrição em `body` `text-secondary`, centralizados.
- Ações no fim: `loud` em cima, `quiet` embaixo, `space-nano` entre elas. Fim de fluxo sempre tem "Ir para o início" (`transparent`).
- `art` substitui o ícone (selo do nível, ilustração). `children` entra entre o texto e as ações (resumo, `RedeemCode`).

**Acessibilidade:** `section` com o título como nome; o título é o `h1`.

**Figma:** telas de sucesso de Doar, Recompensas e Ativação; Telas 14 a 16 do Ranking (permissão de contatos).

**React:** `<Soma.ResultScreen tone="positive" title="Doação feita!" description="…" primaryAction={{ label: 'Ver meu impacto' }} onHome={irParaInicio} />`
