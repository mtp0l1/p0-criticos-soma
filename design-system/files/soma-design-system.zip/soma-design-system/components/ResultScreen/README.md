Tela de resultado ou pedido: sucesso, erro ou permissão (contatos, notificação). Fecha um fluxo.

**Você fornece:** o tom, o título, a descrição, as ações e, ao fim de um fluxo, `onHome`. Opcional: `ringSize`, `actionsPlacement`, `iconShape`, `titleSize`, `ringOutline`, `extraLink`.

- Ícone em círculo a `space-large` (40px) do cabeçalho. `ringSize`: `lg` 96px (padrão), `md` 88px (permissão de contatos), `sm` 72px ("Pedido enviado!"). `positive`: check verde. `negative`: ×. `neutral`: ícone livre (ex.: `contacts`).
- `iconShape="square"`: caixa de 56px com raio `radius-large` e ícone de 32px, para confirmações menores (Sua primeira entrega está marcada). `ringOutline`: contorno de 3px `border-highlight` no círculo (Cadastro concluído, `tone="neutral"` com `check`).
- Título em `page-title` (24px); `titleSize="screen"` usa `screen-title` (20px). Descrição em `body` `text-secondary`, centralizados.
- `actionsPlacement="bottom"` (padrão) prende as ações no fim da tela; `"inline"` deixa as ações logo abaixo do texto, com o conteúdo no topo (Telas 12, 14 e 16).
- `primaryAction.done`: o botão fica cinza, com check e sem toque ("Adicionado ao calendário"). `extraLink` põe um segundo link em texto ao lado de "Ir para o início" ("Ver meus agendamentos").
- Ações: `loud` em cima; `secondaryAction` é `quiet` ou, com `hierarchy: 'transparent'`, um link em texto ("Agora não", "Voltar ao ranking"). Fim de fluxo sempre tem "Ir para o início" (`transparent`).
- `art` substitui o ícone (selo do nível, ilustração). `children` entra entre o texto e as ações (resumo, `RedeemCode`).

**Acessibilidade:** `section` com o título como nome; o título é o `h1`.

**Figma:** Ranking, Tela 12 "Pedido enviado" (443:18827), Tela 14 "Permissão de contatos" (581:2919) e Tela 16 "Permissão negada" (600:2931); sucessos de Doar, Recompensas e Ativação: Telas 24 (443:12660), 6 (443:13010), 28 (443:13198) e 29 (443:13289, erro do calendário).

**React:** `<Soma.ResultScreen ringSize="sm" actionsPlacement="inline" title="Pedido enviado!" description="Quando Ana aceitar, vocês aparecem no ranking um do outro." primaryAction={{ label: 'Voltar ao ranking' }} />`
