# InviteMessageExample

Simulação de conversa que mostra onde está o código dentro da mensagem de convite.

## O que você fornece

Nada é obrigatório. Opcional: `sender` (padrão "Ana") e `code` (padrão "REC7X4KP").

## Especificação

- Quadro de 160px de altura, `surface-secondary`, raio `radius-medium`. Nome de quem enviou em `caption`, balão branco com a mensagem ("Oi! Estou reciclando e ganhando pontos. Entra comigo usando meu código de convite: REC7X4KP"), código destacado em `surface-accent` e seta com o rótulo "Este é o código" em `text-link`.
- É uma **ilustração**: não é a mensagem real de convite. A mensagem de verdade vem do app de quem convidou.

## Acessibilidade

`role="img"` com a mensagem inteira no rótulo; a seta e o rótulo são decorativos.

## Nas telas da v2

Cadastro: [Onde encontro o código?](prototipo/#835-6621), na "Simulação de conversa".

## Código

```
<Soma.InviteMessageExample sender="Ana" code="REC7X4KP" />
```

---
**Usar para:** Simulação de conversa que mostra onde está o código dentro da mensagem de convite.
**Nunca:** usar como mensagem real de envio; é só uma simulação.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
