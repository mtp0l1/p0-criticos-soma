# InviteMessageExample

Simulação de conversa que mostra onde está o código dentro da mensagem de convite.

## O que você fornece

Nada é obrigatório. Opcional: `sender` (padrão "Ana") e `code` (padrão "REC7X4KP").

## Especificação

- Balão de conversa com o código destacado numa etiqueta e "Este é o código" logo abaixo.

## Acessibilidade

`role="img"` com a mensagem inteira no rótulo; a seta e o rótulo são decorativos.

## Nas telas da v2

Cadastro: [Onde encontro o código?](prototipo/#835-6621), na "Simulação de conversa".

## Código

```
<Soma.InviteMessageExample sender="Ana" code="REC7X4KP" />
```

---
**Usar para:** Simulação de conversa que mostra onde está o código dentro da mensagem de convite.
**Nunca:** usar como mensagem real de envio; é só uma simulação.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
