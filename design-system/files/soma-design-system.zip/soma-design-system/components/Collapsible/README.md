Um trecho que abre e fecha, com animação de altura (shadcn Collapsible, sobre Radix).

**Você fornece:** o gatilho (um `Button transparent` com seta) e o conteúdo.

- O rótulo do gatilho diz o que vai acontecer ("Mostrar", "Ocultar"); a seta acompanha.
- Um trecho só: Collapsible. Várias perguntas na mesma lista: `Accordion`.

**Acessibilidade:** o gatilho leva `aria-expanded` e `aria-controls`; com movimento reduzido abre sem animação.

**React:** `<Soma.Collapsible open={o} onOpenChange={setO}><Soma.CollapsibleTrigger asChild><Soma.Button hierarchy="transparent">Mostrar</Soma.Button></Soma.CollapsibleTrigger><Soma.CollapsibleContent>…</Soma.CollapsibleContent></Soma.Collapsible>`
