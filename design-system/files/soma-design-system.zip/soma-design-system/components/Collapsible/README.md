# Collapsible

Um trecho que abre e fecha, com animação de altura.

## O que você fornece

O gatilho (um `Button transparent` com seta) e o conteúdo.

## Especificação

- O rótulo do gatilho diz o que vai acontecer ("Mostrar", "Ocultar"); a seta acompanha.
- Um trecho só: Collapsible. Várias perguntas na mesma lista: `Accordion`.

## Acessibilidade

O gatilho leva `aria-expanded` e `aria-controls`; com movimento reduzido abre sem animação.

## Código

```
<Soma.Collapsible open={o} onOpenChange={setO}><Soma.CollapsibleTrigger asChild><Soma.Button hierarchy="transparent">Mostrar</Soma.Button></Soma.CollapsibleTrigger><Soma.CollapsibleContent>…</Soma.CollapsibleContent></Soma.Collapsible>
```

---
**Usar para:** Um trecho que abre e fecha, com animação de altura.
**Nunca:** esconder informação obrigatória.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
