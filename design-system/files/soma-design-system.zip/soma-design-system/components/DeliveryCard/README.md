Card "Sua próxima entrega", na aba Reciclar e no Início.

**Você fornece:** o estado e, quando agendada, espaço, data e endereço; mais a ação.

- `empty`: `surface-secondary`, "Você ainda não agendou uma entrega" em `label`, botão "Agendar entrega".
- `scheduled`: `surface-accent`, "Vila Verde · Seg, 07 set" em `label`, endereço em `caption`, botão "Mostrar meu QR".
- `past`: a data passou sem entrega registrada; "Reagendar entrega". **Não está desenhado no Figma** (pendência anotada na tela).
- **Sem ícone** no texto nem no botão (versões anteriores tinham calendário e `qr-code`). Raio `radius-large`, padding `space-micro`, botão `loud` `compact` em largura total.

**Acessibilidade:** `section` "Sua próxima entrega"; o botão diz a ação.

**Figma:** "Delivery variant" A e B na Aba Reciclar (443:12175). Os rótulos "Variante A/B" são anotação e não vão para a tela; no app é um só card, em largura total.

**React:** `<Soma.DeliveryCard state="scheduled" space="Vila Verde" date="Seg, 07 set" address="R. Nunes Machado, 620 · Batel" onAction={mostrarQR} />`

---
**Usar para:** Card "Sua próxima entrega", na aba Reciclar e no Início.
**Nunca:** usar como resumo de confirmação (use `DeliverySummaryCard`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
