Card "Sua próxima entrega", na aba Reciclar e no Início.

**Você fornece:** o estado e, quando agendada, espaço, data e endereço; mais a ação.

- `empty`: `surface-secondary`, calendário + "Você ainda não agendou uma entrega", botão "Agendar entrega".
- `scheduled`: `surface-accent`, "Vila Verde · Seg, 07 set · 09h" em `label`, endereço em `caption`, botão "Mostrar meu QR" com ícone `qr-code`.
- `past`: a data passou sem entrega registrada; "Reagendar entrega" (pendência anotada no Figma).
- Raio `radius-large`, padding `space-micro`, botão `loud` `compact` em largura total.

**Acessibilidade:** `section` "Sua próxima entrega"; o botão diz a ação.

**Figma:** "Delivery variant" A e B na Aba Reciclar (478:14965, 478:14970). Os rótulos "Variante A/B" são anotação e não vão para a tela.

**React:** `<Soma.DeliveryCard state="scheduled" space="Vila Verde" date="Seg, 07 set · 09h" address="R. Nunes Machado, 620" onAction={mostrarQR} />`
