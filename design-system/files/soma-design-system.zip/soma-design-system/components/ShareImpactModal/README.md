Modal "Compartilhar meu impacto": resume os números da entrega e oferece três caminhos para compartilhar.

**Você fornece:** os três números (`stats`: `value`, `label`, `highlight`), os destinos (`options`: ícone, rótulo e `onClick`) e, se quiser, o `trigger`. Controle com `open` e `onOpenChange`.

- Radix Dialog centralizado: fundo `surface-card`, raio `radius-xlarge`, padding 24px, largura até 358px. Título em `subtitle`, apoio em `body-small`, X de 44px no canto.
- Resumo em três chips (`surface-secondary`, raio `radius-medium`): "3,2 kg reciclados", "+64 pontos" (em `text-link`), "12 L de água". Divisor. Depois três destinos em círculos de 48px: Mensagem, Rede social e Copiar link. Por fim o botão "Fechar" (`loud`).
- Abre pelo botão "Compartilhar" do `ImpactTiles` (Entrega registrada) e do Meu impacto.

**Acessibilidade:** foco preso no modal, Esc fecha, o foco volta ao botão que abriu; cada destino é um botão com texto visível.

**Figma:** Tela 16 (443:13637 e seguintes).

**React:** `<Soma.ShareImpactModal open={aberto} onOpenChange={setAberto} stats={[{ value: '3,2 kg', label: 'reciclados' }, { value: '+64', label: 'pontos', highlight: true }, { value: '12 L', label: 'de água' }]} options={[{ icon: 'message', label: 'Mensagem' }, { icon: 'users', label: 'Rede social' }, { icon: 'link', label: 'Copiar link' }]} />`

---
**Usar para:** Modal "Compartilhar meu impacto": resume os números da entrega e oferece três caminhos para compartilhar.
**Nunca:** passar de três caminhos de compartilhar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
