# ShareImpactModal

Folha "Compartilhar meu impacto": resume os números da entrega e oferece três caminhos para compartilhar.

## O que você fornece

Os três números (`stats`: `value`, `label`, `highlight`), os destinos (`options`: ícone, rótulo e `onClick`) e, se quiser, o `trigger`. Controle com `open` e `onOpenChange`.

## Especificação

- Folha inferior com título, descrição e os números sobre azul-marinho.
- Três ações em círculos brancos e "Fechar" em botão neutro.

## Acessibilidade

Foco preso no modal, Esc fecha, o foco volta ao botão que abriu; cada destino é um botão com texto visível.

## Nas telas da v2

Ativação: [Compartilhar impacto](prototipo/#842-10693).

## Código

```
<Soma.ShareImpactModal open={aberto} onOpenChange={setAberto} stats={[{ value: '3,2 kg', label: 'reciclados' }, { value: '+64', label: 'pontos', highlight: true }, { value: '12 L', label: 'de água' }]} options={[{ icon: 'message', label: 'Mensagem' }, { icon: 'users', label: 'Rede social' }, { icon: 'link', label: 'Copiar link' }]} />
```

---
**Usar para:** Modal "Compartilhar meu impacto": resume os números da entrega e oferece três caminhos para compartilhar.
**Nunca:** passar de três caminhos de compartilhar.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
