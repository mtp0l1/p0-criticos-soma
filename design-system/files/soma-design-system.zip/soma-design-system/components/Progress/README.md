# Progress

Barra de progresso contínua, sobre Radix Progress (shadcn Progress).

## O que você fornece

O valor de 0 a 100 e um `label` acessível.

## Especificação

- Altura `space-nano` (8px), trilho `surface-track` (#E8E2D6), preenchimento `selected-indicator` (#FFA125), `radius-full`, como nas telas da v2. A animação de avanço some com movimento reduzido.
- `indicatorClassName` troca o preenchimento quando o fundo já é laranja (`GoalCard` usa `bg-surface-inverse`).
- Sempre com o número ou a frase ao lado ("40%", "Faltam 3 perguntas"): o progresso nunca vai só na barra.
- Sequência com marcos usa `StreakProgress`.

## Acessibilidade

`role="progressbar"` com `aria-valuenow`, `aria-valuemax` e nome.

## Código

```
<Soma.Progress value={40} label="Progresso no nível" />
```

---
**Usar para:** Barra de progresso contínua, sobre Radix Progress (shadcn Progress).
**Nunca:** usar para etapas discretas.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
