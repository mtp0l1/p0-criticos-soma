Barra de progresso contínua, sobre Radix Progress (shadcn Progress).

**Você fornece:** o valor de 0 a 100 e um `label` acessível.

- Altura `space-nano` (8px), trilho `surface-track` (#DDE4EE), preenchimento `selected-indicator` (#FFA125), `radius-full`, como no Figma. A animação de avanço some com movimento reduzido.
- `indicatorClassName` troca o preenchimento quando o fundo já é laranja (`GoalCard` usa `bg-surface-inverse`).
- Sempre com o número ou a frase ao lado ("40%", "Faltam 3 perguntas"): o progresso nunca vai só na barra.
- Etapas discretas usam `StepDots` (cadastro) ; sequência com marcos usa `StreakProgress`.

**Acessibilidade:** `role="progressbar"` com `aria-valuenow`, `aria-valuemax` e nome.

**React:** `<Soma.Progress value={40} label="Progresso no nível" />`

---
**Usar para:** Barra de progresso contínua, sobre Radix Progress (shadcn Progress).
**Nunca:** usar para etapas discretas (use `StepDots`).
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
