Botão de liga e desliga, sozinho ou em grupo (shadcn Toggle e ToggleGroup, sobre Radix).

**Você fornece:** o conteúdo (ícone, texto ou os dois), o estado (`pressed` ou `value`) e, se for só ícone, um `aria-label`.

- Desligado: `ghost` (sem borda) ou `outline` (borda `input`). Ligado: fundo `surface-accent`, borda `border-highlight` e peso 600; o estado não depende só da cor.
- Hover `interactive-fill-quiet-hover`, pressionado `-active`, foco com o anel do sistema, desabilitado em `interactive-fill-disabled`.
- `ToggleGroup type="single"` escolhe um (exibição em lista ou mapa); `type="multiple"` escolhe vários (filtro de materiais).
- Para ligar uma configuração com efeito imediato, use `Switch`. Para escolha única com rótulo de grupo, `ChoiceChips`.

**Acessibilidade:** `aria-pressed` no Toggle; no grupo, um ponto de tabulação e setas entre os itens. Dê `aria-label` ao grupo.

**Base técnica:** Radix Toggle e ToggleGroup; variantes em `toggleVariants`; o grupo passa `variant` e `size` aos itens por contexto.

**React:** `<Soma.Toggle aria-label="Favoritar" pressed={on} onPressedChange={setOn}><Soma.Icon name="heart" /></Soma.Toggle>` · `<Soma.ToggleGroup type="single" variant="outline" value={v} onValueChange={setV} aria-label="Exibição"><Soma.ToggleGroupItem value="lista">Lista</Soma.ToggleGroupItem></Soma.ToggleGroup>`

---
**Usar para:** Botão de liga e desliga, sozinho ou em grupo (shadcn Toggle e ToggleGroup, sobre Radix).
**Nunca:** usar para enviar formulário ou navegar; só liga e desliga um estado.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
