Estado vazio centralizado com ilustração, título, explicação e um próximo passo.

**Você fornece:** a ilustração, o título, uma frase de apoio e a ação.

- Título `page-title`, apoio `body` em `text-secondary`, ação `quiet` em largura total. Gap `space-mini`, respiro `space-large`.
- "Item não encontrado", sem ":(". Diga o que houve e o que fazer.
- A ação leva a uma saída real: "Enviar e-mail" para o SAC. Região sem cobertura: "Avisar quando abrir aqui".
- Ilustração plana, suave e urbana.
- Busca ainda não feita também tem estado: nunca deixe a tela em branco.

**React:** `<Soma.EmptyState title="Item não encontrado" description="…" action={{ label: 'Enviar e-mail', icon: 'mail' }} />`
