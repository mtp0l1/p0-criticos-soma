Estado vazio centralizado com ilustração, título, explicação e um próximo passo.

**Você fornece:** a ilustração, o título, uma frase de apoio e a ação. Opcional: `secondaryAction` e `artFrame`.

- Título `page-title` (aceita quebra de linha com `\n`), apoio `body` em `text-secondary`. A ação principal é `loud` em largura total (`hierarchy="quiet"` quando for só uma saída lateral, como "Enviar e-mail"); `secondaryAction` é `quiet`, logo abaixo.
- Moldura da arte: padrão círculo creme de 160px; `artFrame="rect"` retângulo de 240×160 `surface-secondary` (Meu espaço antes da 1ª entrega, com `building`); `artFrame={false}` mostra a ilustração solta (ranking de amigos vazio).
- "Item não encontrado", sem ":(". Diga o que houve e o que fazer. A ação leva a uma saída real.
- Busca ainda não feita também tem estado: nunca deixe a tela em branco.

**Figma:** Ranking, Tela 6 "Meu espaço sem entrega" (443:18966) e Tela 8 "Amigos vazio" (443:19602).

**React:** `<Soma.EmptyState artFrame={false} art={<Soma.Illustration name="ranking-vazio" />} title={'Seu ranking de amigos\ncomeça com você'} description="Quando seu amigo fizer a 1ª entrega, vocês ganham 100 pontos cada um." action={{ label: 'Convidar amigos' }} secondaryAction={{ label: 'Adicionar amigo por código' }} />`

---
**Usar para:** Estado vazio centralizado com ilustração, título, explicação e um próximo passo.
**Nunca:** mostrar sem próximo passo nem usar ilustração fora do catálogo.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
