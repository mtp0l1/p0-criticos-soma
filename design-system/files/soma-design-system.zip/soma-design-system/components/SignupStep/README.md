# SignupStep

Corpo de um passo do cadastro: título, campos, botão e pontos de progresso. **Um dado por tela.** Vai abaixo do `Header title="Cadastro"`.

## O que você fornece

O título do passo (`title`), o passo atual (`step`) e o total (`total`, padrão 7). Opcional: `description` e `action` (o botão). Os campos entram como filhos.

## Especificação

- Padding lateral `space-xsmall` (20px), 24px abaixo do cabeçalho. Título em `page-title` (24px, bold) e a linha de apoio em `body-small` `text-secondary`, 8px abaixo.
- Cada bloco fica a **40px** do próximo (`space-large`): título → campos → aceite → botão → pontos. Campos do mesmo bloco ficam a 24px; agrupe numa `div` com `grid gap-small`.
- O botão **segue o conteúdo**, não prende no rodapé. Fica desabilitado até o campo obrigatório estar válido; o erro é curto, embaixo do campo, sem apagar o que a pessoa digitou.
- A seta do cabeçalho é a única forma de voltar: retorna ao passo anterior e mantém o que já foi preenchido. Não há botão "Voltar" no corpo.
- Passos do handoff anterior: 01 nome e data de nascimento, 02 CPF, 03 e-mail, 04 celular, 05 senha, 06 CEP, 07 código de convite e aceite (aqui o botão é "Criar minha conta").

## Acessibilidade

O `h1` é o "Cadastro" do cabeçalho; o título do passo é `h2`. Os pontos dizem "Passo 4 de 7" ao leitor de tela.

## Nas telas da v2

Cadastro, de [Nome e data de nascimento](prototipo/#835-6472) a [Código de convite (vazio)](prototipo/#835-6657).

## Código

```
<Soma.SignupStep title="Qual é o seu celular?" step={4} action={<Soma.Button fullWidth disabled={!ok}>Continuar</Soma.Button>}><Soma.TextField label="Celular" mask="phone" required value={tel} onChange={setTel} /></Soma.SignupStep>
```

---
**Usar para:** Corpo de um passo do cadastro: título, campos, botão e pontos de progresso.
**Nunca:** pôr mais de um dado por tela nem prender o botão no rodapé: ele segue o conteúdo.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
