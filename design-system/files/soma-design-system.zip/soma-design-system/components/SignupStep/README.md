# SignupStep

Passo do cadastro: topo com Voltar e Ajuda; tile de ícone, título, campos e o botão fixo no pé da tela. **Um dado por tela.** Não leva `Header` nem indicador de progresso.

## O que você fornece

O título do passo (`title`). Opcional: `icon`, `description`, `onBack`, `onHelp` e `action` (o botão). Os campos entram como filhos.

## Especificação

- Voltar (seta `chevron-left`) e Ajuda em discos no topo; ícone num círculo pêssego de 56px, título, descrição, campos e o botão no pé.

## Acessibilidade

O título do passo é o h2 da tela; os botões se chamam "Voltar" e "Ajuda".

## Nas telas da v2

Cadastro, de [Nome e data de nascimento](prototipo/#835-6472) a [Código de convite (vazio)](prototipo/#835-6657).

## Código

```
<Soma.SignupStep title="Qual é o seu celular?" icon="phone" onBack={voltar} onHelp={ajuda} action={<Soma.Button fullWidth>Continuar</Soma.Button>}>
  <Soma.TextField label="Celular" mask="phone" required value={v} onChange={setV} />
</Soma.SignupStep>
```

---
**Usar para:** Passo do cadastro: topo com Voltar e Ajuda, título, campos e botão fixo no pé da tela.
**Nunca:** pôr mais de um dado por tela, soltar o botão do pé da tela nem mostrar "Passo N de 7": o cadastro não tem indicador de progresso.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
