# SignupStep

Passo do cadastro: topo com Voltar, barra de progresso e Ajuda; tile de ícone, título, campos e o botão fixo no pé da tela. **Um dado por tela.** Não leva `Header`.

## O que você fornece

O título do passo (`title`), o passo atual (`step`) e o total (`total`, padrão 7). Opcional: `icon`, `description`, `onBack`, `onHelp` e `action` (o botão). Os campos entram como filhos.

## Especificação

- Topo: Voltar em disco branco de 44px, a barra de progresso ("Passo 4 de 7", os passos já feitos em laranja) no centro e Ajuda em disco à direita. Padding lateral `space-xsmall` (20px).
- Tile de ícone de 52px (`surface-tint-peach`, ícone em `icon-brand`), 40px abaixo do topo. Título em `page-title` (28px bold) e a linha de apoio em `body-small` `text-secondary`, 8px abaixo.
- Campos a 24px do título (`space-small`); campos do mesmo bloco, numa div com `grid gap-nano`.
- O botão fica fixo no pé da tela (56px de altura, 24px da borda). Fica desabilitado até o campo obrigatório estar válido; o erro é curto, embaixo do campo, sem apagar o que a pessoa digitou.
- Voltar retorna ao passo anterior e mantém o que já foi preenchido. Não há botão "Voltar" no corpo.
- Passos: 01 nome e data de nascimento, 02 CPF, 03 e-mail, 04 celular, 05 senha, 06 CEP, 07 código de convite e aceite (aqui o botão é "Criar minha conta").

## Acessibilidade

O título do passo é o h2 da tela; os botões se chamam "Voltar" e "Ajuda". A barra de progresso diz "Passo 4 de 7" ao leitor de tela.

## Nas telas da v2

Cadastro, de [Nome e data de nascimento](prototipo/#835-6472) a [Código de convite (vazio)](prototipo/#835-6657).

## Código

```
<Soma.SignupStep title="Qual é o seu celular?" icon="phone" step={4} onBack={voltar} onHelp={ajuda} action={<Soma.Button fullWidth>Continuar</Soma.Button>}>
  <Soma.TextField label="Celular" mask="phone" required value={v} onChange={setV} />
</Soma.SignupStep>
```

---
**Usar para:** Passo do cadastro: topo com progresso, título, campos e botão fixo no pé da tela.
**Nunca:** pôr mais de um dado por tela nem soltar o botão do pé da tela: ele fica fixo embaixo.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
