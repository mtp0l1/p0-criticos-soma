# PillTabs

Abas em pílulas soltas: a ativa cheia e as outras contornadas. Na tela de Recompensas troca entre Catálogo e Meus resgates.

## O que você fornece

Os itens, o valor atual e o rótulo do grupo.

## Especificação

- Pílulas de 40px (`size-chip`), `radius-full`. Ativa: `surface-inverse` com `text-inverse`. Inativa: fundo `surface-primary`, sombra `shadow-card` e texto foreground.
- Espaço de `space-nano` entre as pílulas. Para duas ou três opções curtas. Se o conteúdo é o mesmo recortado (período, filtro), use `Tabs`; para escolha dentro de um formulário, `SegmentedControl`.

## Acessibilidade

Tabs: `role="tablist"`, `aria-selected`, setas movem o foco.

## Nas telas da v2

Recompensas: [Catálogo com meta](prototipo/#854-9534) e [Escolha a próxima meta](prototipo/#854-10106). O versão anterior desenhava a aba inativa com texto laranja (#DD8613, 2,6:1); na v2 o texto fica navy.

## Código

```
<Soma.PillTabs label="Recompensas" value={v} onChange={setV} items={[{ id: 'cat', label: 'Catálogo' }, { id: 'res', label: 'Meus resgates' }]} />
```

---
**Usar para:** Abas em pílulas soltas: a ativa cheia e as outras contornadas.
**Nunca:** usar fora de Recompensas nem com mais de duas abas.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
