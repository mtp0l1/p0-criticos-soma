Abas em pílulas soltas: a ativa cheia e as outras contornadas. Na tela de Recompensas troca entre Catálogo e Meus resgates.

**Você fornece:** os itens, o valor atual e o rótulo do grupo.

- Pílulas de 44px de altura, `radius-full`. Ativa: `interactive-fill-loud` com `text-on-loud` (navy) e sem borda. Inativa: fundo `surface-primary`, borda `border-highlight` e texto `foreground`.
- Espaço de `space-nano` entre as pílulas. Para duas ou três opções curtas. Se o conteúdo é o mesmo recortado (período, filtro), use `Tabs`; para escolha dentro de um formulário, `SegmentedControl`.

**Acessibilidade:** Radix Tabs: `role="tablist"`, `aria-selected`, setas movem o foco.

**Figma:** Recompensas, Telas 1 e 9 (438:1973). O Figma desenha a inativa com texto laranja (#DD8613, 2,6:1); aqui o texto fica navy.

**React:** `<Soma.PillTabs label="Recompensas" value={v} onChange={setV} items={[{ id: 'cat', label: 'Catálogo' }, { id: 'res', label: 'Meus resgates' }]} />`

---
**Usar para:** Abas em pílulas soltas: a ativa cheia e as outras contornadas.
**Nunca:** usar fora de Recompensas nem com mais de duas abas.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
