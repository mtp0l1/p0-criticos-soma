Cartão do participante com avatar, nome e QR code para identificação no espaço de recebimento.

**Você fornece:** o nome, o QR code (gerado pelo back-end) e, se houver, a foto (`photo`).

- Fundo `surface-brand`, raio `radius-large`, nome em `page-title` caixa alta. Avatar de `size-avatar` com borda `surface-primary` e iniciais quando não há foto. QR num quadro `surface-primary` de `size-qr`, padding `space-micro`.
- O app escreve o nome em branco sobre laranja (2,05:1). O padrão aqui é `text-on-loud` (7,07:1); `nameTone="app"` reproduz o app e reprova.
- Nunca reduza o QR abaixo de `size-qr` nem coloque nada sobre a margem branca.
- Aumente o brilho da tela ao abrir o cartão (comportamento do app, não do componente).

**Base técnica:** Radix `Avatar` (`size="avatar"`); sem `photo`, mostra as iniciais do nome.

**React:** `<Soma.MemberCard name="Sabrina O'Hara" photo={foto} qr={<img src={qrUrl} alt="QR code do participante" />} />`
