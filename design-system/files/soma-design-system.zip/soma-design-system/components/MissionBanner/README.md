Faixa escura de missão com título, contagem de etapas e barra segmentada.

**Você fornece:** o título da missão, o total de etapas e quantas estão concluídas.

- Fundo `surface-inverse`, raio `radius-large`, texto `text-inverse` (14,49:1), estrela em `icon-brand`.
- Um segmento por etapa: concluído em `selected-indicator`, pendente em `text-secondary`. A legenda "N de M etapas completas" sempre acompanha a barra.
- O componente some sozinho quando `done` alcança `total`.
- Fale em "etapas", nunca "missões" para as partes de uma missão.

**Acessibilidade:** a barra é decorativa (`aria-hidden`); o progresso é lido pela legenda.

**React:** `<Soma.MissionBanner title="Primeira missão" total={8} done={3} />`
