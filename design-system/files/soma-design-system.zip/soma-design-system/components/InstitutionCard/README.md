# InstitutionCard

Instituição que recebe a doação de pontos. Aparece no topo da tela de doação (valor, saldo zero e pontos insuficientes).

## O que você fornece

Nome, descrição, imagem e o destino de "Saber mais".

## Especificação

- Cartão com a imagem ou o logo da instituição, o nome e "Saber mais" com seta. A descrição é opcional: na tela de valor, ela não aparece.

## Acessibilidade

O nome é `h2`; "Saber mais" diz ao leitor sobre qual instituição.

## Nas telas da v2

Doar pontos: [Valor da doação](prototipo/#832-6750). Na lista de escolha a instituição é o `InstitutionRow`.

## Código

```
<Soma.InstitutionCard name="Associação S. Francisco de Assis" description="Abrigo e adoção." onMore={abrir} />
```

---
**Usar para:** Instituição que recebe a doação de pontos.
**Nunca:** esconder o "Saber mais".
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
