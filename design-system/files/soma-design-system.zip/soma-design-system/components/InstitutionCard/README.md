# InstitutionCard

Instituição que recebe a doação de pontos. Aparece no topo da tela de doação (valor, saldo zero e pontos insuficientes).

## O que você fornece

Nome, descrição, imagem e o destino de "Saber mais".

## Especificação

- Card `surface-primary` com borda `border-primary`, raio `radius-large`, padding `space-mini`. Imagem de 64px com raio `radius-medium`; sem imagem, ícone `hand-heart`.
-

Nome em `label`, descrição em `caption`, "Saber mais" em `text-link` sublinhado (no handoff anterior é azul #2563EB; o sistema usa um link só).
-

O link "Saber mais" parece texto mas tem área tocável de 44px de altura.

## Acessibilidade

O nome é `h2`; "Saber mais" diz ao leitor sobre qual instituição.

## Nas telas da v2

Doar pontos: [Valor da doação](prototipo/#832-6750). Na lista de escolha a instituição é o `InstitutionRow`.

## Código

```
<Soma.InstitutionCard name="Associação S. Francisco de Assis" description="Abrigo e adoção." onMore={abrir} />
```

---
**Usar para:** Instituição que recebe a doação de pontos.
**Nunca:** esconder o "Saber mais".
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
