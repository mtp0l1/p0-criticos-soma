Instituição que recebe a doação de pontos.

**Você fornece:** nome, descrição, imagem e o destino de "Saber mais".

- Card `surface-primary` com borda `border-primary`, raio `radius-large`, padding `space-mini`. Imagem de 64px com raio `radius-medium`; sem imagem, ícone `hand-heart`.
- Nome em `label`, descrição em `caption`, "Saber mais" em `text-link` sublinhado (no Figma é azul #2563EB; o sistema usa um link só).

**Acessibilidade:** o nome é `h2`; "Saber mais" diz ao leitor sobre qual instituição.

**Figma:** "InstitutionCard" em Doar pontos (478:12936).

**React:** `<Soma.InstitutionCard name="Associação S. Francisco de Assis" description="Abrigo e adoção." onMore={abrir} />`
