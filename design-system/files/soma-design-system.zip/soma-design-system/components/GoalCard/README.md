# GoalCard

Minha meta no topo do catálogo de recompensas: o prêmio escolhido e o quanto falta.

## O que você fornece

O nome da recompensa (`reward`), os pontos atuais (`points`), a meta (`goal`) e, se houver, os quilos equivalentes ao que falta (`missingKg`). `onPress` ou `href` levam ao detalhe do prêmio, onde fica "Trocar recompensa".

## Especificação

- Cartão em `surface-brand` com a bandeira, "Minha meta" e o placar de pontos; nome da recompensa e barra.
- Em andamento: "Faltam N pontos" e a estimativa em quilos (`material`). Atingida: pílula azul-marinho "Meta atingida! Pronta para troca."

## Acessibilidade

Barra com `role="progressbar"` e rótulo "Progresso da meta"; o texto "faltam" é lido, não só a barra.

## Nas telas da v2

Recompensas: [Catálogo com meta](prototipo/#854-9534), [Nova meta definida](prototipo/#854-9138) e [Meta atingida](prototipo/#854-9923). Sem o botão "Trocar meta" que existia na versão anterior.

## Código

```
<Soma.GoalCard reward="Kit 5 canetas Fine Pen" points={320} goal={800} missingKg={24} onPress={abrirDetalhe} />
```

---
**Usar para:** Minha meta no topo do catálogo de recompensas: o prêmio escolhido e o quanto falta.
**Nunca:** mostrar meta sem quanto falta.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
