Minha meta no topo do catálogo de recompensas: o prêmio escolhido e o quanto falta.

**Você fornece:** o nome da recompensa (`reward`), os pontos atuais (`points`), a meta (`goal`) e, se houver, os quilos equivalentes ao que falta (`missingKg`). `onPress` ou `href` levam ao detalhe do prêmio, onde fica "Trocar recompensa".

- Card `surface-brand` com `radius-large` e padding `space-mini`. Primeira linha: "MINHA META" em `eyebrow` e "320 / 800 pontos" em bold, à direita. Depois o prêmio em `subtitle`, a barra de progresso e, embaixo, "faltam 480 pontos" à esquerda e "≈ 24 kg de recicláveis" à direita.
- Meta atingida: ícone de check ao lado dos pontos e "Meta atingida! Pronta para troca." no lugar do "faltam".
- No Figma o card é degradê laranja com texto branco (2,05:1). Aqui o fundo é `surface-brand` com `text-on-loud` (navy) e a barra em `surface-inverse` sobre trilho `surface-primary`.
- Quando `onPress`/`href` existem, o card inteiro é tocável (Tela 5). Trocar a meta com mais de 50% de progresso é proposta (PROPOSTA) e ainda precisa de confirmação.

**Acessibilidade:** barra com `role="progressbar"` e rótulo "Progresso da meta"; o texto "faltam" é lido, não só a barra.

**Figma:** Recompensas, Telas 1, 5 e 17 (438:1973). Sem o botão "Trocar meta" que existia na versão anterior.

**React:** `<Soma.GoalCard reward="Kit 5 canetas Fine Pen" points={320} goal={800} missingKg={24} onPress={abrirDetalhe} />`

---
**Usar para:** Minha meta no topo do catálogo de recompensas: o prêmio escolhido e o quanto falta.
**Nunca:** mostrar meta sem quanto falta.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
