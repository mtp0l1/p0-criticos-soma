Meta atual no topo do catálogo de recompensas.

**Você fornece:** a recompensa escolhida, os pontos que a pessoa tem, os pontos da meta e, se puder trocar, `onChange`.

- Fundo `surface-brand` com `text-on-loud`, raio `radius-large`. "SUA META" em `eyebrow`, recompensa em `body-strong`, `Progress` com trilho `surface-primary` e preenchimento `surface-inverse`, linha "1.130 de 2.236 pontos · faltam 1.106".
- No Figma o card é um degradê #E8823F → #F2994A com texto branco (2,05:1): aqui o texto é navy e não há degradê.

**Acessibilidade:** `section` "Sua meta"; o progresso tem nome e o número vem em texto.

**Figma:** meta no catálogo (477:22160).

**React:** `<Soma.GoalCard reward="Kit 5 canetas" points={1130} goal={2236} onChange={trocarMeta} />`
