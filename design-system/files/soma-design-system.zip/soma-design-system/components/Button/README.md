# Button

Botão de ação em cinco ênfases (`loud`, `dark`, `quiet`, `transparent`, `destructive`), construído como o Button do shadcn/ui: `buttonVariants` (CVA), `asChild` (Radix Slot) e `forwardRef`.

## O que você fornece

O rótulo, em verbo de ação curto ("Ok, entendi", "Convidar amigos"), a ênfase e, se fizer sentido, um ícone.

## Especificação

- Um `loud` por tela: pílula de 56px, `primary` com `primary-foreground` (6,2:1) e brilho `shadow-glow`. Nunca texto branco sobre laranja.
- `quiet` é a ação secundária clara: fundo `surface-primary`, sombra `shadow-card`, ícone `icon-primary`.
- `dark` é a ação forte secundária ("Mostrar meu QR", "Compartilhar"): fundo `surface-inverse`, texto `text-inverse`, sombra `shadow-dark`.
- `transparent` é link curto ("Ver níveis", "Ver mais") em `text-link`.
- `destructive` só para sair, apagar ou cancelar algo que não volta, quase sempre dentro de `AlertDialog`.
- `size`: `large` (56px, padrão), `compact` (48px, listas e cards densos), `icon` (quadrado de 44px; prefira `IconButton`).
- `fullWidth` para a ação principal de modal, bottom sheet e formulário. `asChild` para um link com cara de botão (`<Button asChild><a href="…">…</a></Button>`).

## Estados

Padrão · hover (`interactive-fill-*-hover`) · pressionado (`*-active`) · foco (anel `ring` de 2px a 2px) · `disabled` (`interactive-fill-disabled` com `interactive-text-disabled`, sem opacidade) · `loading` (mantém a cor, troca o ícone pelo indicador, `aria-busy` e ignora toques). - Link com cara de botão desabilitado (`asChild` + `disabled`) recebe `aria-disabled`, sai da ordem de foco e ganha o mesmo visual. `destructive` tem hover e pressionado próprios (`interactive-fill-destructive-hover` e `-active`).

## Acessibilidade

O rótulo é o nome acessível. Botão só com ícone é `IconButton`, com `label` obrigatório. Transição respeita `prefers-reduced-motion`.

## Código

```
<Soma.Button hierarchy="quiet" icon="user-plus" iconPosition="end">Convidar amigos</Soma.Button>
```

```
buttonVariants({ hierarchy: 'loud', fullWidth: true })
```

---
**Usar para:** Botão de ação em cinco ênfases (`loud`, `dark`, `quiet`, `transparent`, `destructive`), construído como o Button do shadcn/ui: `buttonVariants` (CVA), `asChild` (Radix Slot) e `forwardRef`.
**Nunca:** ter dois botões `loud` na mesma tela, nem trocar cor ou raio por `className`.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
