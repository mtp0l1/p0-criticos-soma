Card da "Pergunta do dia" no Quiz (Tela 1): pergunta, opções "a) …" e envio.

**Você fornece:** a pergunta, as opções (`options`, só o texto), a opção marcada (`value`) e o envio (`onSubmit`). Opcional: `points`, `info` (texto do balão do i) e `submitting`.

- Card com borda de 1,5px `border-highlight` e espaço interno de 16px. Cabeçalho: "Pergunta do dia" em 12px 700 `text-link` e o `PointsBadge` de 10px ("+15 pontos") à direita. Pergunta em 15px 700.
- As opções ganham "a)", "b)", "c)", "d)" na frente. Cada uma tem borda `input` e raio `radius-small`; a marcada fica em `surface-accent`, com borda `border-highlight` de 1,5px e texto 600. Não há bolinha de rádio visível.
- "Enviar resposta" é `loud`, largura total, desabilitado até uma opção ser marcada.
- Depois de responder, a tela troca para `AnswerResult` e, ao voltar, para `DailyDone`.
- As opções têm 44px de altura (alvo de toque do sistema); o Figma desenha 36px.

**Acessibilidade:** Radix RadioGroup com a pergunta como nome do grupo; setas movem entre opções; o foco aparece no contorno da opção.

**Figma:** Quiz, Tela 1 (443:15355). O laranja #DD8613 reprova (2,8:1); aqui é `text-link`.

**React:** `<Soma.QuestionCard points={15} question={q} options={opcoes} value={v} onChange={setV} onSubmit={enviar} />`
