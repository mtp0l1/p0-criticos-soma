Card da "Pergunta do dia" no Quiz: pergunta, opções de resposta e envio.

**Você fornece:** a pergunta, as opções (`options`), a opção marcada (`value`) e o envio (`onSubmit`). Opcional: `points` (quanto o acerto vale), `info` (texto do balão do i) e `submitting`.

- Card com borda de 1,5px `border-highlight`, "PERGUNTA DO DIA" em `eyebrow` maiúsculo `text-link` e `PointsBadge` ("+15 pontos") à direita.
- Opções em `body-small`, borda `input`, raio `radius-small`; marcada: `surface-accent` e borda `border-highlight`.
- "Enviar resposta" é `loud`, largura total, desabilitado até uma opção ser marcada. Com `submitting`, mostra a espera no botão.
- Depois de responder, a tela troca para `AnswerResult` (acerto ou erro) e, no dia seguinte à resposta, para `DailyDone`. O card não tem mais estado "já respondida" nem `version`.

**Acessibilidade:** Radix RadioGroup com a pergunta como nome do grupo; setas movem entre opções.

**Figma:** Quiz, Tela 1 (443:15190). O laranja #DD8613 reprova (2,8:1); aqui é `text-link`.

**React:** `<Soma.QuestionCard points={15} question={q} options={opcoes} value={v} onChange={setV} onSubmit={enviar} />`
