# QuestionCard

Card da "Pergunta do dia" no Quiz (Tela 1): pergunta, opções "a) …" e envio.

## O que você fornece

A pergunta, as opções (`options`, só o texto), a opção marcada (`value`) e o envio (`onSubmit`). Opcional: `points`, `info` (texto do balão do i) e `submitting`.

## Especificação

- Cartão creme com borda de destaque, "Pergunta do dia" e os pontos numa pílula primária.
- Pergunta em 18px. Cada opção é uma linha branca de 56px com o rádio visível; escolhida, ganha borda e o rádio preenchido com `check`.
- A pergunta abre sem resposta marcada, e "Enviar resposta" só habilita depois da escolha.

## Acessibilidade

RadioGroup com a pergunta como nome do grupo; setas movem entre opções; o foco aparece no contorno da opção.

## Nas telas da v2

Quiz: [Pergunta do dia](prototipo/#849-8934). O laranja #DD8613 da versão anterior reprova (2,8:1); aqui é `text-link`.

## Código

```
<Soma.QuestionCard points={15} question={q} options={opcoes} value={v} onChange={setV} onSubmit={enviar} />
```

---
**Usar para:** Card da "Pergunta do dia" no Quiz (Tela 1): pergunta, opções "a) …" e envio.
**Nunca:** revelar a resposta certa antes do envio.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
