Card da pergunta do dia: opções de resposta e envio, ou o aviso de que a pessoa já respondeu.

**Você fornece:** o estado (`open` ou `answered`), a pergunta, as opções, a opção marcada e o envio. Opcional: `info` (texto do balão do i) e `points` (quanto o acerto vale).

- `version="atual"` (padrão, Figma do Quiz): card com borda de 1,5px `border-highlight`, "PERGUNTA DO DIA" em `eyebrow` maiúsculo `text-link` e `PointsBadge` à direita. Opções em `body-small`, borda `input`, raio `radius-small`; marcada: `surface-accent` e borda `border-highlight`.
- `version="anterior"`: eyebrow em `text-secondary` com linha tracejada, opções com borda laranja.
- "Enviar resposta" é `loud` em largura total e fica desabilitado até uma opção ser marcada.
- Já respondida: relógio em `icon-brand-strong` (estado de espera, nunca check verde) e "Volte amanhã".
- Resultado (acertou ou errou) vai em `Modal` ou `Sheet`; resposta errada explica e incentiva, nunca culpa.

**Acessibilidade:** Radix RadioGroup com a pergunta como nome do grupo; setas movem entre opções.

**Figma:** card da pergunta no Quiz (477:20539). O texto laranja #DD8613 do Figma reprova (2,8:1); aqui ele é `text-link`.

**React:** `<Soma.QuestionCard state="open" points={15} question={q} options={opcoes} value={v} onChange={setV} onSubmit={enviar} />`
