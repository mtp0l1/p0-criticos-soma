Interruptor de liga e desliga com efeito imediato, sobre Radix Switch (shadcn Switch). Para notificações e preferências.

**Você fornece:** o rótulo (ligado por `htmlFor`) e o estado.

- 44 × 24px. Desligado: trilho `text-secondary` e bolinha branca. Ligado: trilho `surface-inverse` e bolinha `primary`. Os dois trilhos passam de 3:1 contra o branco; o laranja sozinho não passaria.
- Rótulo à esquerda, interruptor à direita, linha de `size-touch`.
- Muda na hora, sem botão de salvar. Se a mudança precisa de confirmação, use `Checkbox` com botão.
- A área tocável é de 44px de altura. Hover escurece o trilho desligado; desabilitado fica cinza nos dois estados.

**Acessibilidade:** `role="switch"` com `aria-checked`; espaço e Enter alternam.

**React:** `<Soma.Label htmlFor="lembrete">Lembrete da pergunta do dia</Soma.Label><Soma.Switch id="lembrete" checked={on} onCheckedChange={setOn} />`
