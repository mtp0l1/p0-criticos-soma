# Switch

Interruptor de liga e desliga com efeito imediato, sobre Switch. Para notificações e preferências.

## O que você fornece

O rótulo (ligado por `htmlFor`) e o estado.

## Especificação

- 52 × 32px. Desligado: trilho `interactive-fill-disabled` e bolinha branca com sombra. Ligado: trilho `primary` (laranja). A posição da bolinha também mostra o estado, não só a cor. O trilho ligado tem 2,0:1 contra o branco, abaixo dos 3:1 de borda de controle; a v2 aceita isso porque o estado não depende só da cor.
- Rótulo à esquerda, interruptor à direita, linha de `size-touch`.
- Muda na hora, sem botão de salvar. Se a mudança precisa de confirmação, use `Checkbox` com botão.
- A área tocável é de 44px de altura. Hover escurece o trilho desligado; desabilitado fica cinza nos dois estados.

## Acessibilidade

`role="switch"` com `aria-checked`; espaço e Enter alternam.

## Código

```
<Soma.Label htmlFor="lembrete">Lembrete da pergunta do dia</Soma.Label><Soma.Switch id="lembrete" checked={on} onCheckedChange={setOn} />
```

---
**Usar para:** Interruptor de liga e desliga com efeito imediato, sobre Switch.
**Nunca:** exigir botão de salvar depois: o efeito é imediato; para aceite de regulamento use `Checkbox`.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
