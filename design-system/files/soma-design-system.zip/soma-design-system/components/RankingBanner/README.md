Atalho laranja para o ranking, com a posição num círculo e uma frase de contexto.

**Você fornece:** a posição, o título e a frase.

- Fundo `surface-brand`, raio `radius-large`, texto e círculo em `text-on-loud` (7,07:1). Nunca texto branco.
- Posição em `stat-number` dentro de círculo de 56px com borda de 2px.
- A frase compara com quem entrega no mesmo espaço de recebimento ("Você já reciclou mais que 9,23% dos participantes do seu espaço").
- Sem entrega no período, não mostre posição: troque por `Message` com chamada para a primeira entrega.

**Acessibilidade:** o banner é um botão; a posição é lida como "Posição 305".

**Estados:** hover em `interactive-fill-loud-hover`, toque em `interactive-fill-loud-active` (navy mantém mais de 5:1). Com `href`, vira link.

**React:** `<Soma.RankingBanner position={305} title="Continuar entregando" message="…" onPress={abrirRanking} />`
