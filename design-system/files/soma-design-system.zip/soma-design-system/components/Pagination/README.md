Navegação entre páginas de uma lista (shadcn Pagination).

**Você fornece:** os links das páginas, a atual (`isActive`) e anterior e próxima (`disabled` nos extremos).

- Itens de 44px. Página atual: `surface-accent` com borda `border-highlight` e peso 600.
- No app, prefira "Carregar mais" ou rolagem contínua. Use paginação quando a pessoa precisa saber a posição ou voltar a uma página (extrato longo, painel web).

**Acessibilidade:** `nav` "Paginação"; a página atual leva `aria-current="page"`; setas têm rótulo ("Página anterior", "Próxima página"); extremos desabilitados saem da ordem de foco.

**React:** `<Soma.Pagination><Soma.PaginationContent><Soma.PaginationItem><Soma.PaginationPrevious href="?p=1" /></Soma.PaginationItem><Soma.PaginationItem><Soma.PaginationLink href="?p=2" isActive>2</Soma.PaginationLink></Soma.PaginationItem></Soma.PaginationContent></Soma.Pagination>`

---
**Usar para:** Navegação entre páginas de uma lista (shadcn Pagination).
**Nunca:** usar em lista curta ou rolagem infinita.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
