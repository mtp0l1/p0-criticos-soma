# ContactRow

Linha de contato para convidar: avatar, nome, espaço e o botão "Convidar".

## O que você fornece

O nome (`name`), o espaço (`space`) e o estado (`status`: `idle` ou `sent`). Opcional: `photo` e `onInvite`.

## Especificação

- Cartão branco com avatar, nome e espaço. "Convidar" com contorno primário; depois de enviado, etiqueta verde "Enviado".

## Acessibilidade

O botão diz o nome ("Convidar Larissa Prado"); "Convite enviado" é texto.

## Nas telas da v2

Ranking: [Amigos que participam](prototipo/#859-10987).

## Código

```
<Soma.ContactRow name="Larissa Prado" space="Vila Verde" status="idle" onInvite={convidar} />
```

---
**Usar para:** Linha de contato para convidar: avatar, nome, espaço e o botão "Convidar".
**Nunca:** trocar o botão "Convidar" por outra ação.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
