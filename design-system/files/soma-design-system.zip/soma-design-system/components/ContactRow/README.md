Linha de contato para convidar: avatar, nome, espaço e o botão "Convidar".

**Você fornece:** o nome (`name`), o espaço (`space`) e o estado (`status`: `idle` ou `sent`). Opcional: `photo` e `onInvite`.

- Cartão com `Avatar` (iniciais quando não há foto), nome em `label` e espaço em `caption`. Em `idle`: botão "Convidar" (`quiet`). Em `sent`: pílula "Convite enviado", sem botão.
- Depois de enviar, o estado muda na própria linha; nunca remova a linha.

**Acessibilidade:** o botão diz o nome ("Convidar Larissa Prado"); "Convite enviado" é texto.

**Figma:** Convidar amigos (438:1973).

**React:** `<Soma.ContactRow name="Larissa Prado" space="Vila Verde" status="idle" onInvite={convidar} />`
