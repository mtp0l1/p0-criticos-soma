Linha de contato para convidar: avatar, nome, espaço e o botão "Convidar".

**Você fornece:** o nome (`name`), o espaço (`space`) e o estado (`status`: `idle` ou `sent`). Opcional: `photo` e `onInvite`.

- Cartão de 64px com `Avatar` de 40px (iniciais quando não há foto), nome em `label` e espaço em `caption`. Em `idle`: botão "Convidar" (`quiet`, pílula). Em `sent`: pílula "Convite enviado", sem botão.
- Depois de enviar, o estado muda na própria linha; nunca remova a linha. Entre as linhas, `space-nano`.
- Abaixo da lista vai "Convidar quem ainda não participa" (`quiet`, largura total), que leva à tela Convidar amigos.

**Acessibilidade:** o botão diz o nome ("Convidar Larissa Prado"); "Convite enviado" é texto.

**Figma:** Ranking, Tela 15 "Amigos que participam" (581:2997).

**React:** `<Soma.ContactRow name="Larissa Prado" space="Vila Verde" status="idle" onInvite={convidar} />`
