# ContactRow

Linha de contato para convidar: avatar, nome, espaço e o botão "Convidar".

## O que você fornece

O nome (`name`), o espaço (`space`) e o estado (`status`: `idle` ou `sent`). Opcional: `photo` e `onInvite`.

## Especificação

- Cartão de 64px com `Avatar` de 40px (iniciais quando não há foto), nome em `label` e espaço em `caption`. Em `idle`: botão "Convidar" (`quiet`, pílula). Em `sent`: pílula "Convite enviado", sem botão.
- Depois de enviar, o estado muda na própria linha; nunca remova a linha. Entre as linhas, `space-nano`.
- Abaixo da lista vai "Convidar quem ainda não participa" (`quiet`, largura total), que leva à tela Convidar amigos.

## Acessibilidade

O botão diz o nome ("Convidar Larissa Prado"); "Convite enviado" é texto.

## Nas telas da v2

Ranking: [Amigos que participam](prototipo/#859-10987).

## Código

```
<Soma.ContactRow name="Larissa Prado" space="Vila Verde" status="idle" onInvite={convidar} />
```

---
**Usar para:** Linha de contato para convidar: avatar, nome, espaço e o botão "Convidar".
**Nunca:** trocar o botão "Convidar" por outra ação.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
