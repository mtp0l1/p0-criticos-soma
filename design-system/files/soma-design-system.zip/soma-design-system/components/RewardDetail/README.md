Detalhe de uma recompensa: imagem, categoria, nome, custo, etiquetas e "De onde vêm os pontos".

**Você fornece:** a categoria (`category`), o nome (`title`), os pontos (`points`) e a origem dos pontos (`source`). Opcional: `image` e `tags`.

- Imagem em quadro `surface-secondary` de 150px de altura e `radius-large`; sem imagem, mostra o ícone de presente.
- Categoria em `eyebrow` `text-link`, nome em `screen-title`, custo e etiquetas em pílulas (450 pontos, "2× vidro").
- Bloco "De onde vêm os pontos" com a conta em `text-link` ("45,0 kg de vidro = 450 pontos ≈ R$ 45,00 em prêmios"). Sempre explica a origem; nunca só o número.
- Os botões ("Resgatar", "Trocar recompensa", "Usar como meta") ficam fixos embaixo, fora do componente.

**Figma:** Recompensas, Tela 18 (438:1973).

**React:** `<Soma.RewardDetail category="Alimentação e gastronomia" title="Kit de temperos gourmet" points={450} tags={['2× vidro']} source="45,0 kg de vidro = 450 pontos ≈ R$ 45,00 em prêmios" />`

---
**Usar para:** Detalhe de uma recompensa: imagem, categoria, nome, custo, etiquetas e "De onde vêm os pontos".
**Nunca:** esconder "De onde vêm os pontos".
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
