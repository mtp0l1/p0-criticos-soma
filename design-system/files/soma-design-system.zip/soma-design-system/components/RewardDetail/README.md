# RewardDetail

Detalhe de uma recompensa: imagem, categoria, nome, custo, etiquetas e "De onde vêm os pontos".

## O que você fornece

A categoria (`category`), o nome (`title`), os pontos (`points`) e a origem dos pontos (`source`). Opcional: `image` e `tags`.

## Especificação

- Faixa pêssego com o ícone num disco (ou a imagem), categoria, nome e etiquetas; os pontos em pílula primária.
- "De onde vêm os pontos" em três colunas quando `source` segue "quanto = pontos ≈ valor".
- `steps` mostra "Como resgatar" numerado.

## Nas telas da v2

Recompensas: [Detalhe · Definir meta](prototipo/#854-9076).

## Código

```
<Soma.RewardDetail category="Alimentação e gastronomia" title="Kit de temperos gourmet" points={450} tags={['2× vidro']} source="45,0 kg de vidro = 450 pontos ≈ R$ 45,00 em prêmios" />
```

---
**Usar para:** Detalhe de uma recompensa: imagem, categoria, nome, custo, etiquetas e "De onde vêm os pontos".
**Nunca:** esconder "De onde vêm os pontos".
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
