# RewardChoiceList

Lista de recompensas para escolher a meta durante o cadastro. Cada recompensa é um card com botão de opção.

## O que você fornece

O nome do grupo para leitor de tela (`label`), as opções (`options`: `value`, `title`, `points`, `unavailable`), o valor escolhido (`value`) e `onChange`.

## Especificação

- Cada recompensa é um cartão com ícone num disco, nome e pontos. Escolhida: fundo creme, borda de destaque e `check` à direita.
- Indisponível: cinza, com a etiqueta "Indisponível no momento", sem escolha.
- `icon` em cada opção é opcional.

## Acessibilidade

RadioGroup: um ponto de tabulação, setas movem a escolha; o grupo se chama pelo `label`.

## Nas telas da v2

Ativação: [Escolha a recompensa](prototipo/#842-9303) e [Escolha (progresso zero)](prototipo/#842-9387).

## Código

```
<Soma.RewardChoiceList label="Recompensa da meta" value={meta} onChange={setMeta} options={[{ value: 'fones', title: 'Fones de ouvido Bluetooth', points: 800 }]} />
```

---
**Usar para:** Lista de recompensas para escolher a meta durante o cadastro.
**Nunca:** usar fora do cadastro (no catálogo use `RewardRow`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
