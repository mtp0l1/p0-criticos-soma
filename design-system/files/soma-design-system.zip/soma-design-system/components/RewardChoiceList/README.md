Lista de recompensas para escolher a meta durante o cadastro. Cada recompensa é um card com botão de opção.

**Você fornece:** o nome do grupo para leitor de tela (`label`), as opções (`options`: `value`, `title`, `points`, `unavailable`), o valor escolhido (`value`) e `onChange`.

- Card `surface-card`, raio `radius-large`, padding 16px, gap de 12px entre o botão de opção e o texto. Texto: "Fones de ouvido Bluetooth · 800 pontos". A escolhida leva borda de 2px `border-highlight` e o texto em `label`; as outras, borda de 1px.
- Sem estoque: card em `interactive-fill-disabled`, texto apagado e "· Indisponível no momento" no fim. Não dá para escolher e o leitor de tela lê como desabilitado.
- O card todo é a área de toque (mínimo 44px). Entre os cards, `space-micro` (12px).
- Fica logo acima do `GoalProgressCard`, que mostra quanto falta para a recompensa escolhida, e do botão "Definir como meta".

**Acessibilidade:** Radix RadioGroup: um ponto de tabulação, setas movem a escolha; o grupo se chama pelo `label`.

**Figma:** Telas 25 e 26 (443:12728 e 443:12811).

**React:** `<Soma.RewardChoiceList label="Recompensa da meta" value={meta} onChange={setMeta} options={[{ value: 'fones', title: 'Fones de ouvido Bluetooth', points: 800 }]} />`