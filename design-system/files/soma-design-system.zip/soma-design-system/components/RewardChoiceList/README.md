# RewardChoiceList

Lista de recompensas para escolher a meta durante o cadastro. Cada recompensa é um card com botão de opção.

## O que você fornece

O nome do grupo para leitor de tela (`label`), as opções (`options`: `value`, `title`, `points`, `unavailable`), o valor escolhido (`value`) e `onChange`.

## Especificação

- Card `surface-card`, raio `radius-large`, padding 16px, gap de 12px entre o botão de opção e o texto. Texto: "Fones de ouvido Bluetooth · 800 pontos". A escolhida leva borda de 2px `border-highlight` e o texto em `label`; as outras, borda de 1px.
- Sem estoque: card em `interactive-fill-disabled`, texto apagado e "· Indisponível no momento" no fim. Não dá para escolher e o leitor de tela lê como desabilitado.
- O card todo é a área de toque (mínimo 44px). Entre os cards, `space-micro` (12px).
- Fica logo acima do `GoalProgressCard`, que mostra quanto falta para a recompensa escolhida, e do botão "Definir como meta".

## Acessibilidade

RadioGroup: um ponto de tabulação, setas movem a escolha; o grupo se chama pelo `label`.

## Nas telas da v2

Ativação: [Escolha a recompensa](prototipo/#842-9303) e [Escolha (progresso zero)](prototipo/#842-9387).

## Código

```
<Soma.RewardChoiceList label="Recompensa da meta" value={meta} onChange={setMeta} options={[{ value: 'fones', title: 'Fones de ouvido Bluetooth', points: 800 }]} />
```

---
**Usar para:** Lista de recompensas para escolher a meta durante o cadastro.
**Nunca:** usar fora do cadastro (no catálogo use `RewardRow`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
