# HelpfulVote

Pergunta "Isso ajudou?" com Sim e Não, ao fim de um artigo de ajuda.

## O que você fornece

O voto atual e o que fazer ao votar.

## Especificação

- Cartão branco com a pergunta e dois botões em pílula, com ícone. A escolhida fica em `primary`.

## Acessibilidade

Os botões usam `aria-pressed`; o agradecimento é `role="status"`.

## Base técnica

ToggleGroup `type="single"`; o escolhido tem `data-state="on"` e `aria-pressed`.

## Código

```
<Soma.HelpfulVote value={voto} onVote={setVoto} />
```

---
**Usar para:** Pergunta "Isso ajudou?" com Sim e Não, ao fim de um artigo de ajuda.
**Nunca:** usar fora do fim de um artigo de ajuda.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
