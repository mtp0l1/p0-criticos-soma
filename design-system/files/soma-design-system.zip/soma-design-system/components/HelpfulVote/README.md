# HelpfulVote

Pergunta "Essa resposta foi útil?" com Sim e Não, ao fim de um artigo de ajuda.

## O que você fornece

O voto atual e o que fazer ao votar.

## Especificação

- Fica abaixo do texto, separada por divisor `border-primary`. Pergunta em `label`.
- Botões de `size-touch` com borda `interactive-border-quiet`; o escolhido ganha `interactive-fill-loud`.
- Depois do voto, "Obrigado pela resposta." em `caption`. Com "Não", ofereça "Enviar e-mail" para o SAC.

## Acessibilidade

Os botões usam `aria-pressed`; o agradecimento é `role="status"`.

## Base técnica

ToggleGroup `type="single"`; o escolhido tem `data-state="on"` e `aria-pressed`.

## Código

```
<Soma.HelpfulVote value={voto} onVote={setVoto} />
```

---
**Usar para:** Pergunta "Essa resposta foi útil?" com Sim e Não, ao fim de um artigo de ajuda.
**Nunca:** usar fora do fim de um artigo de ajuda.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
