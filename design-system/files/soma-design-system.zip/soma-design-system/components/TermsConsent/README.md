# TermsConsent

Aceite do regulamento e aviso de privacidade, no último passo do cadastro.

## O que você fornece

`checked` e `onCheckedChange`. Opcional: `regulationHref` e `privacyHref`.

## Especificação

- `Checkbox` de 20px com raio `radius-xsmall` e o texto "Declaro que li e estou de acordo com o **Regulamento do programa**." (`body-small`; o link em `text-link` sublinhado, na versão anterior é azul #286DC7). Abaixo, a 16px, o aviso "Acesse a nossa **Política de Privacidade** para informações sobre como tratamos os seus Dados Pessoais."
- "Criar minha conta" **só fica ativo com o aceite marcado**. Os links abrem sem desmarcar nem marcar a caixa.

## Acessibilidade

O texto é o rótulo do checkbox (`htmlFor`); o link dentro do rótulo é focável à parte.

## Nas telas da v2

Cadastro: [Código de convite (vazio)](prototipo/#835-6657), [Código aplicado](prototipo/#835-6601) e [Onde encontro o código?](prototipo/#835-6621).

## Código

```
<Soma.TermsConsent checked={aceite} onCheckedChange={setAceite} />
```

---
**Usar para:** Aceite do regulamento e aviso de privacidade, no último passo do cadastro.
**Nunca:** pré-marcar o aceite nem liberar o botão sem ele.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
