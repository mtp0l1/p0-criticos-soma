# RankingRow

Linha da classificação depois do pódio: "#4", avatar, nome e quilos.

## O que você fornece

Posição, nome, quilos e, se houver, foto. Na linha da própria pessoa: `self`, `hint` ("Faltam 6,5 kg para ultrapassar Carlos Lima") e, se as letras do avatar diferem do nome, `initials`.

## Especificação

- Card `surface-primary` com borda `border-primary`, raio `radius-medium`, padding `space-micro` (12px). Colunas: "#4" em 14px bold `text-secondary`, avatar de 36px, nome em `label` e quilos em `label` bold, à direita. Entre as colunas, `space-micro`.
- `self`: fundo `surface-accent`, borda `border-highlight`, avatar na cor de destaque, "#5" e quilos em `text-link`, nome em bold. O nome é "Você (Policarpo)" e o avatar mostra "P".
- `hint` ocupa a largura da linha, abaixo, alinhado ao avatar (32px da borda), em `caption` bold. Só a linha da própria pessoa tem dica.
- Use dentro de `RankingList` (lista ordenada com `space-nano` entre linhas). Não é tocável.

## Acessibilidade

Cada linha é item de lista ordenada; "º lugar" e "(você)" são lidos, o "#" é só visual.

## Nas telas da v2

Lista do Ranking: [Ranking · Amigos](prototipo/#859-9252), [Ranking · Meu espaço](prototipo/#859-9406), [Ranking do novato](prototipo/#859-10444) e [Poucos participantes](prototipo/#859-10199). #FFF2EA/#FFD3BE do handoff anterior viram `surface-accent`/`border-highlight`; o raio de 14px vira `radius-medium` (12px), da escala fechada.

## Código

```
<Soma.RankingList><Soma.RankingRow position={3} name="Você (Policarpo)" initials="P" kg={31.7} self hint="Faltam 6,5 kg para ultrapassar Carlos Lima" /></Soma.RankingList>
```

---
**Usar para:** Linha da classificação depois do pódio: "#4", avatar, nome e quilos.
**Nunca:** mostrar posição sem o nome da pessoa.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
