Linha da classificação depois do pódio.

**Você fornece:** posição, nome, quilos e, se houver, foto. Na linha da própria pessoa: `self` e `hint` ("Faltam 6,5 kg para ultrapassar Carla").

- Card `surface-primary` com borda `border-primary`, raio `radius-medium`, padding `space-micro`. Posição em 14px bold `text-secondary`, avatar de 36px, nome em `label`, quilos em `label` à direita.
- `self`: fundo `surface-accent`, borda `border-highlight`, posição e nome em `text-link`.
- Use dentro de `RankingList` (lista ordenada com `space-nano` entre linhas). Não é tocável.

**Acessibilidade:** cada linha é item de lista ordenada; "(você)" é lido na linha da pessoa.

**Figma:** lista do Ranking (478:10126): #FFF2EA/#FFD3BE viram `surface-accent`/`border-highlight`.

**React:** `<Soma.RankingList><Soma.RankingRow position={5} name="Você" kg={136} self hint="Faltam 6,5 kg para ultrapassar Carla" /></Soma.RankingList>`
