# SegmentedControl

Controle em pílula para alternar entre duas ou três seções, como Quiz e Histórico.

## O que você fornece

Os itens, o valor atual e o rótulo do grupo.

## Especificação

- Trilho `surface-secondary` em pílula (`radius-full`), padding `space-xnano`. O segmento ativo é azul-marinho (`surface-inverse`) com texto `text-inverse`.
- Segmento ativo em `interactive-fill-loud` com `text-on-loud`; inativo sem fundo, em `text-primary`.
-

No máximo três segmentos, rótulos de uma palavra.
-

Cada seção tem 40px de altura dentro de um trilho de 48px (a área tocável do trilho passa dos 44px).

## Acessibilidade

`role="tablist"` com `aria-selected`.

## Base técnica

Radix Tabs com `TabsList variant="segmented"`. Hover em `interactive-fill-quiet-hover`.

## Código

```
<Soma.SegmentedControl label="Seção do quiz" value={v} onChange={setV} items={[{id:'quiz',label:'Quiz'},{id:'hist',label:'Histórico'}]} />
```

---
**Usar para:** Controle em pílula para alternar entre duas ou três seções, como Quiz e Histórico.
**Nunca:** ter mais de três seções (use `Tabs`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
