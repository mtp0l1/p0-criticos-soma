Controle em pílula para alternar entre duas ou três seções, como Quiz e Histórico.

**Você fornece:** os itens, o valor atual e o rótulo do grupo.

- Contêiner `surface-primary` com borda `border-primary`, raio `radius-medium`, padding `space-xnano`.
- Segmento ativo em `interactive-fill-loud` com `text-on-loud`; inativo sem fundo, em `text-primary`.
- No máximo três segmentos, rótulos de uma palavra.

- Cada seção tem no mínimo 44px de altura (alvo de toque do sistema).

**Acessibilidade:** `role="tablist"` com `aria-selected`.

**Base técnica:** Radix Tabs com `TabsList variant="segmented"`. Hover em `interactive-fill-quiet-hover`.

**React:** `<Soma.SegmentedControl label="Seção do quiz" value={v} onChange={setV} items={[{id:'quiz',label:'Quiz'},{id:'hist',label:'Histórico'}]} />`

---
**Usar para:** Controle em pílula para alternar entre duas ou três seções, como Quiz e Histórico.
**Nunca:** ter mais de três seções (use `Tabs`).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
