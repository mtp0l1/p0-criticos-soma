Controle em pílula para alternar entre duas ou três seções, como Quiz e Histórico.

**Você fornece:** os itens, o valor atual e o rótulo do grupo.

- Contêiner `surface-primary` com borda `border-primary`, raio `radius-medium`, padding `space-xnano`.
- Segmento ativo em `interactive-fill-loud` com `text-on-loud`; inativo sem fundo, em `text-primary`.
- No máximo três segmentos, rótulos de uma palavra.

**Acessibilidade:** `role="tablist"` com `aria-selected`.

**Base técnica:** Radix Tabs com `TabsList variant="segmented"`. Hover em `interactive-fill-quiet-hover`.

**React:** `<Soma.SegmentedControl label="Seção do quiz" value={v} onChange={setV} items={[{id:'quiz',label:'Quiz'},{id:'hist',label:'Histórico'}]} />`
