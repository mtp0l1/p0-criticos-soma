Esqueleto de carregamento para texto, linha com miniatura e card.

**Você fornece:** o formato (`text`, `row`, `card`) e quantas linhas.

- Adição intencional, inspirada nos Skeletons do Andes: a produção anterior não tinha estado de carregamento e a tela fica em branco enquanto busca.
- Blocos em `surface-secondary` com brilho suave; sem animação quando a pessoa pede menos movimento.
- Mesmo tamanho do conteúdo que vai entrar (um `row` por item de resgate, um `card` por card de saldo). Troque pelo conteúdo assim que ele chegar; depois de 10 s, mostre erro com nova tentativa.

**Acessibilidade:** `role="status"` com rótulo "Carregando".

**Base técnica:** sem `variant`, é o Skeleton do shadcn: um bloco livre que você dimensiona com classes (`<Skeleton className="h-small w-[120px]" />`). Pulso suave, parado com movimento reduzido.

**React:** `<Soma.Skeleton variant="row" />`

---
**Usar para:** Esqueleto de carregamento para texto, linha com miniatura e card.
**Nunca:** ficar no lugar do erro: se a carga falhar, mostre `Message`.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
