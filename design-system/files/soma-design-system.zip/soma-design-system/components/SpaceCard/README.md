# SpaceCard

Espaço de recebimento: perto de você, opção do agendamento e da troca de espaço, ou o espaço atual.

## O que você fornece

Nome, distância, endereço e/ou horário; `onDirections` para "Como chegar"; `onSelect` e `selected` quando for opção; `current` para o espaço atual na troca.

## Especificação

- Na aba Reciclar: cartão branco com sombra, nome, selo de distância, horário com relógio e "Como chegar" em pílula pêssego, em largura total. Sem endereço.
- Como opção: rádio à esquerda, endereço e horário, e "Como chegar" como link no canto. Escolhido: fundo `surface-accent`, borda de 2px em `text-link` e rádio marcado.
- Espaço atual (`current`): fundo `surface-secondary`, pino no lugar do rádio e selo "Seu espaço". Não é escolhível.
- "Como chegar" abre o `SpaceMapSheet` do próprio espaço.

## Acessibilidade

A área de escolha é um botão com `aria-pressed`; "Como chegar" é um botão separado e diz o nome do espaço ao leitor.

## Nas telas da v2

[Aba Reciclar (nova)](prototipo/#829-7018), [Espaço de recebimento](prototipo/#842-9952) e [Escolha seu espaço](prototipo/#867-11279).

## Código

```
<Soma.SpaceCard name="Vila Verde" distance="800 m" address="Rua das Flores, 120" hours="Seg a sáb, 8h às 18h" selected onSelect={escolher} onDirections={abrirMapa} />
```

---
**Usar para:** listar espaços na aba Reciclar e oferecer a escolha no agendamento e na troca de espaço.
**Nunca:** mostrar espaço sem endereço.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
