# SpaceCard

Espaço de recebimento: na lista "perto de você" ou como opção na escolha do agendamento.

## O que você fornece

Nome, distância, endereço e/ou horário; `onDirections` para "Como chegar"; `onSelect` e `selected` quando for opção.

## Especificação

- Sem `onSelect` (aba Reciclar): `surface-secondary`, raio `radius-large`.
- Com `onSelect` (agendamento): `surface-primary` com borda `border-primary` e raio `radius-medium` (12px); selecionado ganha borda de 2px `border-highlight` e distância em `text-link`.
- Nome em `label`, distância, endereço e horário em `caption`. Horário com relógio.
- "Como chegar": `Button` `quiet` `compact` em pílula com `pin`; abre o mapa.
- Termo genérico é sempre "espaço de recebimento"; o nome próprio fica como cadastrado ("Casa so+ma Batel").

## Acessibilidade

A área de escolha é um botão com `aria-pressed`; "Como chegar" é um botão separado e diz o nome do espaço ao leitor.

## Nas telas da v2

Escolha do espaço: [Espaço de recebimento](prototipo/#842-9952) e [Escolha do espaço](prototipo/#842-9467). Na escolha do espaço cada card tem o "Como chegar" dentro (`onDirections`); no passo anterior o escolhido abre o `SpaceDetail`.

## Código

```
<Soma.SpaceCard name="Vila Verde" distance="800 m" address="Rua das Flores, 120" selected onSelect={escolher} onDirections={abrirMapa} />
```

---
**Usar para:** Espaço de recebimento: na lista "perto de você" ou como opção na escolha do agendamento.
**Nunca:** mostrar espaço sem endereço.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
