Espaço de recebimento: na lista "perto de você" ou como opção na escolha do agendamento.

**Você fornece:** nome, distância, endereço e/ou horário; `onDirections` para "Como chegar"; `onSelect` e `selected` quando for opção.

- Sem `onSelect` (aba Reciclar): `surface-secondary`, raio `radius-large`.
- Com `onSelect` (agendamento): `surface-primary` com borda `border-primary`; selecionado ganha borda de 2px `border-highlight` e distância em `text-link`.
- Nome em `label`, distância, endereço e horário em `caption`. Horário com relógio.
- "Como chegar": `Button` `quiet` `compact` em pílula com `pin`; abre o mapa.
- Termo genérico é sempre "espaço de recebimento"; o nome próprio fica como cadastrado ("Casa so+ma Batel").

**Acessibilidade:** a área de escolha é um botão com `aria-pressed`; "Como chegar" é um botão separado e diz o nome do espaço ao leitor.

**Figma:** "Recycling space card" (478:15006) e "Ecopoint-Card" em escolha-espaco (477:9318).

**React:** `<Soma.SpaceCard name="Vila Verde" distance="800 m" address="Rua das Flores, 120" selected onSelect={escolher} onDirections={abrirMapa} />`
