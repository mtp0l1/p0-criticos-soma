Indicador de espera sem duração conhecida (shadcn Spinner).

**Você fornece:** nada; opcionalmente um `label` que diga o que está carregando.

- 24px em `icon-brand-strong`; `className="size-icon-small"` para 16px ao lado de texto.
- Conteúdo de tela carregando usa `Skeleton`; botão em espera usa `loading` do `Button`. O Spinner fica para trechos pequenos (uma linha, um campo validando).

**Acessibilidade:** `role="status"` com nome ("Carregando"). Com movimento reduzido, para de girar; mantenha o texto ao lado.

**React:** `<Soma.Spinner label="Carregando recompensas" />`

---
**Usar para:** Indicador de espera sem duração conhecida (shadcn Spinner).
**Nunca:** usar quando se sabe a duração (use `Progress`).
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
