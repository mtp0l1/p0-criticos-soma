Modal de confirmação ou de escolha, com título, texto curto ou conteúdo, e uma única ação.

**Você fornece:** o título, a mensagem ou o conteúdo (como um `RadioList`), a arte opcional e o rótulo da ação.

- Contêiner `surface-primary`, raio `radius-large`, sobre `overlay`. Título `body-strong`, texto `caption` em `text-secondary`.
- Um X de 44px no canto e uma ação `loud` em largura total no pé. Não repita a mesma ação no X e no botão.
- Texto até três linhas. Se passar disso, o conteúdo vira tela cheia: o botão não pode ficar escondido.
- Ao fechar, a tela de trás já mostra o resultado (percentual, contador) sem precisar sair e voltar.
- Resposta errada explica e incentiva ("Quase lá!"). Arte urbana e plana; nada de lixo no chão ou rosto triste.

**Acessibilidade:** `role="dialog"`, foco preso, Esc e toque fora fecham, foco volta ao gatilho, título ligado por `aria-labelledby` (tudo do Radix).

**Base técnica:** Radix Dialog (`DialogContent`, `DialogHeader`, `DialogFooter`). Controle com `open`/`onOpenChange`, ou passe `trigger`. `dismissible={false}` tira o X e bloqueia Esc e toque fora. Para mais de uma ação, monte com as primitivas de `Dialog`.

**React:** `<Soma.Modal open={aberto} onOpenChange={setAberto} title="Parabéns! Resposta correta!" actionLabel="Ok, entendi" onAction={fechar}>Faltam 4 perguntas…</Soma.Modal>`

---
**Usar para:** Modal de confirmação ou de escolha, com título, texto curto ou conteúdo, e uma única ação.
**Nunca:** ter mais de uma ação principal nem esconder a saída.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
