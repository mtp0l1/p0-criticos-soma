Aviso da proteção semanal da sequência: "se você perder um dia, a sequência continua".

**Você fornece:** o texto e, se houver, `onInfo` para abrir "Como funciona a sequência".

- `variant="inline"` (padrão): uma linha com escudo, para dentro da tela do Quiz. `variant="card"`: faixa `surface-info` com mais texto, para a Tela 3 e o histórico.
- Com `onInfo`, aparece um botão de ícone de informação (44px, rótulo "Como funciona a proteção da sequência") que abre uma `Sheet` com a explicação.
- A proteção vale uma vez por semana. Escreva o que ela faz, sem prometer além disso.

**Acessibilidade:** o texto carrega a mensagem; o botão de informação leva rótulo próprio.

**Figma:** Quiz, Telas 1, 3 e 6 (443:15190).

**React:** `<Soma.ProtectionNotice onInfo={abrirSheet}>Proteção da semana disponível</Soma.ProtectionNotice>`
