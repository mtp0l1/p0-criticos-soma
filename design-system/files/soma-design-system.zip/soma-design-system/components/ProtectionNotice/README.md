# ProtectionNotice

Aviso da proteção semanal da sequência: "se você perder um dia, a sequência continua".

## O que você fornece

O texto e, no card, `onInfo` para abrir "Como funciona a sequência".

## Especificação

- Sempre em tom de informação (`surface-info`).
- `inline`: pílula de uma linha dentro da trilha. `card`: com o escudo num disco e, se houver `onInfo`, o botão de informação.

## Acessibilidade

O texto carrega a mensagem; o botão (i) leva rótulo próprio.

## Nas telas da v2

Quiz: [Pergunta do dia](prototipo/#849-8934), [Primeira vez no Quiz](prototipo/#849-9497) e [Como funciona a proteção](prototipo/#849-9594). No versão anterior o escudo do card era um emoji; aqui é o ícone `shield`.

## Código

```
<Soma.ProtectionNotice variant="card" onInfo={abrirSheet}>Perdeu um dia? A proteção semanal mantém sua sequência.</Soma.ProtectionNotice>
```

---
**Usar para:** Aviso da proteção semanal da sequência: "se você perder um dia, a sequência continua".
**Nunca:** prometer proteção que a regra semanal não dá.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
