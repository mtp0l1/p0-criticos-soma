Aviso da proteção semanal da sequência: "se você perder um dia, a sequência continua".

**Você fornece:** o texto e, no card, `onInfo` para abrir "Como funciona a sequência".

- `variant="inline"` (padrão): uma linha com escudo de 12px e texto de 12px 500, alinhada à esquerda, dentro da trilha ("Proteção usada. Renova em 2 dias"). Quando falta 1 dia: "Sua proteção renova amanhã".
- `variant="card"`: faixa `surface-accent` de raio `radius-medium` com círculo laranja de 32px e escudo, o texto ("Perdeu um dia? A proteção semanal mantém sua sequência.") e o botão (i). Fica na tela de níveis (Tela 5).
- Com `onInfo`, o (i) abre uma `Sheet` "Como funciona a sequência" (Tela 6): proteção da semana, quando a sequência quebra e os prêmios por constância (100, 500, 1.000 e 2.000 pontos).
- A proteção vale uma vez por semana e renova na segunda. Escreva o que ela faz, sem prometer além disso.

**Acessibilidade:** o texto carrega a mensagem; o botão (i) leva rótulo próprio.

**Figma:** Quiz, Telas 1, 5 e 6 (443:15355, 443:15921, 443:16021). No Figma o escudo do card é o emoji; aqui é o ícone `shield`.

**React:** `<Soma.ProtectionNotice variant="card" onInfo={abrirSheet}>Perdeu um dia? A proteção semanal mantém sua sequência.</Soma.ProtectionNotice>`

---
**Usar para:** Aviso da proteção semanal da sequência: "se você perder um dia, a sequência continua".
**Nunca:** prometer proteção que a regra semanal não dá.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
