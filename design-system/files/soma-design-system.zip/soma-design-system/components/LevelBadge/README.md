Etiqueta do nível do Quiz, em maiúsculas: o nome ("BRONZE") ou a dificuldade ("INICIANTE").

**Você fornece:** o nível (`tier`: `bronze`, `prata`, `ouro`) e o tipo (`kind`): `name` (padrão) mostra Bronze, Prata, Ouro; `level` mostra Iniciante, Intermediário, Avançado.

- Raio `radius-xsmall`, texto de 12px (o Figma desenha 10px), espaçamento largo e maiúsculas. Bronze: fundo `award-bronze`, texto `text-inverse`. Prata: fundo `surface-track`, texto em `foreground`. Ouro: fundo `tier-gold-border`, texto em `foreground`.
- Vai embaixo do troféu no `LevelCard`, ao lado do nome no `TierCard` e no `HistorySummary`. Não é tocável.

**Acessibilidade:** é texto; o nível é lido como palavra.

**Figma:** etiquetas "Bronze", "Iniciante", "Intermediário" e "Avançado" no Quiz, Telas 1, 4 e 5.

**React:** `<Soma.LevelBadge tier="bronze" />` · `<Soma.LevelBadge tier="prata" kind="level" />`

---
**Usar para:** Etiqueta do nível do Quiz, em maiúsculas: o nome ("BRONZE") ou a dificuldade ("INICIANTE").
**Nunca:** usar para texto que não seja nível ou dificuldade.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
