# LevelBadge

Etiqueta do nível do Quiz, em maiúsculas: o nome ("BRONZE") ou a dificuldade ("INICIANTE").

## O que você fornece

O nível (`tier`: `bronze`, `prata`, `ouro`) e o tipo (`kind`): `name` (padrão) mostra Bronze, Prata, Ouro; `level` mostra Iniciante, Intermediário, Avançado.

## Especificação

- Raio `radius-xsmall`, texto de 12px (a versão anterior desenha 10px), espaçamento largo e maiúsculas. Bronze: fundo `award-bronze`, texto `text-inverse`. Prata: fundo `surface-track`, texto em `foreground`. Ouro: fundo `tier-gold-border`, texto em `foreground`.
- Vai embaixo do troféu no `LevelCard`, ao lado do nome no `TierCard` e no `HistorySummary`. Não é tocável.

## Acessibilidade

É texto; o nível é lido como palavra.

## Nas telas da v2

Etiquetas "Bronze", "Iniciante", "Intermediário" e "Avançado" no Quiz: [Pergunta do dia](prototipo/#849-8934), [Histórico](prototipo/#849-9313) e [Primeira vez no Quiz](prototipo/#849-9497).

## Código

```
<Soma.LevelBadge tier="bronze" />
```

```
<Soma.LevelBadge tier="prata" kind="level" />
```

---
**Usar para:** Etiqueta do nível do Quiz, em maiúsculas: o nome ("BRONZE") ou a dificuldade ("INICIANTE").
**Nunca:** usar para texto que não seja nível ou dificuldade.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
