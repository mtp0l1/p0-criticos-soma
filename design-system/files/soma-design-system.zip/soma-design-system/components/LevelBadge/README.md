Selo do nível do quiz: o nome em maiúsculas ("BRONZE") ou a classificação ("Iniciante").

**Você fornece:** o nível (`tier`: `bronze`, `prata`, `ouro`) e o tipo (`kind`): `name` (padrão) mostra BRONZE, PRATA, OURO; `level` mostra Iniciante, Intermediário, Avançado.

- Raio `radius-xsmall`, texto de 12px em 600 com espaçamento largo. Bronze em `award-bronze` com `text-inverse` (5,40:1); prata e ouro em `award-silver` e `award-gold` com `text-primary`.
- Vai ao lado da `Medal`, no `LevelCard` e no `TierCard`. Não é tocável.

**Acessibilidade:** é texto; o nível é lido como palavra.

**Figma:** selos BRONZE e "Iniciante" no Quiz (443:15190).

**React:** `<Soma.LevelBadge tier="bronze" />` · `<Soma.LevelBadge tier="prata" kind="level" />`
