Selo do nível do quiz em maiúsculas ("BRONZE").

**Você fornece:** o nível (`tier`: ferro, bronze, prata, ouro, platina).

- Raio `radius-xsmall`, texto 12px em 600 com espaçamento largo. Cores: bronze `award-bronze` com `text-inverse` (5,40:1), prata `award-silver` e ouro `award-gold` com `text-primary`, ferro `surface-secondary`, platina `surface-inverse`.
- Vai ao lado do selo ilustrado do nível ou do nome da pessoa. Não é tocável.

**Acessibilidade:** é texto; o nível é lido como palavra.

**Figma:** selo "BRONZE" no Quiz (#8D6045).

**React:** `<Soma.LevelBadge tier="bronze" />`
