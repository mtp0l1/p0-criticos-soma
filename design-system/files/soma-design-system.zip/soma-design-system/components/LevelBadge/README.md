# LevelBadge

Etiqueta do nível do Quiz, em maiúsculas: o nome ("BRONZE") ou a dificuldade ("INICIANTE").

## O que você fornece

O nível (`tier`: `bronze`, `prata`, `ouro`) e o tipo (`kind`): `name` (padrão) mostra Bronze, Prata, Ouro; `level` mostra Iniciante, Intermediário, Avançado.

## Especificação

- Pílula em maiúsculas, 11px. Bronze em `primary`; Prata e Ouro mantêm tons próprios.

## Acessibilidade

É texto; o nível é lido como palavra.

## Nas telas da v2

Etiquetas "Bronze", "Iniciante", "Intermediário" e "Avançado" no Quiz: [Pergunta do dia](prototipo/#849-8934), [Histórico](prototipo/#849-9313) e [Primeira vez no Quiz](prototipo/#849-9497).

## Código

```
<Soma.LevelBadge tier="bronze" />
```

```
<Soma.LevelBadge tier="prata" kind="level" />
```

---
**Usar para:** Etiqueta do nível do Quiz, em maiúsculas: o nome ("BRONZE") ou a dificuldade ("INICIANTE").
**Nunca:** usar para texto que não seja nível ou dificuldade.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
