# NeighborhoodNote

Bairro encontrado pelo CEP, com o link "Corrigir".

## O que você fornece

O bairro e a cidade (`neighborhood`, "Aclimação, São Paulo") e `onFix`.

## Especificação

- Aparece 8px abaixo do campo de CEP quando a pessoa completa os 8 dígitos; "Bairro: …" em `body-small` e "Corrigir" em `text-link`, 8px abaixo.
- Com o CEP completo, "Continuar" fica ativo. Com o campo vazio, fica desabilitado (a consulta de CEP vem de um serviço de endereço).
- No handoff anterior os nomes dos quadros 06 e 06A estão trocados (o 06 "campo vazio" mostra o bairro e o 06A "CEP preenchido" mostra o campo vazio); vale a nota de comportamento.

## Acessibilidade

`role="status"`: o leitor de tela anuncia o bairro assim que ele aparece.

## Nas telas da v2

Cadastro: [CEP (campo vazio)](prototipo/#835-6586) e [CEP preenchido](prototipo/#835-6568).

## Código

```
<Soma.NeighborhoodNote neighborhood="Aclimação, São Paulo" onFix={limparCep} />
```

---
**Usar para:** Bairro encontrado pelo CEP, com o link "Corrigir".
**Nunca:** mostrar sem o link "Corrigir".
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
