# NeighborhoodNote

Endereço encontrado pelo CEP: cartão neutro com a rua, "bairro · cidade" e um lápis para corrigir.

## O que você fornece

O bairro (`neighborhood`, "Aclimação") e, se houver, a rua (`street`), a cidade e a UF (`city`, "São Paulo, SP") e `onFix` (toque no lápis).

## Especificação

- Aparece 16px abaixo do campo de CEP quando a pessoa completa os 8 dígitos, subindo 6px com fade de 240ms, sem rebote (parado com `prefers-reduced-motion`).
- Cartão `surface-secondary`, raio `radius-xl` (24px) e padding de 14px. Três colunas com `space-micro`: disco branco de 40px com o pino em `icon-brand-strong`, o texto e o lápis.
- Rua em `label` e, embaixo, "bairro · cidade" em `body-small` `text-secondary`; as duas em uma linha, com reticências. Sem rua, o bairro vira o título e a cidade, a linha de baixo.
- O lápis é um disco branco de 44px (`surface-primary`, `shadow-card`) com `pencil` em `icon-brand-strong` e o rótulo "Corrigir endereço"; leva de volta ao campo de CEP.
- É informação, não confirmação: nada de verde, de check nem de "encontramos!". Com o CEP completo, "Continuar" fica ativo; com o campo vazio, desabilitado (a consulta de CEP vem de um serviço de endereço).

## Acessibilidade

`role="status"`: o leitor de tela anuncia o endereço assim que ele aparece. O lápis é um botão de 44px com o nome "Corrigir endereço".

## Nas telas da v2

Cadastro: [CEP (campo vazio)](prototipo/#835-6586) e [CEP preenchido](prototipo/#835-6568).

## Código

```
<Soma.NeighborhoodNote street="Rua Pires da Mota" neighborhood="Aclimação" city="São Paulo, SP" onFix={limparCep} />
```

---
**Usar para:** Endereço encontrado pelo CEP: cartão neutro com a rua, "bairro · cidade" e um lápis para corrigir.
**Nunca:** mostrar como aviso de sucesso (verde, check) nem deixar o "Corrigir" solto fora do cartão.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
