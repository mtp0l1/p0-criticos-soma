Bairro encontrado pelo CEP, com o link "Corrigir".

**Você fornece:** o bairro e a cidade (`neighborhood`, "Aclimação, São Paulo") e `onFix`.

- Aparece 8px abaixo do campo de CEP quando a pessoa completa os 8 dígitos; "Bairro: …" em `body-small` e "Corrigir" em `text-link`, 8px abaixo.
- Com o CEP completo, "Continuar" fica ativo. Com o campo vazio, fica desabilitado (a consulta de CEP vem de um serviço de endereço).
- No Figma os nomes dos quadros 06 e 06A estão trocados (o 06 "campo vazio" mostra o bairro e o 06A "CEP preenchido" mostra o campo vazio); vale a nota de comportamento.

**Acessibilidade:** `role="status"`: o leitor de tela anuncia o bairro assim que ele aparece.

**Figma:** Cadastro, Telas 06 e 06A (443:9695 e 443:9713).

**React:** `<Soma.NeighborhoodNote neighborhood="Aclimação, São Paulo" onFix={limparCep} />`

---
**Usar para:** Bairro encontrado pelo CEP, com o link "Corrigir".
**Nunca:** mostrar sem o link "Corrigir".
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
