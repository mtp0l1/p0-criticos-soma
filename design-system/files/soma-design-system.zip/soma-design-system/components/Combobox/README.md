Select com busca, para listas longas como cidade (shadcn Combobox: Popover + Command).

**Você fornece:** as opções, o valor, o texto do gatilho vazio, o texto da busca e o texto de "nada encontrado".

- Gatilho com o desenho do `Select`; aberto, a borda vira `border-highlight`. A lista abre com a largura do gatilho, busca no topo e opção atual com check e peso 600.
- Opção em destaque: `accent`. Sem resultado: `emptyText` em `caption`.
- Até uns dez itens, use `NativeSelect` ou `Select`. Em tela pequena com lista muito longa, considere a busca em tela cheia (`SearchField` + `RadioList`).

**Acessibilidade:** gatilho com `role="combobox"` e `aria-expanded`; a busca filtra enquanto digita, setas movem, Enter escolhe, Esc fecha e devolve o foco. Ligue um `Label` pelo `id`.

**Base técnica:** Radix Popover + cmdk. Para casos fora do padrão (grupos, ícones), monte direto com `Popover` e `Command`.

**React:** `<Soma.Combobox id="cidade" options={cidades} value={v} onChange={setV} placeholder="Selecione a cidade" searchPlaceholder="Buscar cidade" emptyText="Nenhuma cidade com esse nome" />`
