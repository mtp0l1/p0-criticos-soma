Campo com ícone, texto ou botão dentro da mesma borda (shadcn InputGroup).

**Você fornece:** o `InputGroupInput` e um ou dois `InputGroupAddon` (`align="start"` ou `"end"`).

- Mesma altura, raio e borda do `Input`. O foco pinta a borda de `border-highlight` e põe o anel no grupo inteiro; erro (`aria-invalid` no input) e desabilitado também valem para o grupo.
- Addon de texto em `caption` `text-secondary` ("pontos", "R$"); ícone de 24px em `icon-brand-strong`; botão como `IconButton` (limpar, copiar, mostrar senha).
- `SearchField` é o atalho pronto para busca.

**Acessibilidade:** `role="group"`; o input precisa de rótulo (`Label` ou `aria-label`), porque o addon não nomeia o campo.

**Base técnica:** o estado do grupo vem do input por `has-[input:focus-visible]`, `has-[input[aria-invalid=true]]` e `has-[input:disabled]`, sem JavaScript.

**React:** `<Soma.InputGroup><Soma.InputGroupInput inputMode="numeric" aria-label="Quantidade de pontos" /><Soma.InputGroupAddon align="end">pontos</Soma.InputGroupAddon></Soma.InputGroup>`

---
**Usar para:** Campo com ícone, texto ou botão dentro da mesma borda (shadcn InputGroup).
**Nunca:** pôr mais de um botão dentro da mesma borda.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
