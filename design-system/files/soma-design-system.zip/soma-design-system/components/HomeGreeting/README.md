# HomeGreeting

Saudação do Início: avatar com a inicial, "Olá Mônica", o espaço de recebimento e os botões do cartão QR e da ajuda.

## O que você fornece

O primeiro nome (`name`) e, se existirem, `location` (espaço de recebimento), `photo`, `onQr` e `onHelp`.

## Especificação

- Avatar de 48px em `interactive-fill-loud` (laranja) com a inicial do nome em foreground; com `photo`, a foto no lugar.
- "Olá {nome}" em `screen-title` (22px bold), sem vírgula. Embaixo, o espaço de recebimento em `caption` `text-secondary`, com o ícone `pin` em `icon-brand`.
- À direita, QR e ajuda em discos brancos de 44px (`surface-primary`, `shadow-card`) com o ícone em `icon-brand`.
- Fica no topo do Início, 24px acima do `BalanceCard`. O espaço de recebimento vem na própria saudação.
- Os dois botões têm 44px, que já é a área de toque.

## Acessibilidade

O nome é um h1; os botões se chamam "Meu cartão QR" e "Ajuda". O avatar é decorativo.

## Nas telas da v2

Início: [Início · depois](prototipo/#829-6915).

## Código

```
<Soma.HomeGreeting name="Mônica" location="Casa so+ma Batel" onQr={abrirQr} onHelp={abrirAjuda} />
```

---
**Usar para:** Saudação do Início: avatar, "Olá Mônica", o espaço de recebimento e os botões do QR e da ajuda.
**Nunca:** trocar o nome da pessoa por texto genérico quando ele existe.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
