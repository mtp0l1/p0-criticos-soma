Saudação do Início: "Olá Mônica", o botão do cartão QR e a ajuda.

**Você fornece:** o primeiro nome (`name`) e, se existirem, `onQr` e `onHelp`.

- "Olá {nome}" em `screen-title` (20px bold), **sem vírgula**. Ao lado do nome, o botão do QR: círculo de `surface-secondary` com `qr-code` em `icon-brand`. À direita, o ícone de ajuda em `icon-brand`.
- Fica logo abaixo da `LocationBar` (24px de distância) e acima do `BalanceCard` (8px).
- Os dois botões têm área de toque de 44px, mesmo com o desenho de 32px do círculo.

**Acessibilidade:** o nome é um `h1`; os botões se chamam "Meu cartão QR" e "Ajuda".

**Figma:** Início, Home DEPOIS (443:12071).

**React:** `<Soma.HomeGreeting name="Mônica" onQr={abrirQr} onHelp={abrirAjuda} />`

---
**Usar para:** Saudação do Início: "Olá Mônica", o botão do cartão QR e a ajuda.
**Nunca:** trocar o nome da pessoa por texto genérico quando ele existe.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
