Faixa com um pedido de amizade recebido, com "Aceitar" e "Agora não".

**Você fornece:** o nome de quem convidou (`name`) e as ações `onAccept` e `onDecline`.

- Faixa `surface-accent` com "**Policarpo** quer adicionar você como amigo no ranking." e os dois botões à direita: "Agora não" em `transparent` e "Aceitar" em `loud` `compact`.
- Aparece no topo do Ranking, aba Amigos. Aceitar dá ao outro acesso aos seus quilos; diga isso se a tela tiver espaço.

**Acessibilidade:** `role="group"` com o nome "Pedido de amizade de Policarpo".

**Figma:** Ranking, Amigos (438:1973).

**React:** `<Soma.FriendRequestBanner name="Policarpo" onAccept={aceitar} onDecline={recusar} />`
