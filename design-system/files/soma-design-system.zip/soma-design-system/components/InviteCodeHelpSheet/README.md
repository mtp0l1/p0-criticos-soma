Bottom sheet "Onde encontro o código?": explica e mostra a mensagem de convite de exemplo.

**Você fornece:** `open` e `onOpenChange` (ou `trigger`). Opcional: `sender` e `code` do exemplo.

- Mesma folha do `AccountExistsSheet` (sem alça, sem X, `surface-secondary`, raio `radius-large`): título "Onde encontro o código?" em `body` bold, descrição "O código vem na mensagem de convite que seu amigo compartilhou com você.", o `InviteMessageExample` e o botão `loud` "Entendi" em largura total. Gaps de 24px.
- Abre por "Onde encontro o código?" do `InviteCodeField`. "Entendi" fecha e a pessoa volta ao passo 07 com o que digitou.

**Acessibilidade:** `dialog` com título e descrição; foco vai para dentro e volta ao link que abriu.

**Figma:** Cadastro, Tela 07B (443:9749).

**React:** `<Soma.InviteCodeHelpSheet open={ajuda} onOpenChange={setAjuda} />`

---
**Usar para:** Bottom sheet "Onde encontro o código?": explica e mostra a mensagem de convite de exemplo.
**Nunca:** abrir fora do passo do código de convite.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
