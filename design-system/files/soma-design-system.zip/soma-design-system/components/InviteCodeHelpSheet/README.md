# InviteCodeHelpSheet

Bottom sheet "Onde encontro o código?": explica e mostra a mensagem de convite de exemplo.

## O que você fornece

`open` e `onOpenChange` (ou `trigger`). Opcional: `sender` e `code` do exemplo.

## Especificação

- Folha com alça, título, explicação, o `InviteMessageExample` e "Entendi".

## Acessibilidade

`dialog` com título e descrição; foco vai para dentro e volta ao link que abriu.

## Nas telas da v2

Cadastro: [Onde encontro o código?](prototipo/#835-6621).

## Código

```
<Soma.InviteCodeHelpSheet open={ajuda} onOpenChange={setAjuda} />
```

---
**Usar para:** Bottom sheet "Onde encontro o código?": explica e mostra a mensagem de convite de exemplo.
**Nunca:** abrir fora do passo do código de convite.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
