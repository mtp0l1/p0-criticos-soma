Campo de texto de uma linha (shadcn Input) e o `Label` do Radix, com a altura e a borda acessível do So+ma.

**Você fornece:** o `type` ou `inputMode` certo, o valor e um `Label` ligado por `htmlFor`.

- Altura `size-input` (56px), raio `radius-medium`, borda `input` (3,98:1), texto `body`, placeholder `muted-foreground`.
- Hover escurece a borda; foco põe a borda `border-highlight` e o anel `ring`; erro (`aria-invalid`) põe a borda `feedback-text-negative`; desabilitado usa `interactive-fill-disabled`.
- Para campo com ajuda e erro prontos, use `TextField`. Para busca, `SearchField`.
- Erro também pinta o anel de foco de vermelho. Somente leitura (`readOnly`) usa `surface-secondary`. `type="file"` tem o botão estilizado em `text-link`.

**Acessibilidade:** sempre com rótulo visível; o placeholder não substitui o rótulo.

**React:** `<Soma.Label htmlFor="email">E-mail</Soma.Label><Soma.Input id="email" type="email" />`
