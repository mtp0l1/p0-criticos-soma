# Input

Campo de texto de uma linha (shadcn Input) e o `Label` do Radix, com a altura e a borda acessível do Campana.

## O que você fornece

O `type` ou `inputMode` certo, o valor e um `Label` ligado por `htmlFor`.

## Especificação

- Altura `size-input` (68px, com o rótulo flutuante dentro do campo), raio `radius-large` (20px), sombra `shadow-card`, borda `input` (3,98:1), texto `body`, placeholder `muted-foreground`.
- Hover escurece a borda; foco põe a borda `border-highlight` e o anel `ring`; erro (`aria-invalid`) põe a borda `feedback-text-negative`; desabilitado usa `interactive-fill-disabled`.
- Para campo com ajuda e erro prontos, use `TextField`. Para busca, `SearchField`.
- Erro também pinta o anel de foco de vermelho. Somente leitura (`readOnly`) usa `surface-secondary`. `type="file"` tem o botão estilizado em `text-link`.

## Acessibilidade

Sempre com rótulo visível; o placeholder não substitui o rótulo.

## Código

```
<Soma.Label htmlFor="email">E-mail</Soma.Label><Soma.Input id="email" type="email" />
```

---
**Usar para:** Campo de texto de uma linha (shadcn Input) e o `Label` do Radix, com a altura e a borda acessível do Campana.
**Nunca:** usar sem `Label` ou `aria-label`; para telas de produto prefira `TextField`.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
