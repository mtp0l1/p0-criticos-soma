# Popover

Balão de ajuda curta que abre ao tocar. Para o (i) da pergunta do dia e do ranking.

## O que você fornece

O gatilho (em geral um `IconButton` "info") e um texto de até três linhas.

## Especificação

- Contêiner `popover` com borda `border`, raio `radius-medium`, sombra `shadow-high`, texto `caption`. Largura 288px, sem passar da tela.
- Abre ao tocar, nunca ao passar o dedo: no celular não existe hover. Por isso não há Tooltip no sistema.
- Conteúdo é explicação, não ação. Se precisar de botão ou escolha, use `Sheet`.
- Entrada e saída animadas a partir do gatilho. `PopoverClose` fecha por um botão dentro do balão.

## Acessibilidade

Dê nome ao balão com `aria-label` no `PopoverContent` (ele é um `dialog`). Esc e toque fora fecham, foco volta ao gatilho, `aria-expanded` no gatilho.

## Código

```
<Soma.Popover><Soma.PopoverTrigger asChild><Soma.IconButton icon="info" label="Como funciona" /></Soma.PopoverTrigger><Soma.PopoverContent>…</Soma.PopoverContent></Soma.Popover>
```

---
**Usar para:** Balão de ajuda curta que abre ao tocar.
**Nunca:** guardar ação obrigatória; é só ajuda curta.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
