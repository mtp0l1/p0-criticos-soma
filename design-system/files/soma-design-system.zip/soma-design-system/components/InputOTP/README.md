Código de verificação digitado em casas separadas (shadcn InputOTP, sobre input-otp).

**Você fornece:** `maxLength`, o valor e uma `InputOTPSlot` por dígito; `invalid` nas casas quando o código estiver errado.

- Casas de 48×56px, raio `radius-medium`, borda `input`, dígito em 20px e peso 600. Casa ativa: borda `border-highlight`, anel de foco e cursor piscando.
- Erro: borda `feedback-text-negative` em todas as casas e `FieldError` embaixo, dizendo o que fazer.
- Use `inputMode="numeric"` e `autoComplete="one-time-code"`: o teclado numérico abre e o celular sugere o código do SMS. Colar preenche tudo.

**Acessibilidade:** é um único campo de texto para o leitor de tela; ligue um `Label` pelo `id`. Com movimento reduzido o cursor não pisca.

**Base técnica:** `OTPInput` cuida de foco, colagem e seleção; as casas leem o estado por `OTPInputContext`.

**React:** `<Soma.InputOTP id="otp" maxLength={6} value={v} onChange={setV} inputMode="numeric" autoComplete="one-time-code"><Soma.InputOTPGroup>{[0,1,2,3,4,5].map(i => <Soma.InputOTPSlot key={i} index={i} />)}</Soma.InputOTPGroup></Soma.InputOTP>`
