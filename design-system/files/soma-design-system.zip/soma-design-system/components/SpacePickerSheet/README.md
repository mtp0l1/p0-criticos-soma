# SpacePickerSheet

Folha "Escolha seu espaço": o espaço atual, os outros como opções e um botão que diz para qual a pessoa vai trocar.

## O que você fornece

A lista (`spaces`), o espaço atual (`current`), a escolha (`value` e `onChange`), `onConfirm` e quem abre a folha. `note` troca o aviso padrão.

## Especificação

- O atual vem primeiro, em `SpaceCard current` (selo "Seu espaço"), e não é escolhível.
- Os outros são `SpaceCard` com `onSelect`.
- Sem escolha, o botão fica desabilitado como "Trocar espaço"; com escolha, vira "Trocar para {nome}". "Cancelar" fica embaixo.
- O aviso padrão diz que a troca vale para os próximos agendamentos e que o ranking muda após a primeira entrega no novo espaço. A regra do ranking é uma proposta, ainda não confirmada.
- O protótipo também desenha os estados de carregando, falha, só um espaço e sem localização. Eles ainda não fazem parte deste componente.

## Acessibilidade

É um diálogo com o título "Escolha seu espaço". Cada opção é um botão com `aria-pressed`.

## Nas telas da v2

[Escolha seu espaço](prototipo/#867-11279), [Espaços · carregando](prototipo/#867-90001), [Espaços · falha ao carregar](prototipo/#867-90002), [Espaços · só um disponível](prototipo/#867-90003) e [Espaços · sem localização](prototipo/#867-90004).

## Código

```
<Soma.SpacePickerSheet open={aberto} onOpenChange={setAberto} spaces={espacos} current="batel" value={escolha} onChange={setEscolha} onConfirm={trocar} />
```

---
**Usar para:** trocar o espaço de recebimento da pessoa.
**Nunca:** confirmar a troca sem uma escolha, nem anunciar um espaço diferente do escolhido.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
