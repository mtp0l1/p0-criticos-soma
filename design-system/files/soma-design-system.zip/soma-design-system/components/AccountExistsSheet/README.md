Bottom sheet "O (11) 98765-4321 já tem uma conta": aparece no passo do celular quando o número já está cadastrado.

**Você fornece:** o número (`phone`) e os dois destinos: `onSignIn` ("Entrar na minha conta") e `onUseOther` ("Usar outro número"). Opcional: `open`, `onOpenChange`, `trigger`.

- Folha de fundo `surface-secondary`, raio `radius-large` no topo, **sem alça e sem X**; padding 24px em cima, 20px nos lados, 32px embaixo. Título em `body` bold, descrição "Entre na sua conta ou cadastre outro número." em `body-small`.
- Dois botões de largura total a 8px: `loud` "Entrar na minha conta" e `quiet` "Usar outro número". As duas ações fecham a folha (a saída é a alternativa real).
- A verificação do celular roda no backend **antes** de avançar.

**Acessibilidade:** mesmo comportamento do `Dialog`: foco preso, título ligado, foco volta ao gatilho.

**Figma:** Cadastro, Tela 04A (443:9656).

**React:** `<Soma.AccountExistsSheet phone="(11) 98765-4321" open={aberta} onOpenChange={setAberta} onSignIn={entrar} onUseOther={limparCelular} />`