# AccountExistsSheet

Folha "O (41) 99876-4321 já tem uma conta": aparece no passo do celular quando o número já está cadastrado.

## O que você fornece

O número (`phone`) e os dois destinos: `onSignIn` ("Entrar na minha conta") e `onUseOther` ("Usar outro número"). Opcional: `open`, `onOpenChange`, `trigger`.

## Especificação

- Folha com alça, o telefone num disco, o título e as duas saídas: "Entrar na minha conta" e "Usar outro número".

## Acessibilidade

Mesmo comportamento do `Dialog`: foco preso, título ligado, foco volta ao gatilho.

## Nas telas da v2

Cadastro: [Celular já cadastrado](prototipo/#835-6529).

## Código

```
<Soma.AccountExistsSheet phone="(11) 98765-4321" open={aberta} onOpenChange={setAberta} onSignIn={entrar} onUseOther={limparCelular} />
```

---
**Usar para:** Bottom sheet "O (41) 99876-4321 já tem uma conta": aparece no passo do celular quando o número já está cadastrado.
**Nunca:** bloquear a pessoa: as duas saídas (entrar, usar outro número) sempre aparecem.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
