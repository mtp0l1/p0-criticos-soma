Bottom sheet que acompanha o dedo e fecha ao ser arrastado para baixo (shadcn Drawer, sobre Vaul).

**Você fornece:** o gatilho, título, descrição, o conteúdo e as ações no rodapé.

- Mesmo desenho do `Sheet`: alça no topo, raio `radius-xlarge` em cima, `shadow-high`, película `overlay`, até 90% da altura.
- Use `Drawer` quando o gesto fizer parte da experiência (compartilhar, escolher local, filtros). Use `Sheet` quando fechar por engano custa caro (confirmar resgate ou doação).
- Sempre ofereça um botão para fechar ou concluir: o gesto não é a única saída.

**Acessibilidade:** é um diálogo: foco preso, Esc fecha, o foco volta ao gatilho. `DrawerTitle` é obrigatório.

**Base técnica:** Vaul sobre Radix Dialog; `shouldScaleBackground` desligado por padrão.

**React:** `<Soma.Drawer><Soma.DrawerTrigger asChild><Soma.Button hierarchy="quiet">Compartilhar</Soma.Button></Soma.DrawerTrigger><Soma.DrawerContent><Soma.DrawerHeader><Soma.DrawerTitle>Compartilhar meu impacto</Soma.DrawerTitle></Soma.DrawerHeader>…</Soma.DrawerContent></Soma.Drawer>`
