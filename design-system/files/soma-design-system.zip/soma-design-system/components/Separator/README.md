Linha divisória horizontal ou vertical, sobre Radix Separator (shadcn Separator).

**Você fornece:** a orientação.

- 1px em `border`. Separa grupos, não cada item: listas já têm divisor próprio.
- Decorativo por padrão (`decorative`); passe `decorative={false}` quando a separação tem sentido para o leitor de tela.

**React:** `<Soma.Separator />` · `<Soma.Separator orientation="vertical" />`
