Lista de opções de escolha única, como a escolha do impacto a compartilhar.

**Você fornece:** o nome do grupo, a legenda, as opções e o valor.

- Linhas de `size-touch` com rádio de 20px e texto em `body`. Sem caixa em volta; dentro de `Modal` ou de card.
- A primeira opção vem marcada quando existe um padrão sensato ("Todos").
- Para resposta de quiz, use `QuestionCard`, que tem opções em caixa.

**Acessibilidade:** `fieldset` com `legend`; rádios nativos.

**Base técnica:** Radix RadioGroup + `RadioGroupItem` com `label` em cada linha.

**React:** `<Soma.RadioList legend="Impacto para compartilhar" value={v} onChange={setV} options={opcoes} />`

---
**Usar para:** Lista de opções de escolha única, como a escolha do impacto a compartilhar.
**Nunca:** usar com mais de 5 opções (use `Select`) nem para ação imediata.
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
