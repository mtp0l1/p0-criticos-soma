# AspectRatio

Mantém a proporção de uma imagem, vídeo ou mapa enquanto a largura muda.

## O que você fornece

`ratio` (16/9, 4/3, 1) e o conteúdo, que deve preencher a área (`size-full object-cover`).

## Especificação

- Evita o salto de layout quando a imagem carrega. Combine com `rounded-lg` e `overflow-hidden`.
- Proporções do sistema: 16/9 para banner de campanha e foto de espaço, 1 para miniatura.

## Acessibilidade

Não muda a semântica; a imagem precisa de `alt` (vazio se for decorativa).

## Código

```
<Soma.AspectRatio ratio={16 / 9} className="overflow-hidden rounded-lg"><img src={foto} alt="" className="size-full object-cover" /></Soma.AspectRatio>
```

---
**Usar para:** Mantém a proporção de uma imagem, vídeo ou mapa enquanto a largura muda.
**Nunca:** usar sem proporção definida.
**Verificado por:** ACC-01 (axe, sem violação); TOK-01 e TOK-02 (só tokens).
