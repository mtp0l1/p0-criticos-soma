Mantém a proporção de uma imagem, vídeo ou mapa enquanto a largura muda (shadcn AspectRatio, sobre Radix).

**Você fornece:** `ratio` (16/9, 4/3, 1) e o conteúdo, que deve preencher a área (`size-full object-cover`).

- Evita o salto de layout quando a imagem carrega. Combine com `rounded-lg` e `overflow-hidden`.
- Proporções do app: 16/9 para banner de campanha e foto de espaço, 1 para miniatura.

**Acessibilidade:** não muda a semântica; a imagem precisa de `alt` (vazio se for decorativa).

**React:** `<Soma.AspectRatio ratio={16 / 9} className="overflow-hidden rounded-lg"><img src={foto} alt="" className="size-full object-cover" /></Soma.AspectRatio>`
