# SearchField

Campo de busca com lupa, texto e botão de limpar.

## O que você fornece

O rótulo acessível, o texto e o que acontece ao mudar e ao limpar. Sem resultado, mostre `EmptyState`.

## Especificação

- Pílula de `size-button` (56px), `radius-full`, sombra `shadow-card`, padding `space-mini`, lupa `icon-brand`, texto `text-primary`, placeholder `text-secondary`.
- Borda border (suave) e sombra `shadow-card` por padrão. `border="app"` reproduz a borda clara da produção anterior (`border-primary`, 1,27:1), que não delimita o campo para quem enxerga pouco.
- Foco: borda `interactive-border-quiet` e anel `focus-ring` de 2px.
- Limpar aparece só com texto, com área `size-touch`.

## Acessibilidade

`role="search"`; o placeholder não substitui o rótulo.

## Base técnica

Shadcn `Input` com lupa e `IconButton` posicionados por cima.

## Código

```
<Soma.SearchField label="Buscar material" value={q} onChange={setQ} />
```

---
**Usar para:** Campo de busca com lupa, texto e botão de limpar.
**Nunca:** usar como filtro de uma lista já visível sem limpar (botão de limpar é obrigatório).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
