Campo de busca com lupa, texto e botão de limpar.

**Você fornece:** o rótulo acessível, o texto e o que acontece ao mudar e ao limpar. Sem resultado, mostre `EmptyState`.

- Altura `size-input`, raio `radius-medium`, padding `space-mini`, lupa `icon-brand`, texto `text-primary`, placeholder `text-secondary`.
- Borda `border-strong` (3,98:1) por padrão. `border="app"` reproduz a borda clara da produção anterior (`border-primary`, 1,27:1), que não delimita o campo para quem enxerga pouco.
- Foco: borda `interactive-border-quiet` e anel `focus-ring` de 2px.
- Limpar aparece só com texto, com área `size-touch`.

**Acessibilidade:** `role="search"`; o placeholder não substitui o rótulo.

**Base técnica:** shadcn `Input` com lupa e `IconButton` posicionados por cima.

**React:** `<Soma.SearchField label="Buscar material" value={q} onChange={setQ} />`

---
**Usar para:** Campo de busca com lupa, texto e botão de limpar.
**Nunca:** usar como filtro de uma lista já visível sem limpar (botão de limpar é obrigatório).
**Verificado por:** ACC-01 (axe, sem violação); ACC-02 (alvo de toque de 44px); TOK-01 e TOK-02 (só tokens).
