Slides que passam por gesto, com setas e pontos (shadcn Carousel, sobre Embla).

**Você fornece:** um `label`, os `CarouselItem` e os controles que quiser (`CarouselPrevious`, `CarouselNext`, `CarouselDots`).

- Um slide por vez por padrão; `className="basis-4/5"` no item deixa o próximo aparecendo. Espaço de `space-micro` entre slides.
- Pontos: atual em `selected-indicator`, os outros em `indicator-inactive`. Setas `quiet` redondas, desabilitadas nos extremos.
- Sem avanço automático. Até cinco slides; o que é importante não fica escondido só no carrossel.

**Acessibilidade:** região "carrossel" com nome; cada slide é um grupo "slide"; setas do teclado passam os slides; os pontos dizem "Ir para o slide 2 de 3".

**React:** `<Soma.Carousel label="Novidades do programa"><Soma.CarouselContent><Soma.CarouselItem>…</Soma.CarouselItem></Soma.CarouselContent><Soma.CarouselDots /></Soma.Carousel>`
