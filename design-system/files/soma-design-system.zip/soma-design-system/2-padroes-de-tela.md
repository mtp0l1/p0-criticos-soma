# Padrões de tela

As telas do app montadas com os componentes do sistema, na ordem dos blocos. A primeira parte é a **versão atual** (telas novas do Figma "So+ma Vantagens – Pontos críticos e novos conceitos"); a segunda é a **versão anterior**, em produção, que continua valendo até cada tela migrar.

Regras comuns da versão atual: largura 360px, fundo `background-primary`, margem lateral `space-xsmall` (20px), conteúdo a `space-small` (24px) do cabeçalho, blocos a `space-small`, botão principal a `space-medium` (32px) do último bloco e nunca colado na barra. `TabBar` com Reciclar. Fluxo que termina vai para `ResultScreen` com "Ir para o início".

## Versão atual

### Reciclar (aba)

Figma: "Aba Reciclar" (478:14928).

```
├── "Reciclar" (screen-title, sem Header)
├── SectionHeader "Sua próxima entrega" → DeliveryCard state=empty | scheduled | past
├── SectionHeader "O que posso reciclar" → SearchField "Buscar um material" + ChoiceChips variant=soft scroll (Plástico · Papel · Vidro · Metal · Óleo)
├── SectionHeader "Espaços de recebimento perto de você" → SpaceCard × n (distância, horário, Como chegar)
└── TabBar active=reciclar
```

- "Agendar entrega" abre o agendamento; "Mostrar meu QR" abre o `MemberCard`. "Como chegar" abre o mapa.
- Sem "Enviar e-mail" nos cards de espaço (mapa de mudanças de 27/10).

### Agendar entrega

Figma: "escolha-espaco" (477:9296).

```
├── Header "Em qual espaço de recebimento você vai entregar?" · voltar + ajuda
├── SpaceCard onSelect × n (selecionado com borda de destaque; detalhe com endereço, horário e Como chegar)
├── SlotPicker "Escolha a data" (dias indisponíveis desabilitados)
├── SlotPicker "Escolha o horário"
├── Button loud fullWidth "Agendar entrega" (desabilitado até espaço, data e hora)
└── TabBar active=reciclar
```

- Sucesso: `Toast kind=success` "Entrega agendada para seg, 07 set" e volta à aba Reciclar com o `DeliveryCard state=scheduled`, ou `ResultScreen` quando for a primeira entrega.
- Meus agendamentos: `Header` "Meus agendamentos" + `DeliveryCard state=scheduled` por entrega, do mais próximo ao mais distante.

### Quiz

Figma: Quiz (477:20539).

```
├── Header variant=round "Quiz" · voltar + ajuda
├── SegmentedControl Quiz | Histórico
├── LevelCard + LevelBadge
├── StreakTrail (semana) + StreakProgress (marcos)
├── QuestionCard state=open | answered · points=15
├── Button quiet fullWidth icon=user-plus "Convidar amigos"
└── TabBar active=inicio
```

- Resultado da resposta em `Modal` ou `Sheet` (acertou: pontos ganhos e novo nível; errou: explica a certa). Dia protegido aparece no `StreakTrail` com escudo.
- Conquistas e introdução em `Sheet`; subir de nível em `ResultScreen` com o selo como `art`.

### Ranking

Figma: Ranking (478:10126); Telas 9, 14, 15 e 16 do mapa de mudanças.

```
├── Header variant=start "Ranking" · voltar + compartilhar
├── SegmentedControl Este mês | Últimos 12 meses
├── Tabs Amigos | Meu espaço | Geral
├── Podium (degraus)
├── RankingList → RankingRow × n (a linha "você" com self e hint "Faltam 6,5 kg para ultrapassar…")
├── Button quiet fullWidth icon=contacts "Encontrar amigos nos contatos"
└── TabBar active=impacto
```

- Encontrar amigos: `ResultScreen tone=neutral icon=contacts` pedindo a permissão (Tela 14); amigos que já participam em `RankingRow` com `Button quiet compact` "Convidar" (Tela 15); permissão negada em `ResultScreen` com "Abrir ajustes" e "Agora não" (Tela 16).
- Aba Amigos vazia: `EmptyState` com "Convidar amigos".

### Recompensas (catálogo)

Figma: home-campaign-on (477:22160).

```
├── "Recompensas" (screen-title) + PointsBadge kind=cost com o saldo
├── SegmentedControl Catálogo | Meus resgates
├── GoalCard (some se não houver meta)
├── CampaignBanner (só com campanha ativa)
├── ChoiceChips scroll com ícone (Todas · Alimentação · Casa · Educação · Sustentável · Saúde · Mercado)
├── RewardRow × n (etiquetas "2× vidro", "Sua meta atual"; "faltam X" quando o saldo não alcança)
└── TabBar active=recompensas
```

- Resgatar: detalhe → `Sheet` de confirmação ("Usar 600 pontos?") → `ResultScreen` com `RedeemCode` como `children`.
- Meus resgates: `RedemptionGroup` → `RedemptionItem` (componentes da versão anterior, sem mudança).

### Doar pontos

Figma: doação — campo vazio, valor válido e erro (478:12858, 478:12927).

```
├── Header "Doar pontos" · voltar + ajuda (fundo background-secondary)
├── InstitutionCard
├── Card outline radius-xlarge: "Quantos pontos deseja doar?" (body-strong) + "Você tem {saldo} pontos" (caption, saldo em text-link) + TextField "Quantidade de pontos" inputMode=numeric
├── Button loud fullWidth "Doar" (desabilitado até valor válido; erro se maior que o saldo)
└── TabBar active=recompensas
```

- Doação livre, sem mínimo nem máximo além do saldo. "Doar" abre `Sheet` de confirmação antes de descontar; depois `ResultScreen` "Doação feita!".

### Cadastro (um passo)

Figma: "01 · Nome e data de nascimento" (476:7330), 11 telas.

```
├── Header "Cadastro" · voltar + ajuda (sem TabBar)
├── Título do passo (page-title): "Vamos começar pelo seu nome e data de nascimento"
├── TextField × 1 ou 2 (com máscara: DD/MM/AAAA, CPF), space-small entre campos
├── Checkbox "Li e aceito o regulamento" no último passo
├── Button loud fullWidth "Continuar" (desabilitado até válido)
└── StepDots current={passo} total={7}
```

- A seta do topo é a única forma de voltar. Dúvidas abrem `Sheet` pelo (?) do cabeçalho.

### Ativação e primeira entrega

Figma: seção Ativação (22 telas).

```
├── Header · voltar
├── Escolha do espaço e da data (como em Agendar entrega)
├── MemberCard (QR) no dia da entrega
├── StatsRow (entregas · kg · pontos) depois da primeira entrega
└── ResultScreen "Primeira entrega feita!" com Compartilhar (Sheet) e "Ir para o início"
```

## Versão anterior (em produção)

### Início (anterior)

Fundo `background-primary`, margem `space-mini`, blocos a `space-medium`.

```
├── LocationBar sticky
├── "Olá, {primeiro nome}" (page-title) + IconButton ajuda
├── MissionBanner (some quando completa)
├── BalanceCard
├── SectionHeader version=anterior "Ganhe suas medalhas"
├── Button quiet fullWidth icon=star "Responda ao quiz"
├── SectionHeader "Reciclar e ganhar pontos" → TileGrid: Buscar material · Convidar amigos
├── SectionHeader "Resultado das minhas ações" → TileGrid: Meu impacto · Meu ranking de reciclagem
├── SectionHeader "Usar pontos" → TileGrid: Recompensas · Doe seus pontos
└── TabBar version=anterior active=inicio
```

- Ganhar pontos fica acima de Usar pontos e acima da dobra.
- Tocar na `LocationBar` abre um `Sheet` com os espaços de recebimento (`RadioList`) e "Confirmar local".
- Conta nova: sem local, a `LocationBar` chama para adicionar; saldo 0 mostra o caminho para a primeira entrega; Doe seus pontos leva a `Message` de saldo zero.

### Quiz (anterior)

```
├── Header "Quiz" · voltar + ajuda
├── SegmentedControl Quiz | Histórico
├── "Olá, {primeiro nome}," (section-title) + "Acerte a pergunta do dia para avançar no seu nível!" (body, text-secondary)
├── LevelCard (+ Ver níveis → LevelList)
├── QuestionCard version=anterior state=open | answered
├── Button quiet fullWidth icon=user-plus "Convidar amigos"
└── TabBar version=anterior active=inicio
```

- O (i) de "Pergunta do dia" abre um `Popover` com a regra.
- Ao enviar: `Modal` de resultado com uma ação; ao fechar, `LevelCard` já mostra o novo percentual.
- Resposta errada: explica a certa e incentiva; sem check verde.

### Meu impacto

Fundo `background-secondary`, cards `surface-primary`.

```
├── Header "Meu impacto" · voltar + ajuda
├── SectionHeader "Resumo" → StatTile layout=row "Total de entregas"
├── SectionHeader "Ranking" · Ver mais → RankingBanner
├── SectionHeader "Meu impacto" · Ver informações → StatGrid (kg, árvores, água economizada, água protegida, energia, CO2, R$, pontos doados)
├── Button transparent icon=share "Compartilhar o seu impacto" → Dialog + RadioList
└── TabBar version=anterior active=impacto
```

- Conta nova: troque os zeros por projeção ou `Message` com chamada para a primeira entrega; `RankingBanner` dá lugar a `Message`.

### Ranking (anterior)

Fundo `background-secondary`.

```
├── Header "Ranking" · voltar (volta para Meu impacto)
├── Tabs Este mês | Últimos 12 meses
├── "Ranking do seu espaço de recebimento neste mês." (caption)
├── StatTile layout=row "Você reciclou" · "{kg} kg este mês"
├── PositionCard
├── Podium version=anterior
├── IconButton info "Como é calculado o ranking?" → Popover
└── Button quiet fullWidth icon=user-plus "Convidar amigos"
```

- Sem entrega: `PositionCard position={null}`; nada de "Sua posição: Nenhuma".
- Trocar de aba mostra `Skeleton` no lugar dos cards até os dados chegarem.
- Cidade sem espaço de recebimento: `EmptyState` "Sua cidade ainda não tem ranking".

### Buscar material

```
├── LocationBar
├── "Confira o material reciclável que pode ser entregue" (page-title)
├── "Busque o material desejado ou toque em cada tipo" (body, text-secondary)
├── SearchField
├── "Foram encontrados {n} resultados para "{termo}"" (caption)
├── MaterialResult × n
└── TabBar version=anterior active=inicio
```

- Antes de buscar: categorias para tocar, nunca tela em branco. Sem resultado: `EmptyState` com "Enviar e-mail".

### Resgates

```
├── Header "Histórico de resgates" · voltar
├── RedemptionGroup "{data}" → RedemptionItem × n
└── TabBar version=anterior active=resgates
```

- Carregando: `Skeleton variant="row"` × 4. Nenhum resgate: `EmptyState` com "Ver recompensas".

### Meu cartão

```
├── Header "Meu cartão" · voltar
└── MemberCard (nome, QR) centralizado
```

### Menu

```
├── "{nome completo}" (page-title)
├── Avatar size=thumb + nome
├── ListRow menu: Meu perfil · Meu cartão · Histórico de resgates · Meu extrato de pontos · Doe seus pontos · Convidar amigos · Enviar sugestão · Ajuda · Política de privacidade · Regulamento · Sair
│     Sair → AlertDialog "Sair da sua conta?" (Continuar no app / Sair destructive)
├── "desenvolvido por so+ma" (caption)
└── TabBar version=anterior active=menu
```

### Ajuda

Lista:

```
├── Header "Ajuda" · voltar
├── SearchField "Como podemos te ajudar?"
├── ListRow help × temas (Recompensas, Quiz, Pontos, Endereços e horários, Materiais recicláveis, Cadastro, Indicar amigos, Impacto ambiental e social)
├── Dentro de um tema: Accordion com as perguntas, cada uma terminando em HelpfulVote
├── SectionHeader "Fale conosco"
└── ListRow help icon=mail "E-mail"
```

Artigo:

```
├── Header "Ajuda" · voltar
├── "{tema}" (overline, text-link)
├── "{pergunta}" (page-title)
├── Texto (body), com passos numerados quando houver
└── HelpfulVote
```

### Doar pontos (anterior)

```
├── Header "Doar meus pontos" · voltar
├── "Saldo atual: {saldo} pontos" (body)
├── ChoiceChips (valores acima do saldo desabilitados)
├── TextField "Outro valor" inputMode=numeric, erro se maior que o saldo
└── Button loud fullWidth "Doar pontos" (desabilitado até valor válido)
```

- Saldo zero: só `Message tone="caution"` "Você ainda não tem pontos para doar" com "Ver locais de entrega".

### Cadastro (anterior)

```
├── Header "{passo}" · voltar
├── Título do passo (page-title): "Agora, informe seu CPF"
├── TextField (um por passo, com máscara e inputMode); estado e cidade em Select
├── Checkbox "Li e aceito o regulamento" no último passo
├── Button loud fullWidth "Continuar" (desabilitado até válido)
└── Button transparent "Continuar depois" (só onde pular for permitido)
```

### Enviar sugestão

```
├── Header "Enviar sugestão" · voltar
├── Label + Textarea "Sua sugestão" (até 500 caracteres)
└── Button loud fullWidth "Enviar" (desabilitado com o campo vazio; loading ao enviar)
```

### Notificações

```
├── Header "Notificações" · voltar
├── Linhas com Label + Switch: Lembrete da pergunta do dia · Avisos de pontos a expirar · Novidades do programa
└── (sem botão de salvar: o Switch vale na hora)
```
