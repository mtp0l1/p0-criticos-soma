# Padrões de tela

As telas do app montadas com os componentes do sistema, na ordem dos blocos. Tudo aqui segue as telas **NOVAS** do handoff no Figma "So+ma Vantagens – Pontos críticos e novos conceitos" (canvas "🟢 HO", 438:1973). Telas marcadas ATUAL no Figma são as de produção que a nova substitui: não use seus componentes. Casos marcados PROPOSTA ainda não foram confirmados e não têm padrão aqui. A última parte lista telas que o handoff não redesenhou.

Regras comuns: largura 360px, fundo `background-primary`, margem lateral `space-xsmall` (20px), conteúdo a `space-small` (24px) do cabeçalho, blocos a `space-small`, botão principal a `space-medium` (32px) do último bloco e nunca colado na barra. `TabBar` com Início, Reciclar, Recompensas, Impacto e Menu. Fluxo que termina vai para `ResultScreen` com "Ir para o início".

### Reciclar (aba)

Figma: "Aba Reciclar" (478:14928).

```
├── "Reciclar" (screen-title, sem Header)
├── SectionHeader "Sua próxima entrega" → DeliveryCard state=empty | scheduled | past
├── SectionHeader "O que posso reciclar" → SearchField "Buscar um material" + ChoiceChips variant=soft scroll (Plástico · Papel · Vidro · Metal · Óleo)
├── SectionHeader "Espaços de recebimento perto de você" → SpaceCard × n (distância, horário, Como chegar)
└── TabBar active=reciclar
```

- "Agendar entrega" abre o agendamento; "Mostrar meu QR" abre o `QrCheckinCard`. "Como chegar" abre o mapa.
- Sem "Enviar e-mail" nos cards de espaço (mapa de mudanças de 27/10).

### Agendar entrega

Figma: "escolha-espaco" (477:9296).

```
├── Header "Em qual espaço de recebimento você vai entregar?" · voltar + ajuda
├── SpaceCard onSelect × n (selecionado com borda de destaque; detalhe com endereço, horário e Como chegar)
├── SlotPicker "Escolha a data" (dias indisponíveis desabilitados)
├── SlotPicker "Escolha o horário"
├── Button loud fullWidth "Agendar entrega" (desabilitado até espaço, data e hora)
└── TabBar active=reciclar
```

- Sucesso: `Toast kind=success` "Entrega agendada para seg, 07 set" e volta à aba Reciclar com o `DeliveryCard state=scheduled`, ou `ResultScreen` quando for a primeira entrega.
- Meus agendamentos: `Header` "Meus agendamentos" + `DeliveryCard state=scheduled` por entrega, do mais próximo ao mais distante.

### Início

Figma: "Início e navegação inferior" (443:11767); Tela 17 (443:14233).

```
├── LocationBar sticky ("Entregando em Casa so+ma Batel")
├── "Olá, {primeiro nome}" (page-title) + IconButton ajuda
├── BalanceCard (tone=dark + action "Ver meta" quando há meta; senão light)
├── GoalSummaryCard (só com meta ativa)
├── QuestionTeaser "Isopor é reciclável?" (Pergunta do dia)
├── SectionHeader "Reciclar e ganhar pontos" → TileGrid: Buscar material · Convidar amigos
├── SectionHeader "Resultado das minhas ações" → TileGrid: Meu impacto · Meu ranking de reciclagem
├── SectionHeader "Usar pontos" → TileGrid: Recompensas · Doar pontos
├── SectionHeader "Atividade recente" · Ver tudo → ActivityRow × até 3 (só com entregas)
└── TabBar active=inicio
```

- O card Pergunta do dia substituiu "Ganhe suas medalhas / Responda ao Quiz". Sem missão, sem checklist e sem nível na Home.
- "Convidar pessoas" virou "Convidar amigos".
- Tocar na `LocationBar` abre um `Sheet` com os espaços de recebimento (`RadioList`) e "Confirmar local".
- Conta nova: sem local, a `LocationBar` chama para adicionar; saldo 0 mostra o caminho para a primeira entrega; Doar pontos leva a `Message` de saldo zero.

### Quiz

Figma: seção Quiz (443:15190), Telas 1 a 8 e 3B.

```
Tela 1 · pergunta disponível (443:15355)
├── Header "Quiz" · voltar
├── LevelCard (Trophy lg + LevelBadge + "Faltam 8 perguntas para Prata")
├── StreakSection "Sua trilha"
│   ├── StreakTrail (semana, hoje com anel)
│   ├── StreakProgress (semanas, marcos 1·5·10·20)
│   ├── ProtectionNotice variant=inline "Proteção usada. Renova em 2 dias"
│   └── link "Ver histórico"
├── QuestionCard points=15 (opções "a) …")
└── TabBar active=inicio
```

```
Telas 2A e 2B · resultado (tela cheia, TabBar visível) (443:15518, 443:15852)
└── AnswerResult correct | errou · mascote da lata · onContinue · secondary "Convidar amigos" | "Volte amanhã para a próxima pergunta"

Tela 3 · já respondeu (3B: com dia protegido) (443:15595)
├── Header "Quiz" · voltar
├── LevelCard
├── StreakSection com hoje feito (today: true)
└── DailyDone countdown="14h 15m"

Tela 4 · histórico (443:15739)
├── Cabeçalho "Histórico" (seta + título)
├── HistorySummary (Trophy md + LevelBadge + totais)
└── AnswerHistory "Histórico de respostas" (mês) → AnswerHistoryRow × n

Tela 5 · "Campeão da Reciclagem" (443:15921)
├── Header "Quiz" · voltar
├── TierCard × 3 (Bronze · Prata · Ouro), cada um com seu fundo e contorno
├── ProtectionNotice variant=card onInfo → Sheet "Como funciona a sequência" (Tela 6)
└── Button loud "Começar"

Tela 6 · Sheet "Como funciona a sequência" (443:16021)
└── Proteção da semana · Quando a sequência quebra · Prêmios por constância · Button "Entendi"

Telas 7 e 8 · conquista de semanas (443:16142, 443:16224)
└── MilestoneResult weeks=1 | 5 (10 e 20 seguem o mesmo molde)
```

- Os níveis são **troféus** ilustrados (`Trophy`): Bronze com 1 estrela, Prata com 2 e Ouro com 3. Não existe mais medalha no app. As ilustrações estão em `6-ilustracoes.md`.
- A sequência conta em **semanas**; marcos de 1, 5, 10 e 20 semanas dão 100, 500, 1.000 e 2.000 pontos. A proteção semanal cobre um dia perdido (escudo no `StreakTrail`).
- Só existem três níveis: Bronze (Iniciante, 5 perguntas), Prata (Intermediário, 15) e Ouro (Avançado, 50).
- O (i) de "Pergunta do dia" abre um `Popover` com a regra (opcional: `info`).
- Errou: explica a resposta certa e incentiva, sem culpa.
- Casos PROPOSTA (A1 a C3: sequência zerada, subida de nível, sem pergunta, falha ao enviar, permissão de aviso, horário, fuso) aguardam confirmação com Claudia e Tatiana.

### Ranking

Figma: seção Ranking & Social (443:18079 a 443:18823), Telas 1 a 3 e 9 a 16.

```
├── Header variant=start "Ranking" · voltar + compartilhar
├── SegmentedControl Este mês | Últimos 12 meses
├── Tabs Amigos | Meu espaço | Geral
├── FriendRequestBanner (aba Amigos, quando há pedido)
├── Podium (Geral: anonymous, sem nome nem foto)
├── PositionCard percent={80} (só na aba Geral)
├── RankingList → RankingRow × n (a linha "você" com self e hint "Faltam 6,5 kg para ultrapassar…")
├── Button quiet fullWidth icon=contacts "Encontrar amigos nos contatos"
└── TabBar active=impacto
```

- Convidar amigos (Tela 9): `InviteCodeCard` com o código e o link; quem convida e quem aceita ganham 100 pontos. Digitar o código do amigo (Tela 11): `TextField` + "Enviar pedido"; depois `ResultScreen` "Pedido enviado!" (Tela 12). Pedido enviado não é amizade: o amigo precisa aceitar.
- Encontrar amigos: `ResultScreen tone=neutral icon=contacts` pedindo a permissão (Tela 14); amigos que já participam em `ContactRow` com "Convidar", que vira "Convite enviado" (Tela 15); permissão negada em `ResultScreen` com "Abrir ajustes" e "Agora não" (Tela 16).
- Aba Amigos vazia: `EmptyState` com "Convidar amigos". Trocar de aba mostra `Skeleton` até os dados chegarem.
- Ranking é individual (por CPF): fale em "participantes". O Geral nunca mostra nome nem foto de ninguém. Sem entrega: `PositionCard percent={null}`.
- O ranking ganhou tela própria: "Meu ranking de reciclagem" na Home leva direto a ele. Como Meu impacto aponta para o Ranking ainda não está fechado no handoff.

### Recompensas (catálogo)

Figma: seção Recompensas (443:17044 e seguintes), Telas 1, V1, 5, 9, 18 a 23.

```
├── "Recompensas" (screen-title) + PointsBadge kind=cost com o saldo
├── SegmentedControl Catálogo | Meus resgates
├── GoalCard "Minha Meta" (320 / 800 pontos, "faltam 480 pontos", "≈ 24 kg de recicláveis")
├── CampaignBanner (só com campanha ativa: "Vidro vale 2× pontos até sexta-feira")
├── ChoiceChips scroll com ícone (Alimentação · Casa e limpeza · Educação · Jardinagem · Saúde e bem-estar · Varejo)
├── Por categoria: SectionHeader "{categoria}" · Ver todas (12) → RewardRow × n
└── TabBar active=recompensas
```

- Detalhe (Tela 18): `RewardDetail` com "De onde vêm os pontos" e o botão fixo "Definir como minha meta" (Tela 19: `ResultScreen` "Nova meta definida!"). Sem saldo, o botão diz "Faltam 480 pontos" (V2).
- Meta atingida (Tela 5): o `GoalCard` mostra "Meta atingida! Pronta para troca"; o detalhe tem "Trocar recompensa" (Tela 20), que gera o código.
- Código (Tela 21): `RedeemCode`; os pontos já foram descontados. Depois, `ResultScreen` "Recompensa resgatada!" com "Escolher próxima meta" (Tela 22).
- Categoria (Tela 23): `Header` "Categoria · Alimentação e Gastronomia", "8 itens disponíveis", `CampaignBanner` e `RewardRow` × n.
- Meus resgates: `RedemptionGroup` → `RedemptionItem` com status Disponível, Usado ou Vencido.
- Casos PROPOSTA de Recompensas (A a C) aguardam confirmação.

### Doar pontos

Figma: doação — campo vazio, valor válido e erro (478:12858, 478:12927).

```
├── Header "Doar pontos" · voltar + ajuda (fundo background-secondary)
├── InstitutionCard
├── Card outline radius-xlarge: "Quantos pontos deseja doar?" (body-strong) + "Você tem {saldo} pontos" (caption, saldo em text-link) + TextField "Quantidade de pontos" inputMode=numeric
├── Button loud fullWidth "Doar" (desabilitado até valor válido; erro se maior que o saldo)
└── TabBar active=recompensas
```

- Doação livre, sem mínimo nem máximo além do saldo. "Doar" abre `Sheet` de confirmação antes de descontar; depois `ResultScreen` "Doação feita!".

### Cadastro (um passo)

Figma: "01 · Nome e data de nascimento" (476:7330), 11 telas.

```
├── Header "Cadastro" · voltar + ajuda (sem TabBar)
├── Título do passo (page-title): "Vamos começar pelo seu nome e data de nascimento"
├── TextField × 1 ou 2 (com máscara: DD/MM/AAAA, CPF), space-small entre campos
├── Checkbox "Li e aceito o regulamento" no último passo
├── Button loud fullWidth "Continuar" (desabilitado até válido)
└── StepDots current={passo} total={7}
```

- A seta do topo é a única forma de voltar. Dúvidas abrem `Sheet` pelo (?) do cabeçalho.

### Ativação e primeira entrega

Figma: seção Ativação (22 telas).

```
├── Header · voltar
├── Escolha do espaço e da data (como em Agendar entrega)
├── QrCheckinCard (QR) no dia da entrega (Tela 11)
├── Entrega registrada (Tela 12): ImpactTiles (kg · pontos ganhos · água economizada) + nota "Sua meta"
└── ResultScreen "Primeira entrega feita!" com Compartilhar (Sheet) e "Ir para o início"
```

## Telas que o handoff não redesenhou

Seguem como estão no app, só que com a barra inferior nova. Os componentes são os mesmos do resto do sistema.

### Meu impacto

Fundo `background-secondary`, cards `surface-primary`.

```
├── Header "Meu impacto" · voltar + ajuda
├── SectionHeader "Resumo" → StatTile layout=row "Total de entregas"
├── SectionHeader "Ranking" · Ver mais → ListRow "Meu ranking de reciclagem" (acesso ao Ranking ainda por fechar no handoff)
├── SectionHeader "Meu impacto" · Ver informações → StatGrid (kg, árvores, água economizada, água protegida, energia, CO2, R$, pontos doados)
├── Button transparent icon=share "Compartilhar o seu impacto" → Dialog + RadioList
└── TabBar active=impacto
```

- Conta nova: troque os zeros por projeção ou `Message` com chamada para a primeira entrega.

### Buscar material

```
├── LocationBar
├── "Confira o material reciclável que pode ser entregue" (page-title)
├── "Busque o material desejado ou toque em cada tipo" (body, text-secondary)
├── SearchField
├── "Foram encontrados {n} resultados para "{termo}"" (caption)
├── MaterialResult × n
└── TabBar active=inicio
```

- Antes de buscar: categorias para tocar, nunca tela em branco. Sem resultado: `EmptyState` com "Enviar e-mail".

### Menu

```
├── "{nome completo}" (page-title)
├── Avatar size=thumb + nome
├── ListRow menu: Meu perfil · Meu QR · Meus resgates · Meu extrato de pontos · Doe seus pontos · Convidar amigos · Enviar sugestão · Ajuda · Política de privacidade · Regulamento · Sair
│     Sair → AlertDialog "Sair da sua conta?" (Continuar no app / Sair destructive)
├── "desenvolvido por so+ma" (caption)
└── TabBar active=menu
```

### Ajuda

Lista:

```
├── Header "Ajuda" · voltar
├── SearchField "Como podemos te ajudar?"
├── ListRow help × temas (Recompensas, Quiz, Pontos, Endereços e horários, Materiais recicláveis, Cadastro, Indicar amigos, Impacto ambiental e social)
├── Dentro de um tema: Accordion com as perguntas, cada uma terminando em HelpfulVote
├── SectionHeader "Fale conosco"
└── ListRow help icon=mail "E-mail"
```

Artigo:

```
├── Header "Ajuda" · voltar
├── "{tema}" (overline, text-link)
├── "{pergunta}" (page-title)
├── Texto (body), com passos numerados quando houver
└── HelpfulVote
```

### Enviar sugestão

```
├── Header "Enviar sugestão" · voltar
├── Label + Textarea "Sua sugestão" (até 500 caracteres)
└── Button loud fullWidth "Enviar" (desabilitado com o campo vazio; loading ao enviar)
```

### Notificações

```
├── Header "Notificações" · voltar
├── Linhas com Label + Switch: Lembrete da pergunta do dia · Avisos de pontos a expirar · Novidades do programa
└── (sem botão de salvar: o Switch vale na hora)
```
