# Padrões de tela

Telas de referência montadas com núcleo e módulos, na ordem dos blocos.

## Visão geral

Telas de referência montadas com os componentes do sistema, na ordem dos blocos. Elas vêm do primeiro produto do ecossistema e mostram como núcleo e módulos se encaixam; um produto novo usa os mesmos padrões com o seu próprio conteúdo. Tudo aqui segue as telas da versão 2 do app, a referência oficial (Padrões › Telas da v2). Telas marcadas ATUAL no Figma são as de produção que a v2 substitui: não use seus componentes. Casos marcados PROPOSTA ainda não foram confirmados e não têm padrão aqui. A última parte lista telas que o handoff não redesenhou.

Regras comuns: largura de referência 390px (vale de 360 a 430px), fundo `background-primary`, margem lateral `space-xsmall` (20px), conteúdo a `space-small` (24px) do cabeçalho, blocos a `space-small`, botão principal a `space-medium` (32px) do último bloco e nunca colado na barra. `TabBar` com Início, Reciclar, Recompensas, Impacto e Menu. Fluxo que termina vai para `ResultScreen` com "Ir para o início".

### Reciclar (aba)

Telas da v2: "Aba Reciclar".

```
├── "Reciclar" (screen-title, sem Header)
├── SectionHeader "Sua próxima entrega" → DeliveryCard state=empty | scheduled | past (texto e botão, sem ícone)
├── SectionHeader "O que posso reciclar" → SearchField "Buscar um material" + ChoiceChips variant=soft scroll (Plástico · Papel · Vidro · Metal · Óleo)
├── SectionHeader "Espaços de recebimento perto de você" → SpaceCard × n (distância, horário, Como chegar)
└── TabBar active=reciclar

```

- "Agendar entrega" abre o agendamento; "Mostrar meu QR" abre o `QrCheckinCard`. "Como chegar" abre o mapa.
- No Figma as duas variantes do card aparecem lado a lado, com os rótulos "Variante A" e "Variante B": é só anotação. No produto é um card em largura total, conforme haja ou não entrega agendada. Pendente no handoff: card quando a data da entrega já passou (`state="past"` é proposta do DS).
- O card do espaço mostra nome, distância, horário e "Como chegar"; não mostra endereço (ele aparece na escolha do agendamento).
- Sem "Enviar e-mail" nos cards de espaço (mapa de mudanças de 27/10).

### Agendar entrega

Telas da v2: "Escolha do espaço".

```
├── Header "Em qual espaço de recebimento você vai entregar?" · voltar + ajuda
├── SpaceCard onSelect × n (selecionado com borda de destaque; detalhe com endereço, horário e Como chegar)
├── SlotPicker "Escolha a data" (dias indisponíveis desabilitados)
├── SlotPicker "Escolha o horário"
├── Button loud fullWidth "Agendar entrega" (desabilitado até espaço, data e hora)
└── TabBar active=reciclar

```

- Sucesso: `Toast kind=success` "Entrega agendada para seg, 07 set" e volta à aba Reciclar com o `DeliveryCard state=scheduled`, ou `ResultScreen` quando for a primeira entrega.
- Meus agendamentos: `Header` "Meus agendamentos" + `DeliveryCard state=scheduled` por entrega, do mais próximo ao mais distante.

### Início

Telas da v2: "Início e navegação inferior": Início · depois, barra inferior e Início pós-entrega.

```
├── LocationBar sticky (uma linha: "Entregando em Casa so+ma Batel")
├── HomeGreeting "Olá {primeiro nome}" + botão QR + ajuda
├── BalanceCard (tone=light, 104px; com meta ativa: tone=dark + "Ver meta", Tela 17)
├── GoalSummaryCard (só com meta ativa)
├── SectionHeader "Reciclar e ganhar pontos" → TileGrid: Buscar material · Convidar amigos
├── SectionHeader "Pergunta do dia" → QuestionTeaser "Isopor é reciclável?"
├── SectionHeader "Resultado das minhas ações" → TileGrid: Meu impacto · Meu ranking de reciclagem
├── SectionHeader "Usar pontos" → TileGrid: Recompensas · Doar pontos
├── SectionHeader "Atividade recente" · Ver tudo → ActivityRow × até 3 (só com entregas)
└── TabBar active=inicio

```

- Ordem do Figma: **Reciclar e ganhar pontos sobe para logo depois do saldo**, antes da Pergunta do dia (Feedback 13). A "Atividade recente" e a meta só aparecem em contas com entrega (Tela 17).
- Blocos a 24px; título do bloco a 8px do conteúdo; entre a saudação e o saldo, 8px. Tiles de 80px com 16px entre eles.
- A saudação é "Olá Mônica" (sem vírgula). O botão redondo ao lado do nome abre o cartão QR; a ajuda fica à direita.
- O card Pergunta do dia substituiu "Ganhe suas medalhas / Responda ao Quiz". Sem missão, sem checklist e sem nível na Home. Pendente no handoff: onde fica a trilha completa do Quiz depois do Início.
- "Convidar pessoas" virou "Convidar amigos", igual ao Ranking. Adote em todo o produto.
- Tocar na `LocationBar` abre um `Sheet` com os espaços de recebimento (`RadioList`) e "Confirmar local".
- Conta nova: sem local, a `LocationBar` chama para adicionar; saldo 0 mostra o caminho para a primeira entrega; Doar pontos leva a `Message` de saldo zero.

### Quiz

Telas da v2: seção Quiz, Telas 1 a 8 e 3B.

```
Tela 1 · pergunta disponível
├── Header "Quiz" · voltar
├── LevelCard (Trophy lg + LevelBadge + "Faltam 8 perguntas para Prata")
├── StreakSection "Sua trilha"
│   ├── StreakTrail (semana, hoje com anel)
│   ├── StreakProgress (semanas, marcos 1·5·10·20)
│   ├── ProtectionNotice variant=inline "Proteção usada. Renova em 2 dias"
│   └── link "Ver histórico"
├── QuestionCard points=15 (opções "a) …")
└── TabBar active=inicio

```

```
Telas 2A e 2B · resultado (tela cheia, TabBar visível)
└── AnswerResult correct | errou · mascote da lata · onContinue · secondary "Convidar amigos" | "Volte amanhã para a próxima pergunta"

Tela 3 · já respondeu (3B: com dia protegido)
├── Header "Quiz" · voltar
├── LevelCard
├── StreakSection com hoje feito (today: true)
└── DailyDone countdown="14h 15m"

Tela 4 · histórico
├── Cabeçalho "Histórico" (seta + título)
├── HistorySummary (Trophy md + LevelBadge + totais)
└── AnswerHistory "Histórico de respostas" (mês) → AnswerHistoryRow × n

Tela 5 · "Campeão da Reciclagem"
├── Header "Quiz" · voltar
├── TierCard × 3 (Bronze · Prata · Ouro), cada um com seu fundo e contorno
├── ProtectionNotice variant=card onInfo → Sheet "Como funciona a sequência" (Tela 6)
└── Button loud "Começar"

Tela 6 · Sheet "Como funciona a sequência"
└── Proteção da semana · Quando a sequência quebra · Prêmios por constância · Button "Entendi"

Telas 7 e 8 · conquista de semanas
└── MilestoneResult weeks=1 | 5 (10 e 20 seguem o mesmo molde)

```

- Os níveis são **troféus** ilustrados (`Trophy`): Bronze com 1 estrela, Prata com 2 e Ouro com 3. Não existe mais medalha no produto. As ilustrações estão em `6-ilustracoes.md`.
- A sequência conta em **semanas**; marcos de 1, 5, 10 e 20 semanas dão 100, 500, 1.000 e 2.000 pontos. A proteção semanal cobre um dia perdido (escudo no `StreakTrail`).
- Só existem três níveis: Bronze (Iniciante, 5 perguntas), Prata (Intermediário, 15) e Ouro (Avançado, 50).
- O (i) de "Pergunta do dia" abre um `Popover` com a regra (opcional: `info`).
- Errou: explica a resposta certa e incentiva, sem culpa.
- Casos PROPOSTA (A1 a C3: sequência zerada, subida de nível, sem pergunta, falha ao enviar, permissão de aviso, horário, fuso) aguardam confirmação com Claudia e Tatiana.

### Ranking

Telas da v2: seção Ranking & Social, Telas 1 a 16. Valem as telas NOVO; a Tela 9V substitui a 9 (versão vigente). Casos PROPOSTA (Casos de uso, Ranking A a D) ficam de fora.

```
├── Header start "Ranking": voltar + (aba Amigos) ícone user-plus que abre Adicionar amigo (Tela 11)
├── SegmentedControl Este mês | Últimos 12 meses
├── Tabs Amigos | Meu espaço | Geral
├── legenda em caption: "Ranking com quem você convidou ou adicionou por código." (Amigos) · "Espaço da sua última entrega: Vila Verde" (Meu espaço) · nenhuma no Geral
├── Podium (só com 3 ou mais participantes; Geral: anonymous)
├── PositionCard percent={80} (só na aba Geral)
├── RankingList → RankingRow × n ("#4"; a linha "você" com self, initials e hint "Faltam 6,5 kg para ultrapassar Carlos Lima")
├── RankingStarterCard (0 kg no período, abaixo da lista)
└── TabBar active=impacto

```

- **Estados** da mesma tela: Amigos vazio (Tela 8: `EmptyState artFrame={false}` com `ranking-vazio`, "Convidar amigos" e `secondaryAction` "Adicionar amigo por código"); Meu espaço antes da 1ª entrega (Tela 6: `EmptyState artFrame="rect"` com `building` e "Agendar primeira entrega"); lista sem pódio com menos de 3 participantes (Tela 7).
- **Avisos** no topo (`Toast surface="card"`): "Você subiu 3 posições no ranking de amigos!" ao reabrir (Tela 5) e "Ana Souza entrou no seu ranking de amigos!" (Tela 10). Pendente no handoff: quando disparam e se há notificação.
- **Pedido recebido** (Tela 13): `FriendRequestSheet` abre ao entrar no Ranking. Pendente: o que acontece em "Agora não" e se o pedido expira.
- **Convidar amigos** (Tela 9V): `Illustration convite-pontos`, título "Convide amigos e vocês ganham 100 pontos cada um", `InviteCodeCard` (código em cartão com Copiar), "Compartilhar convite" (`loud`) e "Encontrar amigos nos contatos" (`quiet`). Os dois ganham quando o amigo faz a primeira entrega.
- **Adicionar amigo** (Tela 11): `TextField` "Código do amigo" com "Ex.: REC7X4KP" e "Enviar pedido" desabilitado até digitar; depois `ResultScreen ringSize="sm" actionsPlacement="inline"` "Pedido enviado!" (Tela 12) com "Voltar ao ranking". Pedido enviado não é amizade: o amigo precisa aceitar. Pendente: mensagens para código inválido, repetido ou o próprio código.
- **Encontrar amigos pelos contatos**: `ResultScreen tone="neutral" icon="contacts" ringSize="md" actionsPlacement="inline"` pedindo a permissão (Tela 14, "Permitir acesso aos contatos" + link "Agora não"); `ContactRow` com "Convidar", que vira "Convite enviado", e "Convidar quem ainda não participa" (Tela 15); permissão negada com a mesma estrutura, "Sem acesso aos contatos", "Permitir acesso aos contatos" e link "Voltar ao ranking" (Tela 16). O código de convite segue disponível.
- Ranking é individual (por CPF): fale em "participantes". O Geral nunca mostra nome nem foto de ninguém. Sem entrega: `PositionCard percent={null}` (extrapolação do sistema; o handoff só mostra o `RankingStarterCard` no Amigos).
- O ranking ganhou tela própria: "Meu ranking de reciclagem" na Home leva direto a ele. Como Meu impacto aponta para o Ranking ainda não está fechado no handoff.

### Recompensas (catálogo)

Telas da v2: seção Recompensas, Telas 1, V1, 5, 9, 17 a 23.

```
├── Header (título "Recompensas", sem PointsBadge)
├── PillTabs Catálogo | Meus resgates
├── GoalCard "Minha meta" (320 / 800 pontos, "faltam 480 pontos", "≈ 24 kg de recicláveis")
├── CampaignBanner (só com campanha ativa: faixa de uma linha, "Vidro vale 2× pontos até sexta-feira")
├── ChoiceChips scroll com ícone (Alimentação · Casa e limpeza · Educação · Jardinagem · Saúde e bem-estar · Varejo)
├── Por categoria: SectionHeader size="small" icon + "Ver todas (12)" → RewardRow × n (sem miniatura)
└── TabBar active=recompensas

```

- Detalhe (Tela 18): `RewardDetail` com "De onde vêm os pontos" e o botão fixo "Definir como minha meta". Tela 19: `ResultScreen` neutra, ícone `crosshair`, "Meta definida!", ações inline ("Ver catálogo" e link "Voltar ao início"). Sem saldo, o botão diz "Faltam 480 pontos" (V2).
- `GoalCard` tocável (Tela 5): abre o detalhe, onde fica "Trocar recompensa". Não há botão "Trocar meta" dentro do card.
- Meta atingida (Tela 5): o `GoalCard` mostra check e "Meta atingida! Pronta para troca."; o detalhe tem "Trocar recompensa" (Tela 20), que gera o código.
- Código (Tela 21): `RedeemCode` (código 26px, borda tracejada de 2px); os pontos já foram descontados. Depois, `ResultScreen` positiva, ícone `gift`, "Recompensa resgatada!" (Tela 22), com "Ver código" e link "Voltar ao início".
- Categoria (Tela 23): `Header` "Categoria · Alimentação e Gastronomia", "8 itens disponíveis", `CampaignBanner` e `RewardRow` × n.
- Linha do catálogo: título, pontos em `text-link` e seta; `current` marca "Sua meta atual" com borda de destaque. Prêmios acima do saldo aparecem iguais, sem "falta X".
- Meus resgates: `RedemptionGroup` → `RedemptionItem` com status Disponível, Usado ou Vencido. Não há tela NOVO desenhada para essa aba.
- Em aberto no handoff: link "Ver em Meus resgates" da Tela 21 (a nota diz que existe, não está desenhado); confirmação antes de descontar pontos; trocar a meta com mais de 50% de progresso (PROPOSTA).
- Casos PROPOSTA de Recompensas (A a C) aguardam confirmação.

### Doar pontos

Telas da v2: seção "Doar pontos". Fluxo: **lista de instituições → doação → sucesso**. Cada etapa tem voltar; o sucesso não tem (sair por "Ir para o início" ou pela barra inferior).

**Lista**

```
├── Header "Doar pontos" · voltar + ajuda
├── "Escolha para quem você quer doar seus pontos" (screen-title)
├── InstitutionRow × 7 (8px entre eles)
└── TabBar active=recompensas

```

**Doação (vazio, zero, acima do saldo, válido)**

```
├── Header "Doar pontos" · voltar + ajuda (fundo background-secondary)
├── InstitutionCard (foto, nome, causa, "Saber mais" → InstitutionDetailModal)
├── DonationAmountCard: "Quantos pontos deseja doar?" + "Você tem {saldo} pontos" + TextField numérico
├── Button loud fullWidth "Doar", 32px abaixo do cartão (segue o conteúdo, não prende no fim da tela)
└── TabBar active=recompensas

```

- Blocos a 20px (`space-xsmall`). "Doar" desabilitado com campo vazio, zero ou acima do saldo (`donationError`).
- Doação livre, sem mínimo nem máximo (decisão da Tati e do Marco). Só inteiros: teclado numérico, sem decimais, sinal nem texto colado.
- Os pontos só saem do saldo quando o servidor confirma.

**Sem saldo e pontos insuficientes:** o `DonationStateCard` toma o lugar do campo (blocos a 24px, `space-small`) e o botão vira a saída: "Fazer minha primeira entrega" ou "Fazer uma entrega".

**Sucesso:** `ResultScreen tone="neutral"` com check em círculo de 48px (`ringSize="xs"`), "Doação realizada!", "Seus 500 pontos foram enviados para a {instituição}", ilustração `doar-sucesso`, "Ir para o início" em `loud` e `TabBar active=inicio`. Sem cabeçalho.

- Em aberto no handoff: oferecer "Compartilhar" ou "Ver meu impacto" depois da doação (o Figma lista como pendência).
- PROPOSTA (Doar A a E), aguardam confirmação com Claudia e Tatiana: `Sheet` de confirmação antes de descontar, e demais casos de uso.

### Cadastro (um passo)

Telas da v2: seção "Cadastro". **Sete passos, um dado por tela**, sem indicador de progresso. Substitui o cadastro atual, que pedia tudo de uma vez.

```
└── SignupStep icon={…} onBack onHelp   (topo com Voltar e Ajuda; sem Header, sem TabBar e sem indicador de progresso)
    ├── Tile de ícone + título do passo (page-title) + linha de apoio (body-small)
    ├── TextField / PasswordField / InviteCodeField (campos do mesmo bloco a 8px)
    └── Button loud fullWidth "Continuar"  (fixo no pé da tela, desabilitado até válido)

```

| Passo | Título | Campo | Observação |
|---|---|---|---|
| 01 | Vamos começar pelo seu nome e data de nascimento | Nome e Sobrenome_, Data de nascimento_ | Dois campos a 24px |
| 02 | Agora, informe seu CPF | CPF (`mask="cpf"`) | Ajuda "Digite seu CPF para continuar"; CPF vazio bloqueia o avanço em todos os ambientes |
| 03 | Qual e-mail você quer usar? | Email* (`inputMode="email"`) | "Vamos usar esse e-mail para falar com você." |
| 04 | Qual é o seu celular? | Celular* (`mask="phone"`) | Número já cadastrado abre `AccountExistsSheet` (04A) |
| 05 | Crie sua senha | `PasswordField` × 2 (Senha_, Repita a senha_) | A confirmação precisa ser igual; "Use 6 números." |
| 06 | Qual é o seu CEP? | CEP* (`mask="cep"`) | Com 8 dígitos: `NeighborhoodNote` e Continuar ativo |
| 07 | Alguém te convidou? | `InviteCodeField` + `TermsConsent` | Botão "Criar minha conta"; "Onde encontro o código?" abre `InviteCodeHelpSheet` (07B) |

- A seta do topo é a única forma de voltar: retorna ao passo anterior e mantém o que já foi preenchido. Não há botão "Voltar" no corpo.
- Erros curtos, embaixo do campo, sem apagar o que a pessoa digitou. Código de convite é opcional; "Criar minha conta" só fica ativo com o aceite do regulamento.
- Depois que a conta é criada a pessoa não volta ao formulário: o fim do fluxo é o `ResultScreen` "Cadastro concluído" (Ativação, Tela 24).
- Em aberto no handoff: mensagens para código inválido ou expirado; possível quadro duplicado do CPF em Pontos críticos (aguarda a Claudia); o botão "Aplicar" do código não está desenhado.

### Ativação e primeira entrega

Telas da v2: seção Ativação. Cada tela abaixo tem um exemplo na página "Telas de exemplo".

```
Cadastro concluído (Tela 24)
└── ResultScreen tone="neutral" icon="check" ringOutline actionsPlacement="inline"
    primaryAction "Definir minha meta" · onHome "Ir para o início"

Escolha da meta (Telas 25 e 26)
├── Header · voltar + ajuda
├── h1 screen-title "Qual recompensa você quer conquistar?" + texto
├── RewardChoiceList (cards de opção; sem estoque: "Indisponível no momento")
├── GoalProgressCard (80 / 800 pontos · "Faltam 36 kg de recicláveis")
└── Button "Definir como meta"

Agendar (Telas 27 e 30)
├── Header (center, título em até três linhas, sem divisor) "Em qual espaço de recebimento você vai entregar?" · voltar + ajuda
├── SectionHeader size="eyebrow" "Escolha o espaço" → SpaceCard onSelect × n → SpaceDetail do escolhido (depois da lista)
├── SlotPicker "Escolha a data" (dia sem vaga em cinza, sem risco) · SlotPicker "Escolha o horário"
└── Button "Agendar entrega" (desabilitado até escolher espaço, data e horário)

Confirmação (Telas 6, 28 e 29)
└── ResultScreen tone="neutral" icon="calendar-check" iconShape="square" titleSize="screen" actionsPlacement="inline"
    ├── DeliverySummaryCard (Quando · Onde · Horário · Aviso depois de salvar)
    ├── primaryAction "Adicionar ao calendário" → done "Adicionado ao calendário"
    └── extraLink "Ver meus agendamentos" + onHome "Ir para o início"
    Erro (Tela 29): "Não conseguimos adicionar ao calendário", ação "Tentar novamente"

Meus agendamentos (Tela 7)
├── Header variant="start" · voltar
├── SectionHeader size="eyebrow" "Próximas entregas" → DeliverySummaryCard + Button quiet "Adicionar ao calendário"
└── SectionHeader size="eyebrow" "Entregas anteriores" → DeliveryHistoryRow

Dia da entrega (Telas 31 e 11)
├── DeliveryDayCard + Button quiet "Como chegar" + Button "Cheguei ao espaço"
└── Header variant="eyebrow" "Vila Verde" + QrCheckinCard (QR de 200px; peça para aumentar o brilho)

Entrega registrada (Telas 12 a 16)
├── título com check de 32px + subtítulo
├── ImpactTiles (kg · pontos ganhos · água) com Compartilhar → ShareImpactModal (Tela 16)
├── GoalNote "Sua meta" (só quem tem meta)
├── ReminderCard (data abre Sheet com Data e Horário; sucesso e erro por notify)
└── Button transparent "Ir para o início"

Início depois da entrega (Tela 17)
├── HomeGreeting · GoalSummaryCard · BalanceCard tone="dark" action "Ver meta"
└── SectionHeader size="eyebrow" "Atividade recente" → ActivityRow action "Ver recibo"

```

- Tela 6A é o e-mail de confirmação (template com variáveis). Não é tela do produto e não tem componente.
- O produto não acompanha se a entrega aconteceu: não existe estado "perdida" em Meus agendamentos, e o evento do calendário não é recorrente.
- A confete da Tela 12 é a ilustração `confete-entrega` (em `assets/illustrations/`, não embutida no bundle).

## Telas que o handoff não redesenhou

Seguem como estão no produto, só que com a barra inferior nova. Os componentes são os mesmos do resto do sistema.

### Meu impacto

Fundo `background-secondary`, cards `surface-primary`.

```
├── Header "Meu impacto" · voltar + ajuda
├── SectionHeader "Resumo" → StatTile layout=row "Total de entregas"
├── SectionHeader "Ranking" · Ver mais → ListRow "Meu ranking de reciclagem" (acesso ao Ranking ainda por fechar no handoff)
├── SectionHeader "Meu impacto" · Ver informações → StatGrid (kg, árvores, água economizada, água protegida, energia, CO2, R$, pontos doados)
├── Button transparent icon=share "Compartilhar o seu impacto" → Dialog + RadioList
└── TabBar active=impacto

```

- Conta nova: troque os zeros por projeção ou `Message` com chamada para a primeira entrega.

### Buscar material

```
├── LocationBar
├── "Confira o material reciclável que pode ser entregue" (page-title)
├── "Busque o material desejado ou toque em cada tipo" (body, text-secondary)
├── SearchField
├── "Foram encontrados {n} resultados para "{termo}"" (caption)
├── MaterialResult × n
└── TabBar active=inicio

```

- Antes de buscar: categorias para tocar, nunca tela em branco. Sem resultado: `EmptyState` com "Enviar e-mail".

### Menu

```
├── "{nome completo}" (page-title)
├── Avatar size=thumb + nome
├── ListRow menu: Meu perfil · Meu QR · Meus resgates · Meu extrato de pontos · Doe seus pontos · Convidar amigos · Enviar sugestão · Ajuda · Política de privacidade · Regulamento · Sair
│     Sair → AlertDialog "Sair da sua conta?" (Continuar no app / Sair destructive)
├── "desenvolvido por so+ma" (caption)
└── TabBar active=menu

```

### Ajuda

Lista:

```
├── Header "Ajuda" · voltar
├── SearchField "Como podemos te ajudar?"
├── ListRow help × temas (Recompensas, Quiz, Pontos, Endereços e horários, Materiais recicláveis, Cadastro, Indicar amigos, Impacto ambiental e social)
├── Dentro de um tema: Accordion com as perguntas, cada uma terminando em HelpfulVote
├── SectionHeader "Fale conosco"
└── ListRow help icon=mail "E-mail"

```

Artigo:

```
├── Header "Ajuda" · voltar
├── "{tema}" (overline, text-link)
├── "{pergunta}" (page-title)
├── Texto (body), com passos numerados quando houver
└── HelpfulVote

```

### Enviar sugestão

```
├── Header "Enviar sugestão" · voltar
├── Label + Textarea "Sua sugestão" (até 500 caracteres)
└── Button loud fullWidth "Enviar" (desabilitado com o campo vazio; loading ao enviar)

```

### Notificações

```
├── Header "Notificações" · voltar
├── Linhas com Label + Switch: Lembrete da pergunta do dia · Avisos de pontos a expirar · Novidades do programa
└── (sem botão de salvar: o Switch vale na hora)

```
