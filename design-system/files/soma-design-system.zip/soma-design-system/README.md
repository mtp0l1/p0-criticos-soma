# Primeiros passos

Como usar o sistema, regras de conteúdo, fundamentos visuais e acessibilidade.

## Por onde começar

Quatro caminhos, conforme o que você está fazendo.

Estou começando um produto

Veja as camadas do sistema e como adotar o núcleo, o tema e só os módulos de que o produto precisa.

Estou desenhando

Monte com o núcleo. As telas da v2 (Padrões › Telas da v2) são a referência oficial; o registro do handoff anterior mostra de onde vieram os módulos e quais tokens substituíram cada valor.

Estou gerando telas com IA

Leia o AGENTS.md e o mapa de decisão. Eles dizem o que usar, o que nunca fazer e como conferir.

Estou construindo

Arquitetura shadcn/ui, convenções, estados e o pacote para levar para o repositório.

## Como usar este sistema

- O Campana é white label: serve a todos os produtos do ecossistema So+ma. O núcleo não depende de produto; as funcionalidades específicas vivem em módulos opcionais. "Para qualquer produto" explica as camadas e como adotar em um produto novo.
- Monte telas só com os componentes de `window.Soma` (lista em "Gerar telas com IA") e com os estilos de texto. Leia o README do componente antes de usá-lo. A base técnica é a do shadcn/ui (Radix + CVA + Tailwind); veja "Para engenharia".
- Cor sempre por papel: use os tokens semânticos (`text-primary`, `surface-accent`, `interactive-fill-loud`…) ou os aliases do shadcn que apontam para eles (`primary`, `accent`, `ring`…). Os tokens de núcleo (`orange`, `navy`, `surface-tile`…) só existem para alimentar os semânticos.
- Medidas só da grade de 4px: `space-*`, `radius-*`, `size-*`. Nada de 13px, 15px de padding ou hex solto.
- Faltou um componente? Monte com primitivos, nomeie a camada `##NomeDoComponente##` e registre o caso na lista de lacunas do handoff.
- O sistema segue as telas **novas** do handoff de referência no Figma. O que o redesign substituiu foi removido, sem versão anterior. "Handoff de referência" diz qual componente monta cada tela e para qual token vai cada hex do arquivo.

## Conteúdo

**Regras de voz (valem para todo produto)**

- Escreva em português do Brasil, em tom direto e acolhedor, tratando a pessoa por "você".
- Títulos, botões e rótulos usam maiúscula só na primeira letra: "Meu perfil", "Buscar material". Nunca "Meu Perfil".
- Diga "tocar", não "clicar".
- Use uma única saudação, "Olá {primeiro nome}", sem vírgula, lida sempre do mesmo campo de nome.
- Nada de emoticon de pontuação (":(" ou ":)"). Mensagem de ausência diz o que houve e o que fazer: "Não há pontos de retirada disponíveis na sua cidade".
- Conta nova não lê texto que pressupõe histórico: "Faça sua primeira ação", nunca "Continue de onde parou" com tudo zerado.
- Números usam vírgula decimal ("9,23%") e ponto de milhar ("9.057"). "R$" só quando for dinheiro.
- Erro é aprendizado, não punição: o texto de resposta errada explica, não culpa.
- Escreva "e-mail" com hífen. Contato com o produto é "Enviar e-mail", pelo canal de atendimento que o produto definir.
- Atribuição de rodapé é "desenvolvido por so+ma", em `caption`, sem número de versão e sem peso perto do logo do produto.
- Nomes de função ficam como estão: o produto escolhe o nome ("Buscar material", "Doe seus pontos") e usa o mesmo em todo lugar.

**Vocabulário (definido por produto)**

Cada produto escreve o seu glossário: como chama a pessoa, o que ela ganha, onde ela entrega ou resgata. O sistema só exige que o termo seja o mesmo em todas as telas. Como referência, o primeiro produto diz "amigos" (não "pessoas"), "participante" (não "usuário"), "o programa" dentro de frase (não o nome da marca), "recicláveis" para o que a pessoa leva e "espaço de recebimento" para o lugar de entrega.

## Fundamentos visuais

**Cor.** Fundo creme, texto azul-marinho, laranja só no que é ação. Valores do tema padrão So+ma (versão 2): texto `ink` #21344E, apoio #56697F, divisor #E8E2D6, fundo de tela #FBF7F1, superfície #FFFFFF, laranja da ação #FFA125, laranja de texto #9E5400. Cada produto pode ter um tema com valores de núcleo próprios (veja "Para qualquer produto"); os papéis dos tokens semânticos não mudam. Fundo de tela `background-primary` (creme); trilhos e áreas rebaixadas em `background-secondary`; cartões, campos, linhas de lista e a barra inferior em `surface-primary`; lembretes e dicas em `surface-accent`; cartão de saldo, botão escuro e toast em `surface-inverse`; `surface-brand` (laranja) só como fundo da tela de sucesso. Texto em `text-primary`, apoio em `text-secondary`, link e rótulo de ação em `text-link`. Um laranja cheio por tela, na ação principal. Verde e vermelho sempre com ícone e texto. `border-highlight` (#FFA125) marca o que está selecionado ou em foco. Ouro, prata e bronze (`award-*`) só em pódio e selo de nível, nos módulos que têm ranking ou nível. Os tons de dados (azul, lilás, verde, rosa, amarelo) só distinguem categorias, nunca em botão, seleção ou feedback.

**Botão primário.** `interactive-fill-loud` com `text-on-loud` (azul-marinho, 6,2:1) em todos os primários, com o brilho `shadow-glow`. No tema padrão, texto branco sobre laranja mede 2,0:1 e não é permitido, nem em botão, nem em banner, nem em cartão. Um tema novo precisa conferir o par próprio.

**Laranja como texto.** Texto e ícone isolado em laranja usam `text-link` e `icon-brand-strong` (#9E5400 no tema padrão): 5,6:1 sobre `surface-primary` e 4,9:1 sobre `surface-accent`.

**Feedback.** Estado nunca vai só em cor: chip, mensagem e toast levam ícone e palavra. Sucesso usa check (`feedback-*-positive`), espera usa relógio (`feedback-*-caution`), erro usa × ou alerta (`feedback-*-negative`). Erro passageiro vai em `Toast`; o que precisa ficar na tela vai em `Message`.

**Tipografia.** Uma família, Lexend (`sans`), em quatro pesos (400, 500, 600, 700), com os 16 estilos de texto da v2 (a lista completa, com tamanho, peso e tracking, está em Fundamentos › Tipografia): `page-title` = Title L (28/34 bold), `screen-title` = Title M (22/28 bold), `section-title` = Title S (18/24 semibold), `subtitle` e `header-title` = Heading (17/22 semibold), `body` = Body (15/22), `body-small` = Body S (14/20), `caption` = Micro (12/16), `balance-number` = Display XL (48/56), `display` = Display (32/38). O tracking acompanha o tamanho: negativo nos títulos grandes, positivo na caixa-alta, zero no corpo. `tab-label` é o único estilo abaixo de 12px. Legenda é `text-secondary` cheia, nunca texto translúcido.

| Elemento | Estilo |
|---|---|
| Título da tela e de passo do cadastro | `page-title` |
| Título de folha, de tela de estado e valor médio | `screen-title` |
| Título de seção e de cartão | `section-title` |
| Título de linha e de bloco | `subtitle` |
| Título do cabeçalho | `header-title` |
| Número de destaque (saldo, total) | `balance-number` |
| Valor de indicador, posição no ranking | `stat-number` |
| Parágrafo | `body` |
| Parágrafo em ênfase, pergunta do quiz | `body-strong` |
| Texto de apoio, texto de opção | `body-small` |
| Rótulo de tile, linha, card | `label` |
| Legenda, meta, equivalência | `caption` |
| Categoria acima de título | `eyebrow` (maiúsculo no componente` |
| Título de tela de sucesso | `display` |

**Espaço e forma.** Grade de 4px, só tokens `space-*`: margem lateral de tela `space-xsmall` (20px, conteúdo de 350px em tela de 390px); do cabeçalho ao conteúdo e entre blocos `space-small` (24px); título de bloco ao conteúdo `space-nano`; padding de card `space-mini`; botões empilhados a 10px. O bloco de ação fixo termina 12px acima da barra inferior e tem altura automática (dois botões cabem); o conteúdo rolável leva 140px de padding inferior para o último item não ficar sob a barra. Em tela de resultado o ícone começa a `space-large` (40px) do cabeçalho. Raios (Fundamentos › Raios): miniatura `radius-small` (12); aviso e nota `radius-medium` (16); campo e linha de lista `radius-large` (20); cartão, bloco e modal `radius-xlarge` (24); botão `radius-2xlarge` (28); barra inferior flutuante `radius-3xlarge` (32); folha `radius-sheet` (36, só nos cantos superiores); chip, selo e disco `radius-full`. O raio do filho é menor ou igual ao do pai.

**Superfície.** A v2 usa elevação suave, em azul-marinho com transparência, nunca preta (Fundamentos › Elevação): `shadow-card` em cartão, campo, linha de lista e botão claro; `shadow-dark` em botão escuro e cartão de saldo; `shadow-glow` só no botão laranja primário; `shadow-float` na barra inferior flutuante; `shadow-high` em popover, lista do Select e toast; `shadow-sheet` na folha. A barra inferior é branca a 86% com desfoque de 24 (com "reduzir transparência": branco opaco, sem desfoque); o cabeçalho fixo ao rolar é opaco; nunca empilhe uma superfície translúcida clara sobre outra. Modal e folha separam do fundo pela película `overlay` (azul-marinho a 50%).

**Estados.** Todo controle tem hover (`interactive-fill-*-hover`, `surface-*-hover`), pressionado (`*-active`), foco e desabilitado; a tabela completa está em "Para engenharia". Desabilitado: `interactive-fill-disabled` com `interactive-text-disabled`, sem borda; só habilite quando o obrigatório estiver preenchido, e opção indisponível diz o motivo. Carregando: `Skeleton` no lugar do conteúdo, `loading` no botão. Foco: anel sólido de 2px em `focus-ring`, a 2px de distância. Selecionado: `selected-indicator` mais texto ou `aria-current`. Contorno de campo usa `border-primary` (exceção documentada ao contraste 3:1 de controle, porque o estado também aparece pelo rótulo e pela posição); foco em borda de 2px.

**Toque.** Todo controle tem pelo menos `size-touch` (44px) de área tocável.

**Navegação.** Barra inferior flutuante com cinco itens, a 16px das laterais e a 24px do fundo; cada produto escolhe os destinos e a ordem (no primeiro produto: Início, Reciclar, Recompensas, Impacto e Menu). A aba ativa vira pílula laranja com o nome; as outras são só ícone em `icon-secondary`. Toda tela de aba mostra a barra; tela de fluxo fechado, não. Cabeçalho com uma única saída, que volta à tela anterior real. Na tela inicial, a ação principal do produto fica acima da dobra.

**Movimento.** Responder ao toque (não ao soltar), seguir o dedo 1:1, tudo interrompível, ir e voltar pelo mesmo caminho, mola em vez de cronômetro: botão pressionado vai a 0,97 em 100 ms; folha abre com mola de resposta 0,30 s e amortecimento 0,8; avançar e voltar usam resposta 0,40 s e amortecimento 1,0; toast entra de cima e fica 2,2 s; carrosséis projetam o gesto e resistem nas bordas. Respeite a preferência de movimento reduzido do aparelho: troque deslocamento e mola por fade de 200 ms.

## Iconografia

- Lucide, em grade de 24 com traço de 2px (2,2px sobre cor de destaque), pontas e cantos arredondados, em `size-icon` (24px) ou `size-icon-small` (16px) dentro de chip, linha de status e botão compacto. Sobre disco de 44px, um tom de dados por categoria. Ícone importante sempre com texto.
- Os ícones marcados como "SVG fornecido" no handoff anterior também são Lucide (por exemplo, Pino = `pin`, Recompensas = `gift`). A lista completa por grupo e os apelidos (o nome da camada no Figma também funciona) estão no README do `Icon`.
- Cor por papel: `icon-brand` ao lado de rótulo, `icon-brand-strong` quando o ícone está sozinho, `icon-primary` no Menu e na barra inferior, `icon-secondary` inativo.
- Ilustrações e mascotes são do produto, não do núcleo. O estilo é de ilustração plana, em tons suaves, sem renders 3D. O primeiro produto usa cena urbana (garrafa PET, lixeiras de reciclagem, pessoas), troféus de três níveis no quiz e um único mascote, o da lata. Todas as ilustrações estão em `6-ilustracoes.md`.

## Acessibilidade

- Texto de 4,5:1 ou mais sobre o fundo; 3:1 para texto grande, ícones que carregam sentido e bordas que delimitam controle. Os pares aprovados estão na nota de cada token semântico.
- Pares do Figma que não atingem isso: texto #DD8613 (2,8:1), #F36208 (3,2:1) e #E8823F → `text-link`; texto branco sobre #FFA125 no chip de data e na meta (2,05:1) → `text-on-loud`; borda de campo #E8E2D6 (1,27:1) → `border-strong`.
- Pares do tema padrão que não atingem isso, mantidos nos tokens de núcleo e com substituto nos semânticos: laranja como texto ou ícone isolado sobre branco (2,05:1) → `text-link` e `icon-brand-strong`; branco sobre `danger` (4,21:1) → `feedback-fill-negative-loud`; borda de campo `line` (1,27:1) → `border-strong`; nome branco no cartão do participante (2,05:1) → `text-on-loud`.
- Controles marcados (Checkbox, Switch) usam navy, não laranja: o laranja contra o branco mede 2,05:1 e o controle precisa de 3:1.
- Os segmentos pendentes da faixa de progresso invertida (`text-secondary` sobre `surface-inverse`) medem 2,25:1; a legenda em texto carrega o progresso.
- Componentes com a variante `app` (`tone="app"`, `border="app"`, `nameTone="app"`) existem só para documentar o estado de produção anterior do primeiro produto. Trabalho novo usa o padrão.
