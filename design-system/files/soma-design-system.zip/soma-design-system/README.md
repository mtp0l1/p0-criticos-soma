## Como usar este sistema

- Monte telas só com os componentes de `window.Soma` (lista em "Gerar telas com IA") e com os estilos de texto. Leia o README do componente antes de usá-lo. A base técnica é a do shadcn/ui (Radix + CVA + Tailwind); veja "Para engenharia".
- Cor sempre por papel: use os tokens semânticos (`text-primary`, `surface-accent`, `interactive-fill-loud`…) ou os aliases do shadcn que apontam para eles (`primary`, `accent`, `ring`…). Os tokens de núcleo (`orange`, `navy`, `surface-tile`…) só existem para alimentar os semânticos.
- Medidas só da grade de 4px: `space-*`, `radius-*`, `size-*`. Nada de 13px, 15px de padding ou hex solto.
- Faltou um componente? Monte com primitivos, nomeie a camada `##NomeDoComponente##` e registre o caso na lista de lacunas do handoff.
- O sistema segue as telas **novas** do handoff no Figma. O que o redesign substituiu (Quiz com Ferro e Platina, `LevelList`, `MissionBanner`, `RankingBanner`, `MemberCard`, a barra com Resgates) foi removido. "Telas novas e mapa do Figma" diz qual componente monta cada tela e para qual token vai cada hex do arquivo.

## Conteúdo

- Escreva em português do Brasil, em tom direto e acolhedor, tratando a pessoa por "você".
- Títulos, botões e rótulos usam maiúscula só na primeira letra: "Meu impacto", "Buscar material", "Minhas recompensas". Nunca "Meu Impacto".
- Diga "tocar", não "clicar". Diga "amigos" ("Convidar amigos"), não "pessoas". Diga "participante", não "usuário" nem "casa". Dentro de frase, diga "o programa", não "Soma". Para o que a pessoa leva, diga "recicláveis". O lugar de entrega é "espaço de recebimento".
- Use uma única saudação, "Olá, {primeiro nome}", com vírgula, lida sempre do mesmo campo de nome.
- Nada de emoticon de pontuação (":(" ou ":)"). Mensagem de ausência diz o que houve e o que fazer: "Não há pontos de retirada disponíveis na sua cidade".
- Conta nova não lê texto que pressupõe histórico: "Faça sua primeira entrega", nunca "Continue reciclando" nem "Você não tem pontos a expirar" com saldo zero.
- Números usam vírgula decimal ("9,23%") e ponto de milhar ("9.057 pontos"). "R$" só quando for dinheiro.
- Erro é aprendizado, não punição: o texto de resposta errada explica, não culpa.
- Contato com o programa é "Enviar e-mail" (SAC de cada programa). Não ofereça WhatsApp. Escreva "e-mail" com hífen.
- Atribuição de rodapé é "desenvolvido por so+ma", em `caption`, sem número de versão e sem peso perto do logo do programa.
- Nomes de função ficam como estão: "Buscar material", "Ganhe suas medalhas", "Doe seus pontos", "Entregando em {local}".

## Fundamentos visuais

**Cor.** Os valores vêm das variáveis do Figma: texto `ink` #21344E, apoio #5C7089, divisor #DDE4EE, fundo #FDFEFF, laranja do botão #F2A545, destaque #FFA125, laranja de texto #A64B00. Fundo de tela `background-primary`; telas de painel (Meu impacto, Ranking) em `background-secondary` com cards `surface-primary`. Tiles em `surface-secondary`, saldo e linhas de ajuda em `surface-accent`, faixa de missão em `surface-inverse`, banner do ranking e cartão do participante em `surface-brand`. Texto em `text-primary`, apoio em `text-secondary`, link em `text-link`. O laranja guia a ação e o estado selecionado; fundos neutros dominam. `border-highlight` (#FFA125) marca o que está selecionado ou em foco (card, opção, campo, dia de hoje). Ouro, prata e bronze (`award-*`) só no pódio e no selo de nível.

**Botão primário.** `interactive-fill-loud` com `text-on-loud` em todos os primários. Texto branco sobre laranja mede 2,05:1 e não é permitido, nem em botão, nem em banner, nem no cartão.

**Laranja como texto.** Texto e ícone isolado em laranja usam `text-link` e `icon-brand-strong` (#A64B00, o laranja do item ativo no Figma): 5,73:1 sobre `surface-primary`, 5,35:1 sobre `surface-accent` e 5,28:1 sobre `surface-secondary`.

**Feedback.** Estado nunca vai só em cor: chip, mensagem e toast levam ícone e palavra. Sucesso usa check (`feedback-*-positive`), espera usa relógio (`feedback-*-caution`), erro usa × ou alerta (`feedback-*-negative`). Erro passageiro vai em `Toast`; o que precisa ficar na tela vai em `Message`.

**Tipografia.** Uma família, Lexend (`sans`), em quatro pesos (400, 500, 600, 700), com os estilos do Figma: `page-title` = Heading/Medium (24/32 bold), `screen-title` = Heading/Small (20/28 bold), `subtitle` = Subtitle/X-Small (16/24 medium), `body` = Paragraph/X-Small (16/24), `body-small` = Paragraph/2X-Small (14/20), `caption` = Paragraph/3X-Small (12/16). Título de conteúdo `page-title`, título de tela raiz `screen-title`, bloco `subtitle`, cabeçalho `header-title`, indicador e posição `stat-number`, saldo `balance-number`, texto `body`, destaque `body-strong`, rótulos `label`, categoria acima de título `eyebrow`, apoio `caption`, botão `button`. `tab-label` é o único estilo abaixo de 12px. Legenda é `text-secondary` cheia, nunca texto translúcido.

| Elemento | Estilo |
|---|---|
| Título da tela no conteúdo ("Vamos começar pelo seu nome…") | `page-title` |
| Título de tela raiz de aba ("Reciclar", "Ranking") | `screen-title` |
| Título de bloco nas telas novas ("Sua próxima entrega") | `subtitle` |
| Rótulo de campo, texto de opção | `body-small` |
| Título do cabeçalho | `header-title` |
| Saldo de pontos | `balance-number` |
| Valor de indicador, posição no ranking | `stat-number` |
| Título de modal, pergunta do quiz | `body-strong` |
| Rótulo de tile, linha, card | `label` |
| Parágrafo | `body` |
| Legenda, meta, equivalência | `caption` |
| "PERGUNTA DO DIA", "ESCOLHA A DATA" | `eyebrow` (maiúsculo no componente) |

**Espaço e forma.** Grade de 4px, só tokens `space-*`, seguindo a página de espaçamento do Figma: margem lateral de tela `space-xsmall` (20px); do cabeçalho ao conteúdo e entre blocos `space-small` (24px); título de bloco ao conteúdo `space-nano`; padding de card `space-mini` ou `space-micro`; do último bloco ao botão principal `space-medium` (32px), sem colar o botão na barra; botões empilhados a `space-nano`; em tela de resultado o ícone começa a `space-large` (40px) do cabeçalho. Lista longa termina com o botão. Raios: tile, card, modal e banner `radius-large` (16); card de formulário `radius-xlarge` (24); botão, campo e linha `radius-medium` (12); opção de resposta, chip de data e toast `radius-small` (8); selo de nível `radius-xsmall` (4); chip e botão em pílula `radius-full`. Os 10, 14 e 18px do Figma vão para o raio mais próximo da escala. O raio do filho é menor ou igual ao do pai.

**Superfície.** O app é plano: sem sombra em tile, card, botão ou banner (a sombra das linhas de Recompensas no Figma vira borda `border-primary`). Só o que flutua (Popover, lista do Select, bottom sheet) leva `shadow-high`. Separação vem das superfícies e do divisor `border-primary`. Modal e bottom sheet separam do fundo pelo `overlay`.

**Estados.** Todo controle tem hover (`interactive-fill-*-hover`, `surface-*-hover`), pressionado (`*-active`), foco e desabilitado; a tabela completa está em "Para engenharia". Desabilitado: `interactive-fill-disabled` com `interactive-text-disabled`, sem borda; só habilite quando o obrigatório estiver preenchido, e opção indisponível diz o motivo. Carregando: `Skeleton` no lugar do conteúdo, `loading` no botão. Foco: anel sólido de 2px em `focus-ring`, a 2px de distância. Selecionado: `selected-indicator` mais texto ou `aria-current`. Contorno de controle usa `border-strong`.

**Toque.** Todo controle tem pelo menos `size-touch` (44px) de área tocável.

**Navegação.** Barra inferior fixa com cinco itens, nesta ordem: Início, Reciclar, Recompensas, Impacto, Menu (Resgates vive dentro de Recompensas, em "Meus resgates"). Item ativo em `text-link` (#A64B00) e peso 600. Cabeçalho com uma única saída, que volta à tela anterior real. Na Home, a barra de local fica fixa ao rolar e a ação que gera pontos fica acima da dobra.

**Movimento.** Transições curtas (até 200ms) de cor e posição; respeite a preferência de movimento reduzido do aparelho.

## Iconografia

- Lucide, o mesmo set das telas novas no Figma, com traço de 2px, em `size-icon` (24px) ou `size-icon-small` (16px) dentro de chip, linha de status e botão compacto.
- Os "SVG fornecido" do Figma também são Lucide: Reciclar = `recycle`, Meu impacto = `chart`, Pino = `pin`, Recompensas = `gift`. A lista completa por grupo e os apelidos (o nome da camada no Figma também funciona) estão no README do `Icon`.
- Cor por papel: `icon-brand` ao lado de rótulo, `icon-brand-strong` quando o ícone está sozinho, `icon-primary` no Menu e na barra inferior, `icon-secondary` inativo.
- A medalha do quiz tem três níveis (Bronze, Prata, Ouro), com uma, duas ou três estrelas; o nível também vai no texto e no `LevelBadge`.
- Ilustrações são planas, em tons suaves, em cena urbana (garrafa PET, lixeiras de reciclagem, pessoas). Evite folhas e floresta, que remetem a orgânico, e renders 3D. O mascote da lata do Quiz (resultado da resposta) é o único personagem do app.

## Acessibilidade

- Texto de 4,5:1 ou mais sobre o fundo; 3:1 para texto grande, ícones que carregam sentido e bordas que delimitam controle. Os pares aprovados estão na nota de cada token semântico.
- Pares do Figma que não atingem isso: texto #DD8613 (2,8:1), #F36208 (3,2:1) e #E8823F → `text-link`; texto branco sobre #F2A545 no chip de data e na meta (2,05:1) → `text-on-loud`; borda de campo #DDE4EE (1,27:1) → `border-strong`.
- Pares do app que não atingem isso, mantidos nos tokens de núcleo e com substituto nos semânticos: laranja como texto ou ícone isolado sobre branco (2,05:1) → `text-link` e `icon-brand-strong`; branco sobre `danger` (4,21:1) → `feedback-fill-negative-loud`; borda de campo `line` (1,27:1) → `border-strong`; nome branco no cartão do participante (2,05:1) → `text-on-loud`.
- Controles marcados (Checkbox, Switch) usam navy, não laranja: o laranja contra o branco mede 2,05:1 e o controle precisa de 3:1.
- Os segmentos pendentes da faixa de missão (`text-secondary` sobre `surface-inverse`) medem 2,25:1; a legenda em texto carrega o progresso.
- Componentes com variante "como no app" (`tone="app"`, `border="app"`, `nameTone="app"`) existem só para documentar o estado atual. Trabalho novo usa o padrão.
