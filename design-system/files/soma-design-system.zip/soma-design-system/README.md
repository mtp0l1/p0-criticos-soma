## Como usar este sistema

- O Campana é white label: serve a todos os produtos do ecossistema So+ma. O núcleo não depende de produto; as funcionalidades específicas vivem em módulos opcionais. "Para qualquer produto" explica as camadas e como adotar em um produto novo.
- Monte telas só com os componentes de `window.Soma` (lista em "Gerar telas com IA") e com os estilos de texto. Leia o README do componente antes de usá-lo. A base técnica é a do shadcn/ui (Radix + CVA + Tailwind); veja "Para engenharia".
- Cor sempre por papel: use os tokens semânticos (`text-primary`, `surface-accent`, `interactive-fill-loud`…) ou os aliases do shadcn que apontam para eles (`primary`, `accent`, `ring`…). Os tokens de núcleo (`orange`, `navy`, `surface-tile`…) só existem para alimentar os semânticos.
- Medidas só da grade de 4px: `space-*`, `radius-*`, `size-*`. Nada de 13px, 15px de padding ou hex solto.
- Faltou um componente? Monte com primitivos, nomeie a camada `##NomeDoComponente##` e registre o caso na lista de lacunas do handoff.
- O sistema segue as telas **novas** do handoff de referência no Figma. O que o redesign substituiu foi removido, sem versão anterior. "Handoff de referência" diz qual componente monta cada tela e para qual token vai cada hex do arquivo.

## Conteúdo

**Regras de voz (valem para todo produto)**

- Escreva em português do Brasil, em tom direto e acolhedor, tratando a pessoa por "você".
- Títulos, botões e rótulos usam maiúscula só na primeira letra: "Meu perfil", "Buscar material". Nunca "Meu Perfil".
- Diga "tocar", não "clicar".
- Use uma única saudação, "Olá {primeiro nome}", sem vírgula, lida sempre do mesmo campo de nome.
- Nada de emoticon de pontuação (":(" ou ":)"). Mensagem de ausência diz o que houve e o que fazer: "Não há pontos de retirada disponíveis na sua cidade".
- Conta nova não lê texto que pressupõe histórico: "Faça sua primeira ação", nunca "Continue de onde parou" com tudo zerado.
- Números usam vírgula decimal ("9,23%") e ponto de milhar ("9.057"). "R$" só quando for dinheiro.
- Erro é aprendizado, não punição: o texto de resposta errada explica, não culpa.
- Escreva "e-mail" com hífen. Contato com o produto é "Enviar e-mail", pelo canal de atendimento que o produto definir.
- Atribuição de rodapé é "desenvolvido por so+ma", em `caption`, sem número de versão e sem peso perto do logo do produto.
- Nomes de função ficam como estão: o produto escolhe o nome ("Buscar material", "Doe seus pontos") e usa o mesmo em todo lugar.

**Vocabulário (definido por produto)**

Cada produto escreve o seu glossário: como chama a pessoa, o que ela ganha, onde ela entrega ou resgata. O sistema só exige que o termo seja o mesmo em todas as telas. Como referência, o primeiro produto diz "amigos" (não "pessoas"), "participante" (não "usuário"), "o programa" dentro de frase (não o nome da marca), "recicláveis" para o que a pessoa leva e "espaço de recebimento" para o lugar de entrega.

## Fundamentos visuais

**Cor.** Os valores abaixo são os do tema padrão So+ma, vindos das variáveis do Figma. Cada produto pode ter um tema com valores de núcleo próprios (veja "Para qualquer produto"); os papéis dos tokens semânticos não mudam. Valores do tema padrão: texto `ink` #21344E, apoio #5C7089, divisor #DDE4EE, fundo #FDFEFF, laranja do botão #F2A545, destaque #FFA125, laranja de texto #A64B00. Fundo de tela `background-primary`; telas de painel em `background-secondary` com cards `surface-primary`. Tiles em `surface-secondary`, destaques suaves e linhas de ajuda em `surface-accent`, faixas invertidas em `surface-inverse`, banners e cartões de marca em `surface-brand`. Texto em `text-primary`, apoio em `text-secondary`, link em `text-link`. O laranja guia a ação e o estado selecionado; fundos neutros dominam. `border-highlight` (#FFA125) marca o que está selecionado ou em foco (card, opção, campo, dia de hoje). Ouro, prata e bronze (`award-*`) só em pódio e selo de nível, nos módulos que têm ranking ou nível.

**Botão primário.** `interactive-fill-loud` com `text-on-loud` em todos os primários. No tema padrão, texto branco sobre laranja mede 2,05:1 e não é permitido, nem em botão, nem em banner, nem em cartão. Um tema novo precisa conferir o par próprio.

**Laranja como texto.** Texto e ícone isolado em laranja usam `text-link` e `icon-brand-strong` (#A64B00 no tema padrão): 5,73:1 sobre `surface-primary`, 5,35:1 sobre `surface-accent` e 5,28:1 sobre `surface-secondary`.

**Feedback.** Estado nunca vai só em cor: chip, mensagem e toast levam ícone e palavra. Sucesso usa check (`feedback-*-positive`), espera usa relógio (`feedback-*-caution`), erro usa × ou alerta (`feedback-*-negative`). Erro passageiro vai em `Toast`; o que precisa ficar na tela vai em `Message`.

**Tipografia.** Uma família, Lexend (`sans`), em quatro pesos (400, 500, 600, 700), com os estilos do Figma: `page-title` = Heading/Medium (24/32 bold), `screen-title` = Heading/Small (20/28 bold), `subtitle` = Subtitle/X-Small (16/24 medium), `body` = Paragraph/X-Small (16/24), `body-small` = Paragraph/2X-Small (14/20), `caption` = Paragraph/3X-Small (12/16). Título de conteúdo `page-title`, título de tela raiz `screen-title`, bloco `subtitle`, cabeçalho `header-title`, indicador e posição `stat-number`, número de destaque `balance-number`, texto `body`, destaque `body-strong`, rótulos `label`, categoria acima de título `eyebrow`, apoio `caption`, botão `button`. `tab-label` é o único estilo abaixo de 12px. Legenda é `text-secondary` cheia, nunca texto translúcido.

| Elemento | Estilo |
|---|---|
| Título da tela no conteúdo | `page-title` |
| Título de tela raiz de aba | `screen-title` |
| Título de bloco | `subtitle` |
| Rótulo de campo, texto de opção | `body-small` |
| Título do cabeçalho | `header-title` |
| Número de destaque (saldo, total) | `balance-number` |
| Valor de indicador, posição no ranking | `stat-number` |
| Título de modal, pergunta do quiz | `body-strong` |
| Rótulo de tile, linha, card | `label` |
| Parágrafo | `body` |
| Legenda, meta, equivalência | `caption` |
| Categoria acima de título | `eyebrow` (maiúsculo no componente) |

**Espaço e forma.** Grade de 4px, só tokens `space-*`, seguindo a página de espaçamento do Figma do tema padrão: margem lateral de tela `space-xsmall` (20px); do cabeçalho ao conteúdo e entre blocos `space-small` (24px); título de bloco ao conteúdo `space-nano`; padding de card `space-mini` ou `space-micro`; do último bloco ao botão principal `space-medium` (32px), sem colar o botão na barra; botões empilhados a `space-nano`; em tela de resultado o ícone começa a `space-large` (40px) do cabeçalho. Lista longa termina com o botão. Raios: tile, card, modal e banner `radius-large` (16); card de formulário `radius-xlarge` (24); botão, campo e linha `radius-medium` (12); opção de resposta, chip de data e toast `radius-small` (8); selo de nível `radius-xsmall` (4); chip e botão em pílula `radius-full`. Os 10, 14 e 18px do Figma vão para o raio mais próximo da escala. O raio do filho é menor ou igual ao do pai.

**Superfície.** O sistema é plano: sem sombra em tile, card, botão ou banner (uma sombra de linha no Figma vira borda `border-primary`). Só o que flutua (Popover, lista do Select, bottom sheet) leva `shadow-high`. Separação vem das superfícies e do divisor `border-primary`. Modal e bottom sheet separam do fundo pelo `overlay`.

**Estados.** Todo controle tem hover (`interactive-fill-*-hover`, `surface-*-hover`), pressionado (`*-active`), foco e desabilitado; a tabela completa está em "Para engenharia". Desabilitado: `interactive-fill-disabled` com `interactive-text-disabled`, sem borda; só habilite quando o obrigatório estiver preenchido, e opção indisponível diz o motivo. Carregando: `Skeleton` no lugar do conteúdo, `loading` no botão. Foco: anel sólido de 2px em `focus-ring`, a 2px de distância. Selecionado: `selected-indicator` mais texto ou `aria-current`. Contorno de controle usa `border-strong`.

**Toque.** Todo controle tem pelo menos `size-touch` (44px) de área tocável.

**Navegação.** Barra inferior fixa com cinco itens; cada produto escolhe os destinos e a ordem (no primeiro produto: Início, Reciclar, Recompensas, Impacto e Menu). Item ativo em `text-link` e peso 600. Cabeçalho com uma única saída, que volta à tela anterior real. Na tela inicial, a ação principal do produto fica acima da dobra.

**Movimento.** Transições curtas (até 200ms) de cor e posição; respeite a preferência de movimento reduzido do aparelho.

## Iconografia

- Lucide, o mesmo set das telas novas no Figma, com traço de 2px, em `size-icon` (24px) ou `size-icon-small` (16px) dentro de chip, linha de status e botão compacto.
- Os "SVG fornecido" do Figma também são Lucide (por exemplo, Pino = `pin`, Recompensas = `gift`). A lista completa por grupo e os apelidos (o nome da camada no Figma também funciona) estão no README do `Icon`.
- Cor por papel: `icon-brand` ao lado de rótulo, `icon-brand-strong` quando o ícone está sozinho, `icon-primary` no Menu e na barra inferior, `icon-secondary` inativo.
- Ilustrações e mascotes são do produto, não do núcleo. O estilo é plano, em tons suaves, sem renders 3D. O primeiro produto usa cena urbana (garrafa PET, lixeiras de reciclagem, pessoas), troféus de três níveis no quiz e um único mascote, o da lata. Todas as ilustrações estão em `6-ilustracoes.md`.

## Acessibilidade

- Texto de 4,5:1 ou mais sobre o fundo; 3:1 para texto grande, ícones que carregam sentido e bordas que delimitam controle. Os pares aprovados estão na nota de cada token semântico.
- Pares do Figma que não atingem isso: texto #DD8613 (2,8:1), #F36208 (3,2:1) e #E8823F → `text-link`; texto branco sobre #F2A545 no chip de data e na meta (2,05:1) → `text-on-loud`; borda de campo #DDE4EE (1,27:1) → `border-strong`.
- Pares do tema padrão que não atingem isso, mantidos nos tokens de núcleo e com substituto nos semânticos: laranja como texto ou ícone isolado sobre branco (2,05:1) → `text-link` e `icon-brand-strong`; branco sobre `danger` (4,21:1) → `feedback-fill-negative-loud`; borda de campo `line` (1,27:1) → `border-strong`; nome branco no cartão do participante (2,05:1) → `text-on-loud`.
- Controles marcados (Checkbox, Switch) usam navy, não laranja: o laranja contra o branco mede 2,05:1 e o controle precisa de 3:1.
- Os segmentos pendentes da faixa de progresso invertida (`text-secondary` sobre `surface-inverse`) medem 2,25:1; a legenda em texto carrega o progresso.
- Componentes com a variante `app` (`tone="app"`, `border="app"`, `nameTone="app"`) existem só para documentar o estado de produção anterior do primeiro produto. Trabalho novo usa o padrão.
