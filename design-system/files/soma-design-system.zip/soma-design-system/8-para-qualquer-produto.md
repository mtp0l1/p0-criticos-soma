# Para qualquer produto

O Campana é white label: um núcleo que não depende de produto e que todo produto do ecossistema So+ma pode adotar, mais módulos opcionais para funcionalidades específicas. Esta página mostra as camadas, como adotar o sistema em um produto novo e onde fica a fronteira entre o que é do sistema e o que é do produto.

## As camadas

| Camada | O que é | Muda por produto? | Onde |
|---|---|---|---|
| Fundamentos | Tokens de cor, texto, espaço, raio, tamanho e elevação, mais o set de ícones | Sim, pelo tema: só os valores de núcleo (cor da marca, fonte) | `tokens.json` → `tokens.css` |
| Núcleo | Componentes sem regra de negócio: Ações, Navegação, Formulários, Sobreposições, Exibição e Feedback | Não | Componentes |
| Módulos de produto | Componentes de uma funcionalidade (quiz, ranking, doação, agendamento, cadastro…), montados só com o núcleo | Opcional: o produto adota só os módulos de que precisa | Módulos de produto |
| Padrões de tela | Telas de exemplo que combinam núcleo e módulos | Referência, não obrigação | Padrões |

O núcleo nunca importa um módulo. Um módulo pode importar o núcleo e outros módulos só quando o contrato dele disser isso.

## Adotar em um produto novo

1. Carregue `tokens.css` no CSS global, antes do Tailwind, e use o preset do Campana.
2. Defina o tema do produto: os valores de núcleo (cores da marca e fonte). Os tokens semânticos e os aliases do shadcn apontam para o núcleo, então os componentes acompanham sem mudança.
3. Monte as telas só com o núcleo. Leia o contrato de cada componente (**Usar para**, **Nunca**, **Verificado por**) antes de usar.
4. Adote um módulo só se o produto tem a funcionalidade. Sem a funcionalidade, o módulo fica de fora.
5. Escreva o glossário do produto: como o produto chama a pessoa, o que ela ganha, onde ela entrega ou resgata. As regras de voz do sistema ficam; o vocabulário muda.
6. Rode `checks/run.sh`. Falha cita a regra e o arquivo.

Ainda não há tema de um segundo produto no repositório. A arquitetura em camadas foi pensada para isso, e a validação com o primeiro produto novo está no roadmap.

## O que é do sistema e o que é do produto

| Sempre do sistema | Definido por cada produto |
|---|---|
| Grade de 4px e escalas de espaço, raio e texto | Cores da marca e fonte (hoje, o tema padrão usa laranja e Lexend) |
| Alvo de toque de 44px e contraste mínimo | Vocabulário e tom de marca dentro das regras de voz |
| Estados de todo controle (hover, pressionado, foco, desabilitado) | Ilustrações, mascotes e imagens |
| Contrato de cada componente | Destinos da navegação e nome das abas |
| Regras e verificações | Módulos adotados |

## Como escrever sem amarrar ao produto

- Na documentação do sistema, escreva "o produto" e "a pessoa". Nome de produto só aparece em exemplo rotulado como exemplo.
- Componente novo recebe nome pela tarefa que resolve (`GoalCard`), nunca pelo produto.
- Texto dentro de componente vem por prop. O sistema não traz frase de um produto como padrão.
- Exemplo concreto de um produto vai para um módulo ou para uma tela de exemplo, não para o núcleo.

## Quando uma peça de módulo vira núcleo

Uma peça sobe para o núcleo quando passa nos três testes:

1. Dois produtos diferentes já usam.
2. O nome e o texto não têm termo de domínio (reciclagem, pontos, quiz).
3. O contrato passa nas verificações sem exceção.

Até lá, ela fica no módulo.

## Lista para um produto novo

- Tema do produto definido, com contraste conferido (4,5:1 para texto, 3:1 para ícone e borda de controle).
- Glossário do produto escrito.
- Telas montadas só com núcleo e módulos adotados.
- Nenhum valor cru (hex, px fora da grade) fora dos tokens.
- Estados de zero, carregando, vazio, erro e sucesso desenhados.
- Verificações rodadas sem falha nova.

## O que ainda é do primeiro produto

O código mantém o namespace `window.Soma` e a pasta `soma/` por compatibilidade. Renomear é mudança de API e exige aviso às equipes de engenharia, por isso está no roadmap e não foi feito de forma silenciosa. Os módulos de produto e as telas de exemplo nasceram do primeiro produto do ecossistema e servem de referência de como montar o seguinte.
