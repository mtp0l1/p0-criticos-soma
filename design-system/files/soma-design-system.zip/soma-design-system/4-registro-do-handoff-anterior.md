# Registro do handoff anterior

Histórico: de onde vieram os módulos, qual componente montava cada tela do handoff anterior à v2 e para qual token ia cada hex.

## Visão geral

**Esta página é um registro histórico.** A referência oficial é a versão 2 do app (Padrões › Telas da v2), e os valores atuais estão em Fundamentos e Componentes. As tabelas abaixo guardam como o sistema foi alinhado ao handoff anterior do primeiro produto do ecossistema (Figma `AMfte9XW4rEFYw18xjeeBC`): a origem dos módulos e das telas de exemplo, e o modelo para registrar o handoff de outro produto. Os nomes de token valem hoje, mas vários valores citados mudaram na v2: campo de 68px (era 48px), raios da escala nova (por exemplo, `radius-small` é 12px), estilos de texto de 11 a 48px, elevação em seis níveis e barra inferior flutuante. A numeração das telas é a do handoff anterior.

## O que mudou no alinhamento ao handoff anterior

O sistema foi alinhado primeiro aos conceitos (Quiz e Ranking) e depois ao **handoff anterior**, que era a fonte de verdade na época. O que aquele handoff substituiu foi **removido**, sem `version="anterior"`; a versão 2 repete a regra.

| Área | Antes | Agora |
|---|---|---|
| Barra inferior | Início · Recompensas · Resgates · Impacto · Menu | Início · **Reciclar** · Recompensas · Impacto · Menu (Resgates saiu da barra e vive em Recompensas). Ativo em #9E5400, peso 600 |
| Laranja de texto (`orange-deep`) | #B05A00 | #9E5400, o do item ativo no Figma; agora passa também sobre `surface-secondary` |
| Texto principal | navy #21344E | `ink` #21344E (Neutral/Level 3). O navy continua no texto sobre o botão laranja |
| Texto de apoio | #585F69 | #56697F |
| Divisor e trilho | #D9DCE1 | #E8E2D6 (Neutral/Level 6) |
| Fundo e card | #FFFFFF | `paper` #FFFFFF (Neutral/Level 8) |
| Destaque | — | `highlight` #FFA125: `border-highlight`, `selected-indicator` |
| Novos tokens | — | `surface-track`, `indicator-inactive`, `surface-info`, `icon-info`, `award-gold`, `award-silver`, `award-bronze` |
| Tipografia | 3 pesos; page-title 22/28; body 15/22; caption 13/18 | 4 pesos (700 entra); estilos do Figma: `page-title` 24/32, `screen-title` 20/28, `subtitle` 16/24, `body` 16/24, `body-small` 14/20, `caption` 12/16 |
| Espaço de tela | margem 16, blocos a 32 | margem 20 (`space-xsmall`), blocos a 24 (`space-small`), botão a 32 do último bloco |
| Ícones | Lucide provisório, 1,75px | Lucide definitivo (é o set do Figma), 2px, ~90 nomes e apelidos do Figma |
| Componentes novos | — | `StepDots`, `LevelBadge`, `PointsBadge`, `StreakTrail`, `StreakProgress`, `RankingRow`, `StatsRow`, `DeliveryCard`, `SpaceCard`, `SlotPicker`, `GoalCard`, `CampaignBanner`, `RewardRow`, `RedeemCode`, `InstitutionCard`, `ResultScreen` |
| Componentes ampliados | — | `Header` (`variant` center · round · start, `divider`), `ChoiceChips` (ícone, `variant="soft"`, `scroll`), `Toast` (`kind` success · info), `Progress` (`indicatorClassName`) |
| **Removidos** | `MissionBanner`, `StepChecklist`, `LevelList`, `RankingBanner`, `MemberCard`, níveis Ferro e Platina, a barra com Resgates, `version="anterior"` | Substituídos pelas telas novas |
| **Novos (Quiz)** | — | `Trophy` (3 níveis, troféu), `TierCard`, `ProtectionNotice`, `AnswerResult`, `DailyDone`, `HistorySummary`, `AnswerHistory`, `MilestoneResult`, `StreakSection`, `Illustration` |
| **Novos (outras telas)** | — | `QuestionTeaser`, `GoalSummaryCard`, `ActivityRow`, `ImpactTiles`, `RewardDetail`, `SpaceDetail`, `QrCheckinCard`, `InviteCodeCard`, `FriendRequestSheet` (era `FriendRequestBanner`), `ContactRow` |
| **Cadastro** | `TextField` e `Input` de 48px (antes 56px), rótulo de 14px regular, `StepDots` só com o atual em laranja, `Header` com token `size-header` 56px | Novos: `SignupStep`, `PasswordField`, `TermsConsent`, `InviteCodeField`, `NeighborhoodNote`, `AccountExistsSheet`, `InviteMessageExample`, `InviteCodeHelpSheet`, ícones `eye` e `eye-off`, token `size-header`. Ajustados: `TextField` (`mask` cpf, phone e cep, `trailing`, "*" colado ao rótulo), `StepDots`, `SheetContent` (`handle`). Telas de exemplo: nome, CPF, celular (e já cadastrado), senha, CEP, convite (e ajuda) |
| **Doar pontos** | `Header` com voltar escuro, `ResultScreen` com círculo de 48px, `TextField` de valor sem mínimo | Novos: `InstitutionRow`, `DonationAmountCard` (+ `donationError`), `DonationStateCard`, `InstitutionDetailModal`. Ajustados: `Header` (voltar escuro nos arranjos `center` e `eyebrow`), `ResultScreen` (`ringSize="xs"`). Telas de exemplo: Doar (valor), lista, sem saldo, pontos insuficientes e sucesso |
| **Ativação e primeira entrega** | `SlotPicker` com opção de 8px e dia sem vaga riscado, `SpaceCard` e `SpaceDetail` com raio de 16px, `QrCheckinCard` com QR de 184px, `ImpactTiles` com título em `body-strong`, `ResultScreen` só em círculo, `GoalSummaryCard` com borda de 1,5px, ícone de 44px e alvo, `ActivityRow` com ícone de 40px e botão, `BalanceCard` escuro com número de 28px | Novos: `DeliverySummaryCard`, `DeliveryHistoryRow`, `DeliveryDayCard`, `RewardChoiceList`, `GoalProgressCard`, `GoalNote`, `ReminderCard`, `ShareImpactModal`. Ajustados: `SlotPicker` (12px, sem risco), `SpaceCard`/`SpaceDetail` (12px), `QrCheckinCard` (QR de 200px, `size-qr` 200px, padding 24px), `Header variant="eyebrow"` e título do `start` em até duas linhas, `SectionHeader size="eyebrow"`, `ImpactTiles` (título `label`, borda de 1,5px em todos), `ResultScreen` (`iconShape`, `titleSize`, `ringOutline`, `extraLink`, `primaryAction.done`), `GoalSummaryCard` (2px, 40px, `flag`), `ActivityRow` (32px, link), `BalanceCard` escuro (24px), ícone `flag` |
| **Início e Reciclar** | `LocationBar` em duas linhas, `Tile` de 88px com conteúdo em cima e embaixo, `BalanceCard` com número em negrito, `QuestionTeaser` com borda de 1,5px e sem título de bloco, `DeliveryCard` com ícones | `LocationBar` de uma linha, `HomeGreeting` novo, `Tile` de 80px centralizado (`size-tile` 80px), `BalanceCard` de 104px com número regular de 32px, `QuestionTeaser` com borda de 1px sob `SectionHeader` "Pergunta do dia", `DeliveryCard` sem ícones, `SectionHeader` sem link com 24px de altura; ordem da Home com Reciclar e ganhar pontos logo após o saldo |
| **Recompensas** | `GoalCard` com botão "Trocar meta", `CampaignBanner` em card com título e link, `RewardRow` com miniatura e "falta X", abas em `SegmentedControl` | `GoalCard` tocável com "≈ kg" e estado atingido, `CampaignBanner` de uma linha, `RewardRow` sem miniatura com `current`, `PillTabs`, `SectionHeader size="small" icon`, `RedeemCode` 26px, `RewardDetail` imagem 150px, exemplos de `ResultScreen` das Telas 19 e 22 |
| **Ranking e Social** | `FriendRequestBanner` (faixa no topo; no Figma é bottom sheet) | `FriendRequestSheet`, `RankingStarterCard`; `Podium` (degraus retos, `self` em destaque, `initials`), `RankingRow` ("#4", dica alinhada ao avatar), `ContactRow` (avatar 40px), `Toast` (`surface="card"`, `icon`, `position` top), `EmptyState` (`artFrame="rect"`, `secondaryAction`, ação `loud`), `ResultScreen` (`ringSize`, `actionsPlacement`, `secondaryAction.hierarchy`), ícone `building` |
| **Refeitos** | — | `LevelCard` (troféu e frase, sem barra; Bronze, Prata e Ouro), `QuestionCard` (sem estados), `StreakProgress` (semanas, marcos 1·5·10·20), `StreakTrail` (anel de hoje), `BalanceCard` (`tone` light · dark), `PositionCard` (`percent`), `Podium` (`anonymous`), `RedeemCode` |

## Tela do handoff anterior → componentes

Nós do handoff. "NOVO" substitui a tela de produção; "PROPOSTA" ainda não foi confirmado e não tem componente.

| Seção / tela (nó) | Componentes |
|---|---|
| Quiz, Tela 1 | `Header variant="round"`, `SegmentedControl`, `LevelCard`, `StreakTrail`, `StreakProgress`, `ProtectionNotice`, `QuestionCard`, `PointsBadge` |
| Quiz, Telas 2A e 2B | `AnswerResult` (acertou e errou) |
| Quiz, Tela 3 e 3B | `StreakTrail` (hoje feito, dia protegido), `DailyDone` |
| Quiz, Tela 4 | `HistorySummary`, `AnswerHistory`, `AnswerHistoryRow` |
| Quiz, Tela 5 | `TierCard` × 3 |
| Quiz, Tela 6 | `Sheet` + `ProtectionNotice`, `StreakProgress` |
| Quiz, Telas 7 e 8 | `MilestoneResult` |
| Quiz, casos A1 a C3 (543:*) | **PROPOSTA**, sem componente |
| Início, Home DEPOIS | `LocationBar`, `HomeGreeting`, `BalanceCard` (light), `SectionHeader` + `TileGrid`, `SectionHeader` + `QuestionTeaser`, `TabBar` |
| Tela 17, Início com meta e atividade | `HomeGreeting`, `GoalSummaryCard`, `BalanceCard` (`tone="dark"` com meta), `SectionHeader size="eyebrow"`, `ActivityRow` |
| Ranking, Telas 1 a 3 | `Header` (voltar + ícone `user-plus` na aba Amigos), `SegmentedControl`, `Tabs`, legenda em `caption`, `Podium` (`anonymous` no Geral), `PositionCard`, `RankingList` + `RankingRow` |
| Ranking, Telas 4 e 7 | `RankingStarterCard` abaixo da lista (0 kg no período) · lista sem pódio com menos de 3 participantes |
| Ranking, Telas 5 e 10 | `Toast surface="card"` no topo: "Você subiu 3 posições…" e "Ana Souza entrou no seu ranking de amigos!" |
| Ranking, Telas 6 e 8 | `EmptyState` (`artFrame="rect"` com `building`; `artFrame={false}` com `ranking-vazio` + `secondaryAction`) |
| Ranking, Tela 9V | `Illustration convite-pontos`, `InviteCodeCard`, `Button` "Compartilhar convite" e `quiet` "Encontrar amigos nos contatos". A Tela 9 (código tracejado) é a versão anterior |
| Ranking, Telas 11 e 12 | `TextField` "Código do amigo" + "Enviar pedido" (desabilitado até digitar) · `ResultScreen ringSize="sm"` "Pedido enviado!" |
| Ranking, Tela 13 | `FriendRequestSheet` (bottom sheet) |
| Ranking, Telas 14 a 16 | `ResultScreen tone="neutral" icon="contacts" ringSize="md"` (permissão e permissão negada, com link "Agora não" / "Voltar ao ranking") · `ContactRow` + `quiet` "Convidar quem ainda não participa" |
| Recompensas, Tela 1 e V1 | `PillTabs`, `GoalCard`, `CampaignBanner`, `ChoiceChips scroll`, `SectionHeader size="small"`, `RewardRow` |
| Recompensas, Telas 18, V2 e 20 | `RewardDetail`, `Button` fixo (definir meta, "Faltam 480 pontos", trocar) |
| Recompensas, Telas 19, 21 e 22 | `ResultScreen` (`ringSize="md"`, `actionsPlacement="inline"`, ícones `crosshair` e `gift`), `RedeemCode` |
| Recompensas, Telas 5, 9 e 23 | `GoalCard` tocável (meta atingida), escolha da próxima meta com `RewardRow`, categoria com `CampaignBanner` + `RewardRow` |
| Reciclar | `screen-title`, `SectionHeader`, `DeliveryCard`, `SearchField`, `ChoiceChips variant="soft"`, `SpaceCard`, `TabBar` |
| Ativação, Tela 24 | `ResultScreen tone="neutral" icon="check" ringOutline` |
| Ativação, Telas 25 e 26 | `RewardChoiceList`, `GoalProgressCard`, `Button` |
| Ativação, Telas 27 e 30 | `Header variant="start"`, `SectionHeader size="eyebrow"`, `SpaceCard onSelect`, `SpaceDetail`, `SlotPicker`, `Button` |
| Ativação, Telas 6, 28 e 29 | `ResultScreen iconShape="square"`, `DeliverySummaryCard`, `primaryAction.done`, `extraLink` |
| Ativação, Tela 7 | `SectionHeader size="eyebrow"`, `DeliverySummaryCard`, `DeliveryHistoryRow` |
| Ativação, Tela 31 | `DeliveryDayCard`, `Button` |
| Ativação, Tela 11 | `Header variant="eyebrow"`, `QrCheckinCard` |
| Ativação, Telas 12 a 16 "Entrega registrada" | `ImpactTiles`, `GoalNote`, `ReminderCard`, `Sheet` (data e horário), `ShareImpactModal`, `notify()` |
| Ativação, Tela 6A | E-mail de confirmação: sem componente |
| Doar pontos | `Header`, `InstitutionRow`, `InstitutionCard`, `DonationAmountCard`, `DonationStateCard`, `InstitutionDetailModal`, `Button`, `ResultScreen`, `TabBar` |
| Cadastro | `Header`, `SignupStep`, `TextField`, `PasswordField`, `InviteCodeField`, `NeighborhoodNote`, `TermsConsent`, `Button`, `StepDots`, `AccountExistsSheet`, `InviteCodeHelpSheet` |
| Bottom Navigation (todas) | `TabBar` |
| Toasts | `Toast` |

## Hex do handoff anterior → token

| Hex no Figma | Onde aparece | Token |
|---|---|---|
| #21344E · #333230 · #1C1917 · #0F1E2C | texto principal (os três últimos são dos conceitos de Ranking, Recompensas e Ativação) | `text-primary` |
| #21344E · #001633 | texto do botão laranja | `text-on-loud` |
| #56697F · #56708F · #82807D · #5C5A58 · #4A5768 · #8C8A87 | apoio, placeholder, posição | `text-secondary` |
| #9E5400 | aba ativa | `text-link`, `icon-brand-strong` |
| #DD8613 · #F36208 · #E8823F (como texto) | eyebrow, pontos, "você" | `text-link` (os originais reprovam) |
| #2563EB | "Saber mais" | `text-link` |
| #FFA125 | botão principal, chip escolhido | `interactive-fill-loud` (`bg-primary`) |
| #F36208 · #E8823F (como preenchimento) | botão e meta nos conceitos | `interactive-fill-loud` / `surface-brand` |
| #FFA125 | borda do card do quiz, campo em foco, dia de hoje, ponto do passo, botão do Cadastro | `border-highlight`, `selected-indicator` (no botão: `interactive-fill-loud`) |
| #FFD3BE | borda da linha "você" no ranking | `border-highlight` |
| #FFFFFF · #FFFFFF | fundo, card, barra | `background-primary`, `surface-primary` |
| #FAF9F6 · #FAF9F5 · #FBF7F2 | fundo dos conceitos | `background-primary` |
| #F2F5F8 · #EFEDE9 · #ECEAE7 | card cinza, trilho do toggle, botão redondo | `surface-secondary` (`background-secondary` como fundo de tela) |
| #FFF5E9 · #FFF2EA · #FFF0EA · #FFF4EB | opção marcada, linha "você", detalhe do espaço, etiqueta de meta | `surface-accent` |
| #E8E2D6 · #E6E4E1 · #E9DFD3 | divisor, borda de card, trilho, dia futuro | `border-primary`, `surface-track` |
| #E8E2D6 (borda de campo) | campo de texto | `input` / `border-strong` (o claro tem 1,27:1) |
| #ACBDD2 | ponto de passo pendente | `indicator-inactive` |
| #E4F2D9 · #EAF7EE / #2D6A4F | dia feito, campanha | `feedback-fill-positive` / `feedback-text-positive` |
| #DCEBFB | dia protegido | `surface-info` (ícone `icon-info`) |
| #E2AF35 · #C1BEBC · #8D6045 | ouro, prata, bronze (só os três níveis do redesign) | `award-gold`, `award-silver`, `award-bronze` |
| #E0DBCE / #9CA3AF | dia indisponível | `interactive-fill-disabled` / `interactive-text-disabled` |

## Fonte, raio e medidas

- **Fonte:** Lexend em tudo. Inter (Quiz, Ranking, Ativação), Sora e Manrope (Recompensas) eram exploração de conceito e vão para Lexend com o estilo equivalente.
- **Peso:** ExtraBold (800) do Figma vira 700.
- **Tamanho:** 9, 10 e 11px de texto (exceto o rótulo da barra) sobem para `caption` 12px. 13px vira `body-small` (14) ou `caption` (12) conforme o papel.
- **Raio:** 8 → `radius-small`; 10 → `radius-small`; 12 → `radius-medium`; 14 → `radius-medium`; 16 → `radius-large`; 18 e pílulas → `radius-full`; 24 → `radius-xlarge`.
- **Área tocável:** botões redondos de 32 e 36px do Figma ficam com 44px de área (`size-touch`); o círculo visível pode continuar menor dentro dela.
- **Sombra:** a sombra suave das linhas de Recompensas vira borda `border-primary`; só o que flutua tem `shadow-high`.

## Lacunas que ficam para o produto

- Mapa dos espaços de recebimento: não há componente de mapa; use a abertura do app de mapas por "Como chegar".
- Ilustrações do redesign: já estão no sistema (troféus Bronze, Prata e Ouro, mascote da lata nas Telas 2A e 2B, arte da conquista, Doar, convite e ranking vazio). `Trophy`, `LevelCard`, `TierCard`, `HistorySummary`, `AnswerResult` e `MilestoneResult` usam a arte sozinhos. Catálogo em `6-ilustracoes.md`. O Figma guarda as imagens em tamanho de tela (96 a 313px); para impressão ou telas grandes, peça os arquivos originais ao time de design.
- Casos PROPOSTA do Quiz (A1 a C3), de Doar (A a E), de Recompensas (A a C) e do Ranking (D): aguardam confirmação com Claudia e Tatiana antes de virar componente.
- Tela 12 "Entrega registrada": o intervalo padrão de 1 semana e o horário sugerido do lembrete estão pendentes de validação no Figma. "Ver recibo" (Tela 17) leva a uma tela fora do fluxo, ainda sem desenho.
- Card de entrega com data vencida: `DeliveryCard state="past"` é proposta; o Figma marca como pendente.
